MELETE 2.1.1 SETUP INSTRUCTIONS
For Sakai 2.1.2 or higher
-----------------------------------------------------
SETUP INSTRUCTIONS

1. Melete Source
	1.1 Migration from previous Melete version
2. Compile Melete 
	2.1 How to deploy the Melete version with the Sferyx Applet editor
3. Database Configuration
4.Configuring Melete 2.1.1 
	4.1 Important Settings
		4.1.1 Create meleteDocs directory
		4.1.2 Create uploads directory
		4.1.3 CHECK OWNER AND GROUP OF UPLOADS DIRECTORY AND MELETEDOCS
		4.1.4 Set the environment for Melete content packaging
	4.2 Settings under Tomcat Instance
		4.2.1 Copy meleteDocs.xml 
		4.2.2 Revise meleteDocs.xml
5. Update Sakai Roles (under realms)
6. Update FCKeditor toolbar 
---------------------------------
1. Melete Source

Melete is a lesson builder tool for Sakai. Melete 2.1.1 is distributed in two versions:
	- melete_os_2.1.1.zip or melete_os_2.1.1.tar.gz is integrated with the open source HTMLArea and FCK Editor
	- melete_sf_2.1.1.zip or melete_sf_2.1.1.tar.gz is ready for integration with the commercial Sferyx Editor

All the source code for the release is included in the .tar.gz and .zip files. To work with Melete source, you need same development environment as sakai essentially Java 1.4 and Maven 1.0.2.

NOTE: If you have an earlier version of Melete already deployed, then undeploy it first, using 'maven sakai:undeploy'.	

1.1 Migration from previous Melete version

	Its very important to follow this step. Melete now supports co-authoring of content. As part of this process, it 
	 is necessary to restructure existing course content. In the scripts directory, 
	 there are two scripts to accomplish the conversion: convert_melete_dir.pl and coauth_script.sql
	 
	INSTRUCTIONS FOR convert_melete_dir.pl
	
	1.1.1 Be sure to back up your meleteDocs before running this script.
	1.1.2 Configure convert_melete_dir.pl There are 4 variables for UNIX and 2 for Windows to configure near the 
	   beginning of the script. They should be pretty self-explanatory.
 	1.1.3 Run the script as root or privileged user. Chown command is called by the script.
	   You can invoke the script by running the following command ./convert_melete_dir.pl on UNIX perl
	   OR convert_melete_dir.pl in Windows. 
	1.1.4 The script may take a few minutes to complete depending on the size of your meleteDocs.
		In testing, it took about 1 minute to convert 57 mb of meleteDocs data on UNIX and about 3 minutes on Windows.

	INSTRUCTIONS for coauth_script.sql
	(The script first creates a backup of the MELETE_SECTION table into a table called MELETE_SECTION_BKUP) 
	1.1.5 Configure the script by specifying the absolute path of your meleteDocs directory by changing the
	   following line in the script.
  		set @meldocs='/var/meleteDocs';
	1.1.6 Log into your sakai database and execute the coauth_script.sql script. 
	   In mysql, this is accomplished by typing in the command: source coauth_script.sql

2. Compile Melete
	Unzip the melete source code zip file and place the melete source under Sakai 2.1.2.
	On the command prompt, go to the melete source directory which you just placed under sakai and run maven commands just like you did for sakai.
	To build, run 'maven sakai:build' and then to deploy 'maven sakai:deploy'
	
	(for more instructions, see section titled 'Sakai Maven Goals' in the 
	"How we build Sakai Using Maven" document provided by Sakai lead developers)

2.1 How to compile and deploy the Melete version with the Sferyx Applet editor
	
	a. Purchase a license and binary source for Sferyx (http://www.sferyx.com)
	b. Download the Melete source for Sferyx.   
	c. Add the purchased applet jar file under /melete-app/src/webapp. 

	Compile melete using maven commands as described above. There is no other difference.

3. Database Configuration

	* Melete works with HSQLDB, Oracle or Mysql4.1 Database. The driver used is 
	the MySql Connector/J 3.1.12 (same as Sakai). It has been tested just on Mysql. 
	* Melete shares the same database as Sakai's and adds few tables to the database. 
	
	To setup the Melete tables: 
	
	a. You can either run sql scripts manually provided under
	/components/src/sql/mysql, OR
	
	b. When tomcat starts, hibernate will generate the melete tables 
	on its own by reading xml files.
	
4. Configuring Melete 2.1.1 

4.1 Important Settings

	4.1.1 Create meleteDocs directory under /var for linux and unix servers and under 
	C: for windows.
	Make sure web.xml of melete has the right value. 
		  <context-param>
			<param-name>homeDir</param-name>
			<param-value>C:</param-value>
		</context-param>
	Note: Please make sure that homeDir location is just one level deep. n-levels directory structure is 
	presently not supported i.e. it can only be c:\meleteDocs or D:\meleteDocs and NOT c:\sakai\meleteDocs.
	For unix and linux servers, you can make symbolic links to achieve n-level directory structure.
	
	4.1.2 Similarly create uploads directory.
	   Make sure web.xml of melete has the right value.Look under init-param of Orielly's filter
		<init-param>
	        	 <param-name>uploadDir</param-name>
			 <param-value>c:/uploads</param-value>
		</init-param>
	Here also n-level directory structure is not supported.
	
	4.1.3 MAKE SURE FOR LINUX AND UNIX BOXES, OWNER AND GROUP OF UPLOADS  
	AND MELETEDOCS DIRECTORY IS SAME AS THAT OF TOMCAT INSTANCES.

	4.1.4 Set the environment for Melete content packaging
	
	a. The dependency files for export are in the /var folder provided in the melete source code. 
	b. On windows, copy var and its sub directories to c:\ and on unix copy var sub directories under /var
	c. Check the permissions for /var/melete and its children. They should have read and write permissions
	d. If you want to change the location of these files modify the packagingdir param path in
	/melete-app/src/webapp/WEB-INF/web.xml and copy the export dependency files to param path. 
	Make sure these folders have read and write permissions. 
   
   update /var/melete/packagefiles to the location where you have placed the dependency files 
   	<context-param>
		 <param-name>packagingdir</param-name>
		 <param-value>/var/melete/packagefiles</param-value>
	</context-param>

4.2 Settings under Tomcat Instance

	4.2.1 Copy meleteDocs.xml provided in the melete source code into tomcat/conf/Catalina/localhost. 
	
	meleteDocs.xml is a configuration file for providing the context path of  
	lessons or modules generated through the use of the application, stored as physical files. 
	
	4.2.2 Revise the meleteDocs.xml to point to the location of the meleteDocs directory. 
	Windows Tomcat requires a different meleteDocs.xml file than Unix/Linux.   
	Under Windows, the docroot path "/var/meleteDocs" must be "c:/meleteDocs"  
	
	Note the leading "c:" Without it, Tomcat looks in "c:/tomcat/webapps/var/meleteDocs", 
	which doesn't exist. 
		
5. Update Sakai Roles (under realms) to include Melete permissions

	(If you are simply upgrading Melete in your Sakai instance, no roles changes are needed)

	5.1 Check appropriate Melete permissions under the roles in !site.template.course. 
	
		* Check melete.author for teacher, instructor, faculty types of roles (maintain).
		* Check melete.student for student types of custom roles that you have (access).
		
	5.2. If you have project sites and related roles in !site.template.project, appropriate 
		permissions (melete.student or melete.author) need to be checked as defined above.
		
   CAUTION: 
   		a. IF YOU FAIL TO CHECK THE MELETE.STUDENT AND MELETE.AUTHOR PERMISSIONS FOR YOUR
			ROLES, MELETE WILL NOT WORK PROPERLY. 
		b. IF YOU ADD MELETE TO _EXISTING SITES_, USERS WILL NOT HAVE THE MELETE PERMISSIONS 
			THAT YOU CHECKED. YOU WILL NEED TO USE !SITE.HELPER OR OTHER SCRIPT TO PROPAGATE 
			THE CHANGES. 

6. Update FCKeditor toolbar 

	Sakai supports 2 wysiwyg editors: HTMLArea and FCK Editor. For Melete, we recommend FCK Editor. 
	It can be set as the default in sakai.properties by configuring this parameter: wysiwyg.editor=FCKeditor
	
	We will also recommend you to customize the sakai provided FCKEditor to include option to insert image url. 
	There are 2 ways to do it.
	
	Either go to sakai_2-1-2_xxx/reference/library/src/webapp/editor/FCKeditor/config.js 
	file, and change this statement to include Image
	FCKConfig.ToolbarSets["Default"] = [
    ['Source','-','Preview'],
    ['Cut','Copy','Paste','PasteText','PasteWord','-','SpellCheck'],
    ['Undo','Redo','-','Find','Replace','-','SelectAll','RemoveFormat'],
    ['Bold','Italic','Underline','StrikeThrough','-','Subscript','Superscript'],
    ['OrderedList','UnorderedList','-','Outdent','Indent'],
    ['JustifyLeft','JustifyCenter','JustifyRight','JustifyFull'],
    ['Link','Unlink','Anchor'],
	['Image'],['Smiley'],
    ['SpecialChar'], ['Style'], 
    '/',
    ['FontFormat','FontName','FontSize'],
    ['TextColor','BGColor'],
    ['About']
     ] ;
	 
    and compile and deploy sakai again. 
	
    OR
	
	If you have already deployed sakai and don't want to redeploy then under 	
	tomcat/webapps/library/editor/FCKeditor/config.js you can revise the above statement.
	
	Go to FCKeditor source code under /webapps/library/editor/FCKeditor/dialog/fck_image/fck_image_preview.html and remove text after <a> tag from body.