/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-component-shared/src/java/org/sakaiproject/component/app/melete/Term.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html 
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import org.apache.commons.lang.builder.ToStringBuilder;

import org.sakaiproject.api.app.melete.TermService;


/** @author Hibernate CodeGenerator */
public class Term implements Serializable,TermService {

    /** identifier field */
    private Short termId;

    /** persistent field */
    private String season;

    /** persistent field */
    private int year;

    /** persistent field */
    private Date startDate;

    /** persistent field */
    private Date endDate;

    /** nullable persistent field */
    private String institute;

    /** persistent field */
    private Set moduleshdates;

    /** persistent field */
    private Set modulestudentprivs;

    /** persistent field */
    private Set coursemodules;

    /** full constructor */
    public Term(String season, int year, Date startDate, Date endDate, String institute, Set moduleshdates, Set modulestudentprivs, Set coursemodules) {
        this.season = season;
        this.year = year;
        this.startDate = startDate;
        this.endDate = endDate;
        this.institute = institute;
        this.moduleshdates = moduleshdates;
        this.modulestudentprivs = modulestudentprivs;
        this.coursemodules = coursemodules;
    }

    /** default constructor */
    public Term() {
    }

    /** minimal constructor */
    public Term(String season, int year, Date startDate, Date endDate, Set moduleshdates, Set modulestudentprivs, Set coursemodules) {
        this.season = season;
        this.year = year;
        this.startDate = startDate;
        this.endDate = endDate;
        this.moduleshdates = moduleshdates;
        this.modulestudentprivs = modulestudentprivs;
        this.coursemodules = coursemodules;
    }

    public Short getTermId() {
        return this.termId;
    }

    public void setTermId(Short termId) {
        this.termId = termId;
    }

    public String getSeason() {
        return this.season;
    }

    public void setSeason(String season) {
        this.season = season;
    }

    public int getYear() {
        return this.year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getInstitute() {
        return this.institute;
    }

    public void setInstitute(String institute) {
        this.institute = institute;
    }

    public Set getModuleshdates() {
        return this.moduleshdates;
    }

    public void setModuleshdates(Set moduleshdates) {
        this.moduleshdates = moduleshdates;
    }

    public Set getModulestudentprivs() {
        return this.modulestudentprivs;
    }

    public void setModulestudentprivs(Set modulestudentprivs) {
        this.modulestudentprivs = modulestudentprivs;
    }

    public Set getCoursemodules() {
        return this.coursemodules;
    }

    public void setCoursemodules(Set coursemodules) {
        this.coursemodules = coursemodules;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("termId", getTermId())
            .toString();
    }

}
