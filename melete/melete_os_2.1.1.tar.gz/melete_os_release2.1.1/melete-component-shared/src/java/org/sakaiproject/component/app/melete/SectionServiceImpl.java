/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-component-shared/src/java/org/sakaiproject/component/app/melete/SectionServiceImpl.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import java.util.List;

import net.sf.hibernate.HibernateException;

import org.sakaiproject.service.framework.log.Logger;
import org.sakaiproject.api.app.melete.SectionService;
import org.sakaiproject.api.app.melete.ModuleObjService;
import org.sakaiproject.api.app.melete.SectionObjService;

/**
 * @author Rashmi
 *
 * This is the class implementing SectionService interface.
 * Mallika - 4/20/05 - Added method to delete section
 * Revised by rashmi 4/26 add method for sort sections
 */
public class SectionServiceImpl implements Serializable, SectionService{
	 private SectionDB sectiondb;
	private ModuleDB moduleDB;
	 private Section section = null;
	 private List sections = null;
	 private Logger logger;

	public SectionServiceImpl(){
	//	System.out.println("section business cons called");
		sectiondb= getSectiondb();
		moduleDB = getModuleDB();
	}
	
	public void insertSection(ModuleObjService module, SectionObjService section, String contentPath) throws MeleteException
	{
		try{
				// insert new Section
		//		System.out.println("SectionServiceImpl:inserting section");
				Module module1 = (Module)module;
				Section section1 = (Section)section;
			   sectiondb.addSection(module1, section1, contentPath);
	//		   System.out.println("SectionServiceImpl:section inserted");
			   }catch(Exception ex)
				{
			   		logger.error("section business --add section failed");
				   throw new MeleteException("add_section_fail");
				}
	}
	
	public void editSection(ModuleObjService module, SectionObjService section,String dataPath) throws MeleteException
	{
		try{
			// edit Section
			Module module1 = (Module)module;
			Section section1 = (Section)section;
				sectiondb.editSection(module1, section1, dataPath);
		   }
		catch(Exception ex)
			{
				logger.error("multiple user exception in section business");
			   throw new MeleteException("edit_section_multiple_users");
			}
	}
	
	public void deleteSection(SectionObjService sec)
	{
		try
		{
	  		sectiondb.deleteSection((Section)sec);
		}
	  	catch (Exception ex)
		{
	  		
		}
	  			
	}
	
	public SectionObjService getSection(int moduleId, int seqNo) {
		Section section = null;
   //     System.out.println("Coming to SectionBusiness get section method");
        try {
                section = moduleDB.getSection(moduleId, seqNo);
		    }catch (HibernateException e)
		    {
		           logger.error(e.toString());
		    }
        return section;
  }

// Mallika's methods
	  public void setSection(SectionObjService sec) {
	  	  	section = (Section)sec;
	  }

	  public List getSections(int moduleId) {
	  //	System.out.println("Coming to SectionsBusiness getSections");
	  	try {
	  		sections = moduleDB.getSections(moduleId);
	  	}catch (HibernateException e)
		{
	          logger.error(e.toString());
		}
	  	return sections;
	  }

	  public void setSections(List sections) {
	    this.sections = sections;
	  }

	  /*
	   * sort section sequences
	   * @see org.sakaiproject.api.app.melete.SectionService#updateSectionsSequence(java.util.List)
	   */
	  public void updateSectionsSequence(List newSeqList) throws Exception
	  {
	  	try{
			sectiondb.updateSectionsSequence(newSeqList);
			}catch(Exception ex)
			{
				logger.error("ManageModulesBusiness --update sections seq failed");
				throw new MeleteException(ex.toString());
			}	
	  }
	/**
	 * @return Returns the sectiondb.
	 */
	public SectionDB getSectiondb() {
		return sectiondb;
	}
	/**
	 * @param sectiondb The sectiondb to set.
	 */
	public void setSectiondb(SectionDB sectiondb) {
		this.sectiondb = sectiondb;
	}
		/**
	 * @param moduleDB The moduleDB to set.
	 */
	public void setModuleDB(ModuleDB moduleDB) {
		this.moduleDB = moduleDB;
	}
	public ModuleDB getModuleDB() {
		return moduleDB;
	}
	
		/**
	 * @return Returns the logger.
	 */
	public Logger getLogger() {
		return logger;
	}
	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
}