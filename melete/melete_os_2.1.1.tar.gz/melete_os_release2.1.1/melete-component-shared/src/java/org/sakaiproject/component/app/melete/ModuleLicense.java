package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import org.apache.commons.lang.builder.ToStringBuilder;

import org.sakaiproject.api.app.melete.ModuleLicenseService;

/** @author Hibernate CodeGenerator */
public class ModuleLicense implements Serializable,ModuleLicenseService {

    /** identifier field */
    private Integer code;

    /** nullable persistent field */
    private String description;

    /** full constructor */
    public ModuleLicense(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    /** default constructor */
    public ModuleLicense() {
    }

    /** minimal constructor */
    public ModuleLicense(Integer code) {
        this.code = code;
    }

    public Integer getCode() {
        return this.code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("code", getCode())
            .toString();
    }

}
