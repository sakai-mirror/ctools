package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import org.apache.commons.lang.builder.ToStringBuilder;

import org.sakaiproject.api.app.melete.CoursePrefsObjService;

/** @author Hibernate CodeGenerator */
public class CoursePrefs implements Serializable,CoursePrefsObjService {

    /** identifier field */
    private String courseId;

    /** nullable persistent field */
    private String moduleLabel;

    /** full constructor */
    public CoursePrefs(String courseId, String moduleLabel) {
        this.courseId = courseId;
        this.moduleLabel = moduleLabel;
    }

    /** default constructor */
    public CoursePrefs() {
    }

    /** minimal constructor */
    public CoursePrefs(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseId() {
        return this.courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getModuleLabel() {
        return this.moduleLabel;
    }

    public void setModuleLabel(String moduleLabel) {
        this.moduleLabel = moduleLabel;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("courseId", getCourseId())
            .toString();
    }

}
