/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-component-shared/src/java/org/sakaiproject/component/app/melete/SectionDB.java,v 1.2 2006/02/14 17:28:19 mallikat Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.sakaiproject.service.framework.log.Logger;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Query;
import net.sf.hibernate.Session;
import net.sf.hibernate.StaleObjectStateException;
import net.sf.hibernate.Transaction;

/**
 * @author Rashmi
 *
 * implements actual operations to the section table 
 * and related tables  
 *
 *Revised on 3/15/05 by rashmi to make it compatible for linux and windows
 * Mallika - 4/20/05 - Added method to delete section
 * add method to sort sections - rashmi 4/27/05
 * revised by rashmi 06/01/05 to check if file exists in meleteDocs/tempUpload and delete it
 * revised by rashmi 10/03/05 to sort physical files too along with setting new seq number while
 * performing action sort 
 * Mallika - 2/13/06 - pointing sort to new method bkupFileName to perform renaming at file level
 * inside module directory instead of creating another sort directory
 */

public class SectionDB implements Serializable {
	private HibernateUtil hibernateUtil;
	private Logger logger;
	
	public SectionDB(){
		hibernateUtil = getHibernateUtil();
	}
	/**
	 * it looks for the next sequence number to be assigned to the new section.
	 * @param session
	 * @param module
	 * @return sequence number
	 */
	private int assignSequenceNumber(Session session, Module module)
	{
	 int maxSeq= 1;
	 try
		{
	 	  //System.out.println("assign sequence to section query");
		   Query q=session.createQuery("select max(s.seqNo) from Section s where s.module =:module");
		   q.setEntity("module",module);
		   
   	  	  Integer maxsequence = (Integer)q.uniqueResult();
   		
		 // if no sequence is found then its first module.		 
		  if(maxsequence == null)
		  {
		   // System.out.println("first section");
		    return maxSeq ;
 		  }
			 maxSeq = maxsequence.intValue()+1;
		//	 System.out.println("section seq no will be" + maxSeq);
	     }
	     catch (HibernateException he)
	     {
			 logger.error(he.toString());
	     }
	    return maxSeq ;  			

	}
	/*
	 * This method moves the file from temp uploaded file to
	 * the right directory.The file is actually moved to the right spot at the time of saving
	 * so that if user uploads a file or creates content and after previewing and all
	 * cancels it. only when section is saved at that point save the file. 
	 * 
	 * revised by rashmi 03/15/05 to remove hard code of drive for FS.
	 * revised by rashmi 06/01/05 to check if file exists in meleteDocs/tempUpload
	 */
	private String storeContentFiles(String dataPath, String fileName, int seq, String modId, String sectionTitle)
	{
		try{
			File re;
			File parent = new File(dataPath);
			// create directory structure
			if(!parent.exists())
			{
				parent.mkdirs();
			}
			
			String homeDir = dataPath.substring(0,dataPath.indexOf("meleteDocs")-1);
			//System.out.println("home dir in section DB"+ homeDir);
			// new file name
			if(fileName == null)
			{
				fileName = new String("Section_" + seq +".html");
				String tempFileName = homeDir+File.separator+"uploads"+File.separator+modId+sectionTitle+".html";
				
		//			 file to move
				re = new File(tempFileName);
			}
			else  	// for uploaded file 
			{
				re = new File(homeDir+File.separator+"uploads"+File.separator+fileName);
				File re1 = new File(homeDir+File.separator+"meleteDocs"+File.separator+"tempUpload"+File.separator+fileName);
				if(re1.exists())
				{
					re1.delete();
				}
			}
		
			File f=new File(parent,fileName);
			// to overwrite for editor contents in case of edit
			if(f.exists())
			{
			//	System.out.println("file exists and deleting it");
				f.delete();			
			}
			// file actually moved to the right dir
			re.renameTo(f);
			return fileName;
			}catch(Exception e){logger.error(e.toString());return null;}
	}
	
	/**
	 * Add section sets the not-null values not been populated yet and then
	 * inserts the section into section table.
	 * update module witht his association to new added section 
	 * If error in committing transaction, it rollbacks the transaction.  
	 */
	public void addSection(Module module, Section section,String dataPath) throws MeleteException
	{
	//	logger.info("SectionDB:inserting section");
		try{
		     Session session = hibernateUtil.currentSession();
	         Transaction tx = null;
			try
			{
			  // set default values for not-null fields
			  section.setCreationDate(new java.util.Date());
			  section.setModificationDate(new java.util.Date());
			  section.setModuleId(module.getModuleId().intValue());
			  
			  // assign seq number
			  int seq=assignSequenceNumber(session,module);
			  section.setSeqNo(seq);
			  
			  if(section.getContentType().equals("typeUpload"))
			  {
			  	String path=section.getUploadPath();
			//  	System.out.println("upload file " + path);
			  	storeContentFiles(dataPath,path, seq, module.getModuleId().toString(), section.getTitle());
			  	section.setUploadPath(dataPath+path);
	//		  	logger.info("setting final upload path is " + section.getUploadPath());
			  }
			  else if(section.getContentType().equals("typeEditor"))
			  {
			  //set contentpath if content type is new 
			   String path = storeContentFiles(dataPath,null, seq, module.getModuleId().toString(), section.getTitle());
			   section.setContentPath(dataPath+path);
	//		   logger.info("setting final content path is " + section.getContentPath());
			  }
			  // save object
			  tx = session.beginTransaction();
			 // System.out.println("saving section");
			  session.save(section);
	//		  logger.info("after saving section");
			  
			  // associating section with module
			  List sections =module.getSections();
			  if(sections == null)
			  	sections = new ArrayList();
			  
			  // rashmi -- if need be , add seq-1 for index for sequencing list
			  sections.add(section);
			  module.setSections(sections);
		//	  System.out.println("setting sections of module");
			  session.saveOrUpdate(module);
		//	  logger.info("after saving or update module");
			  tx.commit();
			  logger.info("commiting transaction and new added section id:" + section.getModuleId() + ","+section.getTitle());
			  return ;
	        }
			catch(StaleObjectStateException sose)
		     {
				logger.error("stale object exception" + sose.toString());				
		     }
			catch(HibernateException he)
				     {
						if(tx !=null) tx.rollback();
						logger.error(he.toString());
						throw he;
				     }
	        	finally{
				hibernateUtil.closeSession();
				 }
		}catch(Exception ex){
				// Throw application specific error
			throw new MeleteException("add_section_fail");
			}
	}
	
	/*
	 * edit section....
	 * Revision - Rashmi 11/22/04
	 * correct the upload_path value for already uploaded file  
	 */
	
	public void editSection(Module module, Section section,String dataPath) throws MeleteException
	{
		try{
		     Session session = hibernateUtil.currentSession();
	         Transaction tx = null;
			try
			{
			  // set default values for not-null fields
			  section.setModificationDate(new java.util.Date());
						  
			 if(section.getContentType().equals("typeUpload"))
			  {
			  	String path=section.getUploadPath();
		//	  	System.out.println("upload file " + path);
			  	if(!(new File(path).exists()))
			  	{
		//	  		System.out.println("calling store content files in edit at sectiondb " + dataPath +","+path);
			  		storeContentFiles(dataPath,path, section.getSeqNo(), module.getModuleId().toString(), section.getTitle());
			  		section.setUploadPath(dataPath+path);
			   	} else {
			   		section.setUploadPath(path);
			   	}
			  	section.setContentPath(null);
			  	section.setLink(null);
			  }
			  else 
			  if(section.getContentType().equals("typeEditor"))
			  {
			  //set contentpath if content type is new 
			   String path = storeContentFiles(dataPath,null, section.getSeqNo(), module.getModuleId().toString(), section.getTitle());
			   section.setContentPath(dataPath+path);
			   section.setUploadPath(null);
			  	section.setLink(null);
			  }
			  else if(section.getContentType().equals("typeLink"))
			  {
			  	 section.setUploadPath(null);
			  	 section.setContentPath(null);
			  }
			  // save object
			  tx = session.beginTransaction();
	//		  System.out.println("saving section");
			  session.saveOrUpdate(section);
	//		  System.out.println("after saving section");
			  tx.commit();
			  logger.info("commit transaction and edit section :" + section.getModuleId() + ","+section.getTitle());
			  return ; 

	        }
			catch(StaleObjectStateException sose)
		     {
				if(tx !=null) tx.rollback();
				logger.error("stale object exception" + sose.toString());
				throw new MeleteException("edit_section_multiple_users");
		     }
			catch (HibernateException he)
				     {
						if(tx !=null) tx.rollback();
						logger.error(he.toString());
						he.printStackTrace();
						throw he;
				     }
	       	finally{
	       			hibernateUtil.closeSession();
				 	}
		}
		catch(MeleteException ex){
			// Throw application specific error
			throw ex;
		}
		catch(Exception ex){
				// Throw application specific error
			throw new MeleteException("add_section_fail");
			}
	}
	 public void deleteSection(Section sec) throws Exception
	 {
	 	Transaction tx = null;
	 	Session session = hibernateUtil.currentSession();
	 	try
		{
	      logger.info("coming to sectiondb: deleteSection");
	     
	          
	      tx = session.beginTransaction();

	      //Delete section
	      logger.info("Deleting section "+sec.getTitle());
	      String fileName=null;
	      if ((sec.getContentType().equals("typeEditor"))||(sec.getContentType().equals("typeUpload")))
	      {
	      	try
		    {
	      	
	      	if (sec.getContentType().equals("typeEditor"))
	      	{
	      		fileName = sec.getContentPath();
	      	}
	    	if (sec.getContentType().equals("typeUpload"))
	      	{
	      		fileName = sec.getUploadPath();
	      	}
	      		      	
	        File f=new File(fileName);
			// to overwrite for editor contents in case of edit
			if(f.exists())
			{
			//	System.out.println("file exists and deleting it");
				f.delete();		
				logger.info("Deleted file");
			}
		    }
	        catch (Exception e)
		    {
	      	logger.error(e.toString());
		    }
		  }
	      session.delete(sec);
	         
	      tx.commit();
	      logger.info("successfully deleted section");
	    }	 	
	    catch (HibernateException he)
	    {
	      if (tx!=null) tx.rollback();	
		  logger.info(he.toString());
		  throw he;
	    }	 
	    catch (Exception e) {
	      if (tx!=null) tx.rollback();
	      logger.info(e.toString());
	      throw e;
	    }
	    /*finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
		      	logger.info("Closing session after delete");
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
				  throw he;
			  }		    	
		}*/	
	    session.flush();
	    tx = null;
	    try
		{
	         
	      tx = session.beginTransaction();

	      String queryString = "from Section sec where sec.moduleId = :moduleId and sec.seqNo > :seqno";
	      Query query = session.createQuery(queryString);
	      query.setParameter("moduleId", new Integer(sec.getModuleId()));
	      query.setParameter("seqno",new Integer(sec.getSeqNo()));
	      //logger.info("Query created");
	      Iterator itr = query.iterate();
	      //logger.info("Iterating");
	      Section secObj = null;
	      while (itr.hasNext()) {
	      	//logger.info("Going thru loop");
	      	secObj = (Section) itr.next();
	      	//logger.info("Section title is "+secObj.getTitle());
	      	//logger.info("Section seq before is "+secObj.getSeqNo());
	      	secObj.setSeqNo(secObj.getSeqNo() - 1);
	      	//logger.info("Section seq after is "+secObj.getSeqNo());
	      	session.saveOrUpdate(secObj);
	      }
	      session.flush();
	      tx.commit();
	      logger.info("Completed updating sequence");
	     
	      
	    }	 	
	    catch (HibernateException he)
	    {
	      if (tx!=null) tx.rollback();	    	
		  logger.info(he.toString());
		  throw he;
	    }	 
	    catch (Exception e) {
	      if (tx!=null) tx.rollback();
	      logger.info(e.toString());
	      throw e;
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
		      	logger.info("Closing session after delete");
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
				  throw he;
			  }		    	
		}	      	    
	 }	
	 
	/*
	 * set the new seq number for the sections
	 * Revised by rashmi - to rename physical files with new seq number and set
	 * content path value to right filename
	 */
	public void updateSectionsSequence(List newSeqList)throws MeleteException
	{
		try{
		     Session session = hibernateUtil.currentSession();
		      Transaction tx = null;
		
		   try{
//		  		4a. begin transaction
   				tx = session.beginTransaction();
   			
	   		//	1.for each element of list
   				String parentDatapath =null;
   				File newparentDatapath = null; 
   				int modId=0;
		   	   for(int i=0; i < newSeqList.size(); i++ )
		   		{
		   	//	2.get section element and assign new seq
		   		Section section = (Section)newSeqList.get(i);
		   		
		   		section.setSeqNo(i+1);
		   		
		   		//added on 10-03-05 to change name of files as seq number changes
		   		
		 			if(section.getContentPath() != null)
		 			{
		 				if(parentDatapath ==null)
		 				{
		 					newparentDatapath = new File(new File(section.getContentPath()).getParent());
		 					parentDatapath = newparentDatapath.getParent();
		 					modId=section.getModuleId();
			 				}
		 				//Mallika - 1/13/06 - changing lines below to change filenames at file level
		 				//Setting content path without .bkup part
		 				//Mallika - comments beg
		 				/*String newPath = reSortFileName(section.getContentPath(), (i+1) , section.getModuleId());
		 				section.setContentPath(newPath);*/
		 				//Mallika - comments end
		 				//Mallika - new code beg
		 			    String newPath = bkupFileName(section.getContentPath(), (i+1) , section.getModuleId());
		 			    if (newPath != null)
		 			    {	
		 			      newPath = newPath.substring(0,newPath.length()-5);
		 			      section.setContentPath(newPath);
		 			    }
	 				    //Mallika - new code end
		 			}
		   	//3a		save all objects
		   			session.saveOrUpdate(section);
		   			logger.info("section updated");			   			
		   		}
		
               //Mallika - new code beg
		   	   //Iterate through all files in this directory and remove the .bkup extension
		   	   File moduleDir = newparentDatapath;
		   	   //logger.info("Mod dir is "+moduleDir.getAbsolutePath());
		   	   String[] fileNames = moduleDir.list();
		   	   if (fileNames != null)
		   	   {
		         for (int i=0; i<fileNames.length; i++) {
		            // Get filename of file or directory
		            String filename = fileNames[i];
		            if (filename.endsWith(".bkup"))
		            {	
		              File origFile = new File(moduleDir.getAbsolutePath()+File.separator+filename);
		              //logger.info("FILENAME BFOR "+filename);
		              String new_filename = filename.substring(0,filename.length()-5);
		              //logger.info("FILENAME AFTER "+new_filename);
		              File newFile = new File(moduleDir.getAbsolutePath()+File.separator+new_filename);
		              boolean res = origFile.renameTo(newFile);
		              if (res == false)
		    		  {
		    			logger.error("File rename FAILED in the updateSectionsSequence method of SectionDB");
		    		  }
		            }
		         }
		   	   }
   	   
		   	   //Mallika - new code end
	   	   
		   	   // if sorting involved physical files then delete existing module directory
		   	   // and move sort folder to module folder
		   	   //Mallika - comments beg
		   	   /*if(parentDatapath != null)
		   	   {
		   	   		File bringitback = new File(parentDatapath,new String("sort"+modId));
		   	   		if(bringitback.exists())
		   	   		{
		   	   			newparentDatapath.delete();
		   	   			bringitback.renameTo(newparentDatapath);
		   	   		}
		   	   }*/
		   	   //Mallika - comments end
//		   	4b.commit transaction
				tx.commit();
		   		logger.info("newSeqList success");
	   			return ; 
		     }
		     catch (HibernateException he)
		     {
				if(tx !=null) tx.rollback();
				logger.error("error in section seq save"+he.toString());
				throw new MeleteException(he.toString());
		     }
		
		} catch (Exception e)
	     {
			 logger.info(e.toString());
			 throw new MeleteException(e.toString());
	     }
	     finally
			{
		    	try
				  {
			      	hibernateUtil.closeSession();
				  }
			      catch (HibernateException he)
				  {
					  logger.info(he.toString());
				  }		    	
			}
	}
	/*
	 * this method stores the sorted files in new sequence under temp directory
	 * sortModuleId.
	 * Returns the new name of the file with correct sequence number 
	 */
	private String reSortFileName(String filename, int newSeqNo, int ModId)
	{
		File changefile = new File(filename);
		String tempParentName = changefile.getParent();
		String newname = tempParentName +File.separator + "Section_" + newSeqNo+".html";
		tempParentName = new File(changefile.getParent()).getParent();
		System.out.println("CREATing sort directory at " + tempParentName );
		File tempParent = new File(tempParentName, new String("sort"+ModId));
		if(!tempParent.exists())
		{
			tempParent.mkdirs();
		}
		
		File changefileTo = new File(tempParent.getAbsolutePath(), new String("Section_" + newSeqNo+".html"));
	//	System.out.println("CHANGEfile var :"+ changefile.getPath() + "changefileto var :"+ changefileTo.getPath());
		changefile.renameTo(changefileTo);
		return newname;
	}
	
	//Mallika - 2/10/06 - new method to rename each file name to Section_<newSeqNo>.html.bkup
	//in same directory
	private String bkupFileName(String filename, int newSeqNo, int ModId)
	{
		File changefile = new File(filename);
		String tempParentName = changefile.getParent();
		String newname = tempParentName +File.separator + "Section_" + newSeqNo+".html.bkup";
		File changefileTo = new File(newname);
	//	System.out.println("CHANGEfile var :"+ changefile.getPath() + "changefileto var :"+ changefileTo.getPath());
		boolean res = changefile.renameTo(changefileTo);
		if (res == false)
		{
			logger.error("File rename FAILED in the bkupFileName method of SectionDB");
			return null;
		}
		else
		{	
		  return newname;
		}
	}	
	
	
	/**
	 * @return Returns the hibernateUtil.
	 */
	public HibernateUtil getHibernateUtil() {
		return hibernateUtil;
	}
	/**
	 * @param hibernateUtil The hibernateUtil to set.
	 */
	public void setHibernateUtil(HibernateUtil hibernateUtil) {
		this.hibernateUtil = hibernateUtil;
	}
	/**
	 * @return Returns the logger.
	 */
	public Logger getLogger() {
		return logger;
	}
	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
}