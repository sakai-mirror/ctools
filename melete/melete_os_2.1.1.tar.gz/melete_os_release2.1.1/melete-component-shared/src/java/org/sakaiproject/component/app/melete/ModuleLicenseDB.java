/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-component-shared/src/java/org/sakaiproject/component/app/melete/ModuleLicenseDB.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.sakaiproject.service.framework.log.Logger;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.Transaction;
/*
 *  @author Rashmi
 *
 */

public class ModuleLicenseDB implements Serializable{
	ArrayList licenseTypes;
	private HibernateUtil hibernateUtil;
	private Logger logger;
	
	public ModuleLicenseDB(){}
	public ArrayList getLicenseTypes()
	{
		ArrayList licenseTypes = new ArrayList(); 
	  	try
		{
	  // System.out.println("ModuleLicenseDB:getsession");		
	    Session session = getHibernateUtil().currentSession();
       //System.out.println("modulelicense DB after getting session:");	

	    StringBuffer query = new StringBuffer();
	    query.append("from ModuleLicense");
	    List types = session.find(query.toString());
	      
	    ListIterator itr = types.listIterator();
	   
	      while(itr.hasNext())
			{
		       ModuleLicense moduleLicense = (ModuleLicense)itr.next();
			 licenseTypes.add(moduleLicense);
		   // 	 System.out.println("types :" + moduleLicense.getCode() + "," + moduleLicense.getDescription() );
	         	 }    
	      getHibernateUtil().closeSession();
	     }
	     catch (HibernateException he)
	     {
			 logger.error(he.toString());
			// he.printStackTrace();
	     }
		
	     return licenseTypes;
	}
	
	/**
	 * fetches ccLicense
	 * @return
	 */
	public List getCcLicense() {
		ArrayList ccLicenceList = new ArrayList();
		try {
			Session session = getHibernateUtil().currentSession();

			StringBuffer query = new StringBuffer();
			query.append("from CcLicense");
			List ccLicList = session.find(query.toString());

			ListIterator itr = ccLicList.listIterator();

			while (itr.hasNext()) {
				CcLicense ccLicense = (CcLicense) itr.next();
				ccLicenceList.add(ccLicense);

			}
			getHibernateUtil().closeSession();
		} catch (HibernateException he) {
			logger.error(this + he.toString());
		}

		return ccLicenceList;
	}
	

	
	/**
	 * creates CcLicense
	 * 
	 * @param ccLicense -
	 *            CcLicence
	 */
	public void createCcLicense(CcLicense ccLicense)
	{
		logger.debug("Entering createCcLicense");
		saveData(ccLicense);
		logger.debug("Exiting createCcLicense");
	}
	
	
	/**
	 * creates ModuleLicense
	 * 
	 * @param moduleLicense -
	 *            ModuleLicense
	 */
	public void createModuleLicense(ModuleLicense moduleLicense)
	{
		logger.debug("Entering createModuleLicense");
		saveData(moduleLicense);
		logger.debug("Exiting createModuleLicense");
	}
	
	
	/**
	 * @param obj
	 */
	private void saveData(Object obj) {
		Transaction tx = null;
		try
		{
		     Session session = hibernateUtil.currentSession();
	         
	         tx = session.beginTransaction();
	         session.save(obj);
	         tx.commit();
		}catch(HibernateException he)
		{
			try {
				if(tx !=null) 
					tx.rollback();
			} catch (HibernateException e) {
				logger.error(e.toString());
			}
			logger.error(he.toString());
		}finally
		{
			try {
				hibernateUtil.closeSession();
			} catch (HibernateException e) {
				logger.error(e.toString());
			}
		 }
	}
	/**
	 * @return Returns the hibernateUtil.
	 */
	public HibernateUtil getHibernateUtil() {
		return hibernateUtil;
	}
	/**
	 * @param hibernateUtil The hibernateUtil to set.
	 */
	public void setHibernateUtil(HibernateUtil hibernateUtil) {
		this.hibernateUtil = hibernateUtil;
	}
	/**
	 * @return Returns the logger.
	 */
	public Logger getLogger() {
		return logger;
	}
	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
}