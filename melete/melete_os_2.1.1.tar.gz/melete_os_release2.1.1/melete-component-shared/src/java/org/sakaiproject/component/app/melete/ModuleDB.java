/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-component-shared/src/java/org/sakaiproject/component/app/melete/ModuleDB.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/

package org.sakaiproject.component.app.melete;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import net.sf.hibernate.Hibernate;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Query;
import net.sf.hibernate.Session;
import net.sf.hibernate.StaleObjectStateException;
import net.sf.hibernate.Transaction;
import net.sf.hibernate.type.Type;

import org.sakaiproject.service.framework.log.Logger;

/*
 * modified by rashmi - 3/8 to get archived modules sort by date.
 * Murthy 03/08/05 --  set modification date commented in addModule method
 * Mallika - 3/22/05 - Added methods for moduledatebeanservice
 * Mallika - 3/28/05 - Catching MeleteException in updateModuleDateBean
 * module listing for sort modules added by rashmi - 4/20
 * Rashmi 4/22 methods to get coursemodules list and save the new seq - sort modules
 * Mallika - 5/2/05 - added functionality to delete module directory
 * Mallika - 5/18/05 - added truncTitle to sectionBean
 * Rashmi - 6/9/05 - remove term from archive module
 * Rashmi - 6/14/05 - revised if condition in assign seq number
 * Rashmi - 07/07/07 - removed season and yr from method signature
 */

public class ModuleDB implements Serializable {
	private String ccLicenseURL;
	private String ccLicenseName;
	private int seqNumber;
	private HibernateUtil hibernateUtil;
	/** Dependency:  The logging service. */
	protected Logger logger = null;

	/**
	 *
	 */
	public ModuleDB()
	{
		if(hibernateUtil == null)getHibernateUtil();
	}

	/**
	 *
	 * Description:
	 */
	public static ModuleDB getModuleDB()
	{
		return new ModuleDB();
	}
	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
    // rashmi stuff
	/**
	 * called from backing bean addModulePage to get the license url and license name
	 * @param reqAttr
	 * @param allowCmrcl
	 * @param allowMod
	 * @return
	 */
	public String[] fetchCcLicenseURL(Boolean reqAttr, Boolean allowCmrcl, Integer allowMod)
	{
		String[] licenseInfo = new String[2];
		try{
			logger.info("Moduledb:fetchCcLicenseURL" + hibernateUtil);
		     Session session = getHibernateUtil().currentSession();
			 fetchCcLicenseURL(session ,reqAttr, allowCmrcl, allowMod);
	         licenseInfo[0]=ccLicenseURL;
		     licenseInfo[1]=ccLicenseName;
		     getHibernateUtil().closeSession();
		} catch(Exception ex)
		{
			//ex.printStackTrace();
			logger.error(ex.toString());
			}
		return licenseInfo;
	}

	/**
	 * intennal call to this function.
	 * @param session
	 * @param reqAttr
	 * @param allowCmrcl
	 * @param allowMod
	 */
	public void fetchCcLicenseURL(Session session , Boolean reqAttr, Boolean allowCmrcl, Integer allowMod)
	{
	  try
		{
		  StringBuffer query = new StringBuffer();

		  query.append("Select ccl from CcLicense ccl where ccl.reqAttr=? ");
	 	  query.append(" and ccl.allowCmrcl=? and ccl.allowMod=? ");
		  Object args[] = {reqAttr,allowCmrcl,allowMod};

		  Type types[] ={Hibernate.BOOLEAN, Hibernate.BOOLEAN, Hibernate.INTEGER};
		  List urls= session.find(query.toString(), args, types);
		  // fire query
		  CcLicense Cc = (CcLicense)urls.get(0);
		  ccLicenseURL =Cc.getUrl();
		  ccLicenseName = Cc.getName();

		  logger.info("fetched license url is: " + ccLicenseURL + "ccLicenseName" + ccLicenseName );

		  return;
	     }
	     catch (HibernateException he)
	     {
			 logger.error(he.toString());
	     }
	}


	    /**
	   * assign sequence number to the new module.
	 * if no sequence number is found in course module table for given courseId
	 * assume that its a first module.
	 * @param session
	 * @param course
	 * @return
	 */
	private int assignSequenceNumber(Session session, String courseId)
	{
	 int maxSeq= 1;
	 try
		{
		   Query q=session.createQuery("select max(cm.seqNo) from CourseModule cm where cm.courseId =:courseId");
		   q.setParameter("courseId",courseId);
		   Integer maxsequence = (Integer)q.uniqueResult();


		   // if no sequence is found then its first module.
		  if(maxsequence == null || maxsequence.intValue() <= 0)
		  {
		    logger.info("first module ");
		    return maxSeq ;
 		  }
		 logger.info("assignSequence ni=umber:"+ maxsequence);
		 maxSeq = maxsequence.intValue()+1;

	     }
	     catch (HibernateException he)
	     {
			 logger.error(he.toString());
			 //he.printStackTrace();
	     }
	    return maxSeq ;

	}

	   /**
	 * Actually inserts a row with module information.
	 * adds a row in module , moduleshdates , course module.
	 * if a transaction fails , rollback the whole transaction.
	 *
	 * @param module
	 * @param moduleshowdates
	 * @param course
	 *
	 * Revised by rashmi on 1/21/05 -- to associate coursemodule with module
	 * Murthy 03/08/05 --  set modification date commented
	 * Rashmi - 07/07/07 - removed season and yr from method signature
	 */
	public void addModule(Module module, ModuleShdates moduleshowdates, String userId, String courseId)
	{
	logger.info("db level add module called");

	try{
	     Session session = hibernateUtil.currentSession();
           Transaction tx = null;

		try
		{
		  module.setCreationDate(new java.util.Date());
		  module.setUserId(userId);
		  //module.setModificationDate(new java.util.Date());

		  // find course
//		   String q=new String("Select c from Course c where c.courseId ='" + courseId+"'");
//		   List courses = session.find(q);
//		   Course course = (Course)courses.get(0);


    		// assign sequence number
		  int seq = assignSequenceNumber(session, courseId);

		  moduleshowdates.setModule(module);

		  tx = session.beginTransaction();
             // save module
		logger.info("saving module");
		 session.save(module);
		logger.info("after saving module");
		// save module show dates

		logger.info("saving moduleshowdates");

		 session.save(moduleshowdates);
		logger.info("saved moduleshowdates");

		//create instance of coursemodules
		 CourseModule coursemodule = new CourseModule();
		 coursemodule.setCourseId(courseId);


		 coursemodule.setModule(module);
  		 coursemodule.setSeqNo(seq);

		// save course module
		logger.info("saving coursemodule");
 		 session.save(coursemodule);
		logger.info("saved coursemodule");

		 /*Set cms = module.getCoursemodules();
		 if(cms == null) cms = new HashSet();
		 cms.add(coursemodule);
		 module.setCoursemodules(cms);*/

		 CourseModule cms = (CourseModule)module.getCoursemodule();
		 if (cms == null)
		 {
		 	cms = coursemodule;
		 }
		 module.setCoursemodule(cms);

		 session.saveOrUpdate(module);

		  tx.commit();
		logger.info("new added module id:" + module.getModuleId() + ","+module.getTitle());
		  return ;

	     }
	     catch (HibernateException he)
	     {
			if(tx !=null) tx.rollback();
			logger.error(he.toString());
			//he.printStackTrace();
			throw he;
	     }
		finally{
		hibernateUtil.closeSession();
		 }
	}catch(Exception ex){
   // Throw application specific error
		logger.error("error at module db level");
		//ex.printStackTrace();
	}
  }

   // end rashmi stuff
	public List getModulesDatesPrivsForStudents(String userId, String courseId) throws HibernateException {
		List moduleDatePrivBeansList = new ArrayList();
	 	List modList = null;
	 	ModuleDatePrivBean mdpBean = null;
	 	Module mod = null;
	 	CourseModule cmod = null;
	 	ModuleStudentPrivs msPriv = null;
	 	ModuleShdates mDate = null;
	 	List sectionList = null;
	 	List sectionBeanList = null;
	 	Date currentDate = Calendar.getInstance().getTime();
	 	try
		{
	      logger.info("coming to moduledb:getModulesDatesPrivsForStudents ");
	      Session session = hibernateUtil.currentSession();
	      modList = getStudentModules(userId,courseId);
	      Iterator i = modList.iterator();
	      while (i.hasNext()) {
	      	mdpBean = new ModuleDatePrivBean();

	      	Object[] pair = (Object[]) i.next();
	        mod = (Module) pair[0];
	        mdpBean.setModuleId(mod.getModuleId().intValue());
	      	mdpBean.setModule((Module)mod);
	        mDate = (ModuleShdates) pair[1];
	        mdpBean.setModuleShdate(mDate);
	        cmod = (CourseModule) pair[2];
	        mdpBean.setCmod(cmod);
	        mdpBean.setTruncTitle(createTruncstr(mod.getTitle()));
		   	if (mod.getModulestudentprivs() != null)
	        {
	          if (mod.getModulestudentprivs().size() == 1)
		      {
		        for (Iterator l = mod.getModulestudentprivs().iterator(); l.hasNext(); )
		        {
		          logger.info("Associating module student priv object for this module ");
		    	  mdpBean.setModuleStudentPriv((ModuleStudentPrivs) l.next());
		        }
		      }
	        }

		   	sectionList = mod.getSections();
		   	//logger.info("Section list size is "+sectionList.size());
		   	if (sectionList != null)
		   	{
		   		if (sectionList.size() > 0)
		   		{
		      	sectionBeanList = new ArrayList();
		      	for (ListIterator k = sectionList.listIterator(); k.hasNext(); ){
		      		Section sec = (Section)k.next();


		      		//if (mod.getModuleId().intValue() == 32769)
		      		//Null section in list being eliminated
					if (sec != null)
		      		{
		      			/*logger.info("Sec title is "+sec.getTitle());
		      			logger.info("Sec mod id is "+sec.getModuleId());
		      			logger.info("Sec seq no is "+sec.getSeqNo());*/
						SectionBean secBean = new SectionBean(sec);
						secBean.setTruncTitle(createTruncstr(sec.getTitle()));
		      			sectionBeanList.add(secBean);
		      		}


		      	}

		      	//logger.info("Section bean list size is "+sectionBeanList.size());
		      	mdpBean.setSectionBeans(sectionBeanList);
		   		}
		   	}
	      	//logger.info("For module "+mod.getModuleId().intValue());
	        //logger.info("Section size is "+mod.getSections().size());
	        //logger.info("Date object is "+mod.getModuleshdates());
	        //logger.info("Start Date is "+mDate.getStartDate());
	        //logger.info("End Date is "+mDate.getEndDate());
	        //logger.info("Hide Flag is "+mDate.isHideFlag());
	        //logger.info("Course seq is "+cmod.getSeqNo());
	        //logger.info("Course mod size is "+mod.getCoursemodules().size());


	       moduleDatePrivBeansList.add(mdpBean);

	      	mod = null;
	      	cmod = null;
	      	msPriv = null;
	      	mDate = null;

	      }
	      //logger.info("moduleDatePrivBeansList = " + moduleDatePrivBeansList);

	    }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
	    }
	    finally
		{
	      try
		  {
	      	hibernateUtil.closeSession();
		  }
	      catch (HibernateException he)
		  {
			  logger.error(he.toString());
		  }
		}
	    return moduleDatePrivBeansList;
	}

	 public List getShownModulesAndDatesForInstructor(String courseId) throws HibernateException {
	 	List moduleDateBeansList = new ArrayList();
	 	List modList = null;
	 	ModuleDateBean mdBean = null;
	 	Module mod = null;
	 	ModuleShdates mDate = null;
	 	CourseModule cmod = null;
	    List sectionList = null;
	 	List sectionBeanList = null;
	 	try
		{
	      logger.info("coming to moduledb:getShownModulesAndDatesForInstructor ");
	      Session session = hibernateUtil.currentSession();
	      logger.info("got session");
	      modList = getModules(courseId);
	      Iterator i = modList.iterator();
	      while (i.hasNext()) {
	      	mdBean = new ModuleDateBean();
	      	Object[] pair = (Object[]) i.next();
	        mod = (Module) pair[0];
	        mdBean.setModuleId(mod.getModuleId().intValue());
		    mdBean.setModule((Module)mod);
	        mDate = (ModuleShdates) pair[1];
	        mdBean.setModuleShdate(mDate);
	        cmod = (CourseModule) pair[2];
	        mdBean.setCmod(cmod);
	        mdBean.setTruncTitle(createTruncstr(mod.getTitle()));
		   	sectionList = mod.getSections();

		   	if (sectionList != null)
		   	{
		   		if (sectionList.size() > 0)
		   		{
		   		sectionBeanList = new ArrayList();
		      	for (ListIterator k = sectionList.listIterator(); k.hasNext(); ){
		      		Section sec = (Section)k.next();


		      		//if (mod.getModuleId().intValue() == 32769)
		      		//Null section in list being eliminated
					if (sec != null)
		      		{
		      			/*logger.info("Sec title is "+sec.getTitle());
		      			logger.info("Sec mod id is "+sec.getModuleId());
		      			logger.info("Sec seq no is "+sec.getSeqNo());*/
						SectionBean secBean = new SectionBean(sec);
						secBean.setTruncTitle(createTruncstr(sec.getTitle()));
		      			sectionBeanList.add(secBean);
		      		}

		      	}
		      	//logger.info("Section bean list size is "+sectionBeanList.size());
		      	mdBean.setSectionBeans(sectionBeanList);
		   		}
		   	}
		   	//logger.info("For module "+mod.getModuleId().intValue());
	        //logger.info("Section size is "+mod.getSections().size());
	        //logger.info("Date object is "+mod.getModuleshdates());
	        //logger.info("Start Date is "+mDate.getStartDate());
	        //logger.info("End Date is "+mDate.getEndDate());
	        //logger.info("Course seq is "+cmod.getSeqNo());
		    moduleDateBeansList.add(mdBean);

	      	mod = null;
	      	cmod = null;
	      	mDate = null;
  	        sectionList = null;
	      	sectionBeanList = null;

	      }
	      //logger.info("moduleDateBeansList = " + moduleDateBeansList);

	    }
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
	    	  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
			  }
		}
	    return moduleDateBeansList;

	  }

	 public List getModules(String courseId) throws HibernateException {
	 	List modList = new ArrayList();
	 	List sectionsList = null;
	 	Module mod = null;
	 	Query sectionQuery = null;
	 	try
		{
	      logger.info("coming to moduledb: getModules");
	      Session session = hibernateUtil.currentSession();
	      //logger.info("After hibutil");
	      String queryString = "from Module module join module.moduleshdate mshdates join module.coursemodule cmods where cmods.courseId = :courseId  and cmods.archvFlag = 0 order by cmods.seqNo";
	      Query query = session.createQuery(queryString);
	      query.setParameter("courseId", courseId);
	      //logger.info("Query created");
	      modList = query.list();
	      //logger.info("moduleList = " + modList);

	    }
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
			  }
		}
	    return modList;
	  }
//
	 public ModuleDateBean getModuleDateBean(String courseId,  int moduleId) throws HibernateException {
	 	List modList = new ArrayList();
	 	List sectionList = null;
	 	List sectionBeanList = null;
	 	Module mod = null;
	 	ModuleShdates mDate = null;
	 	CourseModule cmod = null;
	 	Query sectionQuery = null;
	 	ModuleDateBean mdBean = null;
	 	try
		{
	      logger.info("coming to moduledb: getModuledatebean");
	      Session session = hibernateUtil.currentSession();
	      //logger.info("After hibutil");
	      String queryString = "from Module module join module.moduleshdate mshdates join module.coursemodule cmods where module.moduleId = :moduleId and cmods.courseId = :courseId  and cmods.archvFlag = 0 order by cmods.seqNo";
	      Query query = session.createQuery(queryString);
	      query.setParameter("moduleId", new Integer(moduleId));
	      query.setParameter("courseId", courseId);
	      //logger.info("Query created");
	      modList = query.list();
	      Iterator i = modList.iterator();
	      while (i.hasNext()) {
	        mdBean = new ModuleDateBean();
	      	Object[] pair = (Object[]) i.next();
	        mod = (Module) pair[0];
	        mdBean.setModuleId(mod.getModuleId().intValue());
		    mdBean.setModule((Module)mod);
	        mDate = (ModuleShdates) pair[1];
	        mdBean.setModuleShdate(mDate);
	        cmod = (CourseModule) pair[2];
	        mdBean.setCmod(cmod);
	        mdBean.setTruncTitle(createTruncstr(mod.getTitle()));
		   	sectionList = mod.getSections();
		   	//logger.info("Section list size is "+sectionList.size());
		   	if (sectionList != null)
		   	{
		   		if (sectionList.size() > 0)
		   		{
		   		sectionBeanList = new ArrayList();
		      	for (ListIterator k = sectionList.listIterator(); k.hasNext(); ){
		      		Section sec = (Section)k.next();
		   //   		logger.info("Sec is "+sec);

		      		//if (mod.getModuleId().intValue() == 32769)
		      		//Null section in list being eliminated
					if (sec != null)
		      		{
		      			/*logger.info("Sec title is "+sec.getTitle());
		      			logger.info("Sec mod id is "+sec.getModuleId());
		      			logger.info("Sec seq no is "+sec.getSeqNo());*/
						SectionBean secBean = new SectionBean(sec);
						secBean.setTruncTitle(createTruncstr(sec.getTitle()));
		      			sectionBeanList.add(secBean);
		      		}

		      	}
		      	//logger.info("Section bean list size is "+sectionBeanList.size());
		      	mdBean.setSectionBeans(sectionBeanList);
		   		}
	      //logger.info("moduleList = " + modList);
		   	}
	      }
		}
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
			  }
		}
	    return mdBean;
	  }

	 public List getStudentModules(String userId,String courseId) throws HibernateException {
	 	List modList = new ArrayList();
	 	List sectionsList = null;
	 	Module mod = null;
	 	Query sectionQuery = null;
	 	try
		{
	      logger.info("coming to moduledb: getStudentModules  courseId:"+courseId);
	      Session session = hibernateUtil.currentSession();
	      //logger.info("After hibutil");
	      String queryString = "from Module module join module.moduleshdate mshdates join module.coursemodule cmods where mshdates.hideFlag = :hfval and cmods.courseId = :courseId and cmods.archvFlag = 0 order by cmods.seqNo";

	      Query query = session.createQuery(queryString);
	      query.setParameter("courseId",courseId);
	      query.setParameter("hfval", new Boolean(false));
	      logger.info("Query created");
	      modList = query.list();
	      logger.info("moduleList = " + modList);

	    }
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
			  }
		}
	    return modList;
	  }

	 public ModuleStudentPrivs getModulePrivs(String userId, String courseId, int moduleId)
	 {
	 	ModuleStudentPrivs msPriv = null;
	 	try
		{
	      logger.info("coming to moduledb: getModulePrivs moduleId:"+moduleId);
	      Session session = hibernateUtil.currentSession();
	      //logger.info("After hibutil");
	        String queryString =  "select modulestudentpriv from ModuleStudentPrivs as modulestudentpriv where " +
    		"modulestudentpriv.student.studentId = :studentId and modulestudentpriv.courseId = :courseId and " +
    		"modulestudentpriv.module.moduleId = :moduleId and " +
			"(modulestudentpriv.deny = 'N' or modulestudentpriv.deny = '')";
          Query query =
	      session.createQuery(queryString);
          query.setParameter("studentId", userId);
          query.setParameter("courseId", courseId);
          query.setParameter("moduleId", new Integer(moduleId));

	      //logger.info("Query created in getModulePrivs");
	      Iterator itr = query.iterate();
	      //logger.info("Iterating");
	      while (itr.hasNext()) {
	      	//logger.info("Going thru loop");
	      	msPriv = (ModuleStudentPrivs) itr.next();
	      }
	      //logger.info("ModuleStudentPrivs = " + msPriv);

	    }
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
			  }
		}
	    return msPriv;
	 }
	 public ModuleShdates getShownModuleDates(int moduleId) throws HibernateException
	 {
	  	ModuleShdates mDate = null;
	 	try
		{
	      logger.info("coming to moduledb: getShownModuleDates moduleId:"+moduleId);
	      Session session = hibernateUtil.currentSession();
	      //logger.info("After hibutil");
	       String queryString =  "select moduleshdate from ModuleShdates as moduleshdate where moduleshdate.module.moduleId = :moduleId";
	      Query query =
		  session.createQuery(queryString);
	      query.setParameter("moduleId", new Integer(moduleId));

	      //logger.info("Query created in getshownmoduledates");
	      Iterator itr = query.iterate();
	      //logger.info("Iterating");
	      while (itr.hasNext()) {
	      	//logger.info("Going thru loop");
	      	mDate = (ModuleShdates) itr.next();
	      }
	     logger.info("ModuleShdates = " + mDate);

	    }
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
			  }
		}
	    return mDate;
	 }
	 public CourseModule getCourseModule(int moduleId, String courseId) throws HibernateException
	 {
	  	CourseModule cmod = null;
	 	try
		{
	      logger.info("coming to moduledb: getCourseModule moduleId:"+moduleId+" course id:"+courseId);
	      Session session = hibernateUtil.currentSession();
	      //logger.info("After hibutil");
	      String queryString =  "select cmod from CourseModule as cmod where cmod.module.moduleId = :moduleId  and cmod.courseId = :courseId";
	      Query query =
		  session.createQuery(queryString);
	      query.setParameter("moduleId", new Integer(moduleId));
	      query.setParameter("courseId", courseId);
	      //logger.info("Query created in getshownmoduledates");
	      Iterator itr = query.iterate();
	      //logger.info("Iterating");
	      while (itr.hasNext()) {
	      	//logger.info("Going thru loop");
	      	cmod = (CourseModule) itr.next();
	      }
	     logger.info("CourseModule = " + cmod);

	    }
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
			  }
		}
	    return cmod;
	 }
	 public void updateModuleDateBeans(List moduleDateBeans) throws Exception {
	 	for (ListIterator i = moduleDateBeans.listIterator(); i.hasNext(); ) {
	        ModuleDateBean mdbean = (ModuleDateBean) i.next();
	        try
			{
	          if (mdbean.isDateFlag() == false)
	          {
	            updateModuleDateBean(mdbean);
	          }
			}
	        catch (Exception e)
			{
	        	//e.printStackTrace();
	        	logger.error(e.toString());
	        	throw e;
			}
	        //logger.info("secs is "+mdbean.getModule().getSections());
  		}
	 }
	 public void updateModuleDateBean(ModuleDateBean mdbean)throws Exception
	 {
	 	Transaction tx = null;
	 	try
		{
	      logger.info("coming to moduledb: updateModuleDateBean");

	      Session session = hibernateUtil.currentSession();

	      tx = session.beginTransaction();

	      //Update module properties
	      session.saveOrUpdate(mdbean.getModule());

//	    Getting the set of show hides dates associated with this module
	      ModuleShdates mshdates = (ModuleShdates) mdbean.getModule().getModuleshdate();

	    	logger.info("Start date is "+mdbean.getModuleShdate().getStartDate());
        	logger.info("End date is "+mdbean.getModuleShdate().getEndDate());
        	mshdates.setStartDate(mdbean.getModuleShdate().getStartDate());
        	mshdates.setEndDate(mdbean.getModuleShdate().getEndDate());
        	logger.info("Set Start date is "+mshdates.getStartDate());
        	logger.info("Set End date is "+mshdates.getEndDate());

        	session.saveOrUpdate(mshdates);



	      //Getting the set of show hides dates associated with this module
	   /*   Set mdset = mdbean.getModule().getModuleshdates();
	      //logger.info("Module date set is "+mdset);
	      for (Iterator i = mdset.iterator(); i.hasNext(); ) {
	        ModuleShdates mshdates = (ModuleShdates) i.next();
	    	logger.info("Start date is "+mdbean.getModuleShdate().getStartDate());
	        	logger.info("End date is "+mdbean.getModuleShdate().getEndDate());
	        	mshdates.setStartDate(mdbean.getModuleShdate().getStartDate());
	        	mshdates.setEndDate(mdbean.getModuleShdate().getEndDate());
	        	logger.info("Set Start date is "+mshdates.getStartDate());
	        	logger.info("Set End date is "+mshdates.getEndDate());

	        	session.saveOrUpdate(mshdates);


	        logger.info("Iterating");
  		  }*/
	      tx.commit();

	      //session.flush();

	    }
	 	catch(StaleObjectStateException sose)
	     {
			if(tx !=null) tx.rollback();
			logger.info("stale object exception" + sose.toString());
			throw new MeleteException("edit_module_multiple_users");
	     }
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
		  throw he;
	    }
	    catch (Exception e) {
	      if (tx!=null) tx.rollback();
	      logger.info(e.toString());
	      throw e;
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
				  throw he;
			  }
		}
	 }
	 public static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            if (children.length == 0)
            {
            	dir.delete();
            	return true;
            }
            else
            {
              for (int i=0; i<children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
              }
            }
        }

        // The directory is now empty so delete it
        return dir.delete();
    }

	 public void deleteModule(ModuleDateBean mdbean, String dataPath) throws Exception
	 {
	 	Transaction tx = null;
	 	try
		{
	      logger.info("coming to moduledb: deleteModule");
	      Session session = hibernateUtil.currentSession();

	      tx = session.beginTransaction();

	      //Delete module properties
	      logger.info("Deleting module "+mdbean.getModule().getTitle());
	      boolean delSuccess = deleteDir(new File(dataPath));
	      logger.info("Dir delete success is "+delSuccess);



	      //Adding these lines to also delete corresponding coursemodule and moduleshdate entry
	      session.delete(mdbean.getModule().getCoursemodule());
	      session.delete(mdbean.getModule().getModuleshdate());


          session.delete(mdbean.getModule());

	      logger.info("successfully deleted module");
	      String queryString = "from CourseModule cmod where cmod.courseId = :courseId and cmod.seqNo > :seqno";
	      Query query = session.createQuery(queryString);
	      query.setParameter("courseId",mdbean.getCmod().getCourseId());
	      query.setParameter("seqno",new Integer(mdbean.getCmod().getSeqNo()));
	      //logger.info("Query created");
	      Iterator itr = query.iterate();
	      //logger.info("Iterating");
	      CourseModule cmod = null;
	      while (itr.hasNext()) {
	      	//logger.info("Going thru loop");
	      	cmod = (CourseModule) itr.next();
	      	cmod.setSeqNo(cmod.getSeqNo() - 1);
	      	session.saveOrUpdate(cmod);
	      }
	      tx.commit();
	      logger.info("Completed updating sequence");
	    }
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
		  throw he;
	    }
	    catch (Exception e) {
	      if (tx!=null) tx.rollback();
	      logger.info(e.toString());
	      throw e;
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
		      	logger.info("Closing session after delete");
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
				  throw he;
			  }
		}
	 }

	 public Module getModule(int moduleId) throws HibernateException {
	 	Module mod = null;
	 	try
		{
	 		//logger.info("Coming to moduledb: getModule");
	 		Session session = hibernateUtil.currentSession();
	 		String queryString = "select module from Module as module where module.moduleId = :moduleId";
	 		Query query = session.createQuery(queryString);
	 		query.setParameter("moduleId", new Integer(moduleId));
	 		Iterator itr = query.iterate();
	 		while (itr.hasNext()){
	 			mod = (Module) itr.next();
	 		}
	 		//logger.info("Coming to moduledb: getModule" + mod.getTitle());

	    }
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
			  }
		}
	    return mod;
	 }

	 public List getSections(int moduleId) throws HibernateException {
	 	List sectionsList = new ArrayList();
	 	Module mod = null;
	 	Query sectionQuery = null;
	 	try
		{
	      logger.info("coming to moduledb: getSections");
	      Session session = hibernateUtil.currentSession();
	      //logger.info("After hibutil");
	      String queryString = "select section from Section as section where section.moduleId = :moduleId order by section.seqNo";
	      Query query = session.createQuery(queryString);
	      query.setParameter("moduleId", new Integer(moduleId));
	      //logger.info("Query created");
	      sectionsList = query.list();
	      //logger.info("moduleList = " + modList);

	    }
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
			  }
		}
	    return sectionsList;
	  }

	 public Section getSection(int moduleId, int seqNo) throws HibernateException {
	 	Section sec = null;
	 	try
		{
	 		logger.info("Coming to moduledb: getSection");
	 		Session session = hibernateUtil.currentSession();
	 		String queryString = "select section from Section as section where section.moduleId = :moduleId and section.seqNo = :seqNo";
	 		Query query = session.createQuery(queryString);
	 		query.setParameter("moduleId", new Integer(moduleId));
	 		query.setParameter("seqNo", new Integer(seqNo));
	 		Iterator itr = query.iterate();
	 		while (itr.hasNext()){
	 			sec = (Section) itr.next();
	 		}
	 		//logger.info("moduledb:getSection" + sec.getTitle());

	    }
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
			  }
		}
	    return sec;
	 }

     public void archiveModule(ModuleDateBean mdbean) throws Exception {
     	Transaction tx = null;
	 	try
		{
	      logger.info("coming to moduledb: archiveModule");

	      Session session = hibernateUtil.currentSession();

	      tx = session.beginTransaction();
	      CourseModule cmod = (CourseModule) mdbean.getModule().getCoursemodule();
	      //logger.info("Module date set is "+mdset);
	      int modSeqNo = -1;

	      logger.info("Found a match module is "+cmod.getModule().getModuleId());
	      cmod.setArchvFlag(true);
	      Date currentDate = Calendar.getInstance().getTime();
	      cmod.setDateArchived(currentDate);
	      session.saveOrUpdate(cmod);
	      modSeqNo = cmod.getSeqNo();
	      cmod.setSeqNo(-1);

	      //Getting the set of course modules associated with this module
	      /*Set cmods = mdbean.getModule().getCoursemodules();
	      //logger.info("Module date set is "+mdset);
	      int modSeqNo = -1;
	      for (Iterator i = cmods.iterator(); i.hasNext(); ) {
	      	CourseModule cmod = (CourseModule) i.next();
	          //logger.info("cmods course id is "+cmod.getCourseId());
	        //Check to see if the cmod object
	        //And course and update it
	        if ((cmod.getModule().getModuleId().equals(mdbean.getModule().getModuleId()))&&(cmod.getCourseId().equals(mdbean.getCmod().getCourseId())))

	        {
	        	logger.info("Found a match module is "+cmod.getModule().getModuleId());
	        	cmod.setArchvFlag(true);
	        	Date currentDate = Calendar.getInstance().getTime();
	        	cmod.setDateArchived(currentDate);
	        	session.saveOrUpdate(cmod);
	        	modSeqNo = cmod.getSeqNo();
	        	cmod.setSeqNo(-1);
	        	break;
	        }

	        logger.info("Iterating");
  		  }	*/
	      logger.info("coming to moduledb: getcourseModules");
	       String queryString = "from CourseModule cmod where cmod.courseId = :courseId  and cmod.seqNo > :seqno";
	      Query query = session.createQuery(queryString);
	      query.setParameter("courseId",mdbean.getCmod().getCourseId());
	      query.setParameter("seqno",new Integer(modSeqNo));
	      //logger.info("Query created");
	      Iterator itr = query.iterate();
	      //logger.info("Iterating");
	      cmod = null;
	      while (itr.hasNext()) {
	      	//logger.info("Going thru loop");
	      	cmod = (CourseModule) itr.next();
	      	cmod.setSeqNo(cmod.getSeqNo() - 1);
	      	session.saveOrUpdate(cmod);
	      }

	      tx.commit();

	      //session.flush();

	    }
	    catch (HibernateException he)
	    {
		  logger.info(he.toString());
		  throw he;
	    }
	    catch (Exception e) {
	      if (tx!=null) tx.rollback();
	      logger.info(e.toString());
	      throw e;
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
				  throw he;
			  }
		}

     }
/* MANAGE TAB FUNCTIONALITY RELATED TRANSCATIONS*/

	 /**
	  * author : rashmi
	  * created on: 11 Jan 2005
	 * @param courseId
	 * @return list of archived modules of the course
	 */
	public List getArchivedModules(String course_id)
	 {
		List archModules = new ArrayList();
		 try
			{
		 	   Session session = hibernateUtil.currentSession();
			   Query q=session.createQuery("select cm from CourseModule cm where cm.courseId =:course_id and cm.archvFlag=1 order by cm.dateArchived");
			   q.setParameter("course_id", course_id);

			   logger.info("Query created for getting archive modules");
			   archModules = q.list();
			   logger.info("archive modules list size" + archModules.size() );
		     }
		     catch (HibernateException he)
		     {
				 logger.info(he.toString());
		     }
		     finally
				{
			    	try
					  {
				      	hibernateUtil.closeSession();
					  }
				      catch (HibernateException he)
					  {
						  logger.info(he.toString());
					  }
				}
		    return archModules ;
	 }

	/**
	 * author : rashmi
     * created on: 11 Jan 2005
	 * @param restoreModules
	 * @throws MeleteException
	 *
	 * to restore a module, update course_module, assign it a seq and
	 * set module_shdates start date as restored date and end date as 1 yr from there
	 * revised on 3/24/05 by rashmi to fix bug#460
	 */
	public void restoreModules(List restoreModules) throws MeleteException
	{
		try{
		     Session session = hibernateUtil.currentSession();
		      Transaction tx = null;

		   try{
	   		//	1.for each element of list
		   		for(int i=0; i < restoreModules.size(); i++ )
		   		{
		   	//	2.set course module object archv_flag to false, archived_date to null,
		   			CourseModule coursemodule = (CourseModule)restoreModules.get(i);
		   			Query q=session.createQuery("select cm1 from CourseModule cm1 where cm1.module.moduleId =:moduleId");
					q.setParameter("moduleId", coursemodule.getModule().getModuleId());

					CourseModule coursemodule1 = (CourseModule)(q.list().get(0));
		   			coursemodule1.setArchvFlag(false);
		   			coursemodule1.setDateArchived(null);

  			//  seq no as max+1
		   		   q=session.createQuery("select max(cm.seqNo) from CourseModule cm where cm.courseId =:courseId");
		 		   q.setParameter("courseId",coursemodule.getCourseId());

		    	  Integer maxsequence = (Integer)q.uniqueResult();
		    	  if(maxsequence.intValue() < 0)
		    	  {
		    	  	coursemodule1.setSeqNo(1);
		    	  }
		    	  else coursemodule1.setSeqNo(maxsequence.intValue()+1);

			// 3. fetch module_shdate object
	   			q=session.createQuery("select msh from ModuleShdates msh where msh.module.moduleId =:moduleId");
					q.setParameter("moduleId", coursemodule.getModule().getModuleId());

					ModuleShdates moduleShdate = (ModuleShdates)(q.list().get(0));

				//	3a.set start date as restored_date and end_date as 1 yr more
					GregorianCalendar cal = new GregorianCalendar();
				       cal.set(Calendar.HOUR,8);
				       cal.set(Calendar.MINUTE,0);
				       cal.set(Calendar.SECOND,0);
				       cal.set(Calendar.AM_PM,Calendar.AM);
					moduleShdate.setStartDate(cal.getTime());
					   cal.add(Calendar.YEAR, 1);
				       cal.set(Calendar.HOUR,11);
				       cal.set(Calendar.MINUTE,59);
				       cal.set(Calendar.SECOND,0);
				       cal.set(Calendar.AM_PM,Calendar.PM);
					moduleShdate.setEndDate(cal.getTime());

   			//4a. begin transaction
		   			tx = session.beginTransaction();
		   	//4b		save all objects
		   	        logger.info("Before save or update coursemodule");
		   			session.saveOrUpdate(coursemodule1);
		   		logger.info("course module updated");
		   			session.saveOrUpdate(moduleShdate);
		   			logger.info("module shdates updated");
			//4c.commit transaction
					tx.commit();
		   		}
		   		logger.info("restored success");
	   			return ;
		     }
		     catch (HibernateException he)
		     {
				if(tx !=null) tx.rollback();
				logger.error(he.toString());
				//he.printStackTrace();
				throw new MeleteException(he.toString());
		     }

		} catch (Exception e)
	     {
			 logger.info(e.toString());
			 throw new MeleteException(e.toString());
	     }
	     finally
			{
		    	try
				  {
			      	hibernateUtil.closeSession();
				  }
			      catch (HibernateException he)
				  {
					  logger.info(he.toString());
				  }
			}

	}



	/**
	 * @return Returns the hibernateUtil.
	 */
	public HibernateUtil getHibernateUtil() {
		return hibernateUtil;
	}
	/**
	 * @param hibernateUtil The hibernateUtil to set.
	 */
	public void setHibernateUtil(HibernateUtil hibernateUtil) {
		this.hibernateUtil = hibernateUtil;
	}

	public String createTruncstr(String modTitle)
	 {
	      String truncTitle = null;
	      if (modTitle.length() <= 30) return modTitle.trim();
	      if (modTitle.length() > 30)
	      {
	      	truncTitle = modTitle.substring(0,27);
	      	truncTitle = truncTitle.concat("...");
	      }
	      logger.info("Newbcstr is "+truncTitle);
	      return truncTitle;
	    }

	/*
	 * module listing for sort modules
	 * added by rashmi - 4/20
	 */
	public List getSortModules(String course_id)
		 {
			List sortModules = new ArrayList();
			 try
				{
			 	   Session session = hibernateUtil.currentSession();
				   Query q=session.createQuery("select cm from CourseModule cm where cm.courseId =:course_id and cm.archvFlag=0 order by cm.seqNo");
				   q.setParameter("course_id", course_id);

				   logger.info("Query created for getting sort modules");
				   sortModules = q.list();
				   logger.info("sortModules  list size" + sortModules.size() );
			     }
			     catch (HibernateException he)
			     {
					 logger.info(he.toString());
			     }
			     finally
					{
				    	try
						  {
					      	hibernateUtil.closeSession();
						  }
					      catch (HibernateException he)
						  {
							  logger.info(he.toString());
						  }
					}
			    return sortModules ;
		 }
	/*
	 * added by rashmi
	 * to save the new sequence of modules
	 */
	public void updateModuleSequence(List newSeqList) throws MeleteException
	{
		try{
		     Session session = hibernateUtil.currentSession();
		      Transaction tx = null;

		   try{
	   		//	1.for each element of list
		   		for(int i=0; i < newSeqList.size(); i++ )
		   		{
		   	//	2.get coursemodule element and assign new seq
		   			CourseModule coursemodule = (CourseModule)newSeqList.get(i);
		   			coursemodule.setSeqNo(i+1);
   			//4a. begin transaction
		   			tx = session.beginTransaction();
		   	//4b		save all objects
		   			session.saveOrUpdate(coursemodule);
		   			logger.info("course module updated");

			//4c.commit transaction
					tx.commit();
		   		}
		   		logger.info("newSeqList success");
	   			return ;
		     }
		     catch (HibernateException he)
		     {
				if(tx !=null) tx.rollback();
				logger.error(he.toString());
				//he.printStackTrace();
				throw new MeleteException(he.toString());
		     }

		} catch (Exception e)
	     {
			 logger.info(e.toString());
			 throw new MeleteException(e.toString());
	     }
	     finally
			{
		    	try
				  {
			      	hibernateUtil.closeSession();
				  }
			      catch (HibernateException he)
				  {
					  logger.info(he.toString());
				  }
			}

	}
}
