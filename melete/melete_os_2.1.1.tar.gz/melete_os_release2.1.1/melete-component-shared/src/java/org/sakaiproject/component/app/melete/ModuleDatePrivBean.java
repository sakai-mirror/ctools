/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-component-shared/src/java/org/sakaiproject/component/app/melete/ModuleDatePrivBean.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html 
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import java.util.List;



/** @author Hibernate CodeGenerator */
public class ModuleDatePrivBean extends ModuleDateBean implements Serializable {


    
    /** nullable persistent field */
    private org.sakaiproject.component.app.melete.ModuleStudentPrivs moduleStudentPriv;
    private List sectionBeans;

    /** full constructor */
    public ModuleDatePrivBean(int moduleId, org.sakaiproject.component.app.melete.Module module, org.sakaiproject.component.app.melete.ModuleShdates moduleShdate, org.sakaiproject.component.app.melete.ModuleStudentPrivs moduleStudentPriv) {
        this.moduleId = moduleId;
        this.module = module;
        this.moduleShdate = moduleShdate;
        this.moduleStudentPriv = moduleStudentPriv;
    }

    /** default constructor */
    public ModuleDatePrivBean() {
    }

    
    public org.sakaiproject.component.app.melete.ModuleStudentPrivs getModuleStudentPriv() {
        return this.moduleStudentPriv;
    }

    public void setModuleStudentPriv(org.sakaiproject.component.app.melete.ModuleStudentPrivs moduleStudentPriv) {
        this.moduleStudentPriv = moduleStudentPriv;
    }
    public List getSectionBeans() {
        return this.sectionBeans;
    }

    public void setSectionBeans(List sectionBeans) {
        this.sectionBeans = sectionBeans;
    }

    
}
