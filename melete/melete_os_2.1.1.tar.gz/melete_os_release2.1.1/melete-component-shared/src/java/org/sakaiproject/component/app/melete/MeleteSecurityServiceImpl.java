/*
 * Created on 1 Feb 2005
 *
 * 
 */
package org.sakaiproject.component.app.melete;

import org.sakaiproject.api.app.melete.MeleteSecurityService;
import org.sakaiproject.api.kernel.function.cover.FunctionManager;
import org.sakaiproject.api.kernel.tool.cover.ToolManager;
import org.sakaiproject.service.framework.log.Logger;
import org.sakaiproject.service.legacy.security.cover.SecurityService;

/*
 * MeleteSecurityService is the implementation of MeleteSecurityService
 * that provides the access permissions to the melete
 * 
 * @author Foot hill college
 * @version $Revision: 1.2 $
 */
public class MeleteSecurityServiceImpl implements MeleteSecurityService {
	
	/** Security function name for author. */
	protected static final String SECURE_AUTHOR = "melete.author";
	
	/** Security function name for student. */
	protected static final String SECURE_STUDENT = "melete.student";

	// Note: security needs a proper Resource reference
	
	/*******************************************************************************
	* Dependencies and their setter methods
	*******************************************************************************/

	/** Dependency: a logger component. */
	private Logger m_logger = null;

	/**
	 * Establish my logger component dependency.
	 * @param logger the logger component.
	 */
	public void setLogger(Logger logger)
	{
		m_logger = logger;
	}

	/*******************************************************************************
	* Init and Destroy
	*******************************************************************************/

	/**
	 * Final initialization, once all dependencies are set.
	 */
	public void init()
	{
		//register melete functions
		FunctionManager.registerFunction(SECURE_AUTHOR);
		FunctionManager.registerFunction(SECURE_STUDENT);
			
		m_logger.info(this +".init()");
	}

	/**
	 * Final cleanup.
	 */
	public void destroy()
	{
		m_logger.info(this +".destroy()");
	}

	/**
	 * 
	 */
	public MeleteSecurityServiceImpl() {
		super();

	}

	/**
	 * {@inheritDoc}
	 */
	public boolean allowAuthor()throws Exception {

		try {
			return SecurityService.unlock(SECURE_AUTHOR, getContextSiteId());
		} catch (Exception e) {
			throw new Exception(this.getClass().getName()+ " : allowAuthor() : " + e.toString());
		}
	}

	public boolean allowStudent()throws Exception{ 

		try {
			return SecurityService.unlock(SECURE_STUDENT, getContextSiteId());
		} catch (Exception e) {
			throw new Exception(this.getClass().getName()+ " : allowStudent() : " + e.toString());
		}
	}
	
	/**
	 * @return siteId
	 */
	private String getContextSiteId() {
		return ("/site/" + ToolManager.getCurrentPlacement().getContext());
	}

}
