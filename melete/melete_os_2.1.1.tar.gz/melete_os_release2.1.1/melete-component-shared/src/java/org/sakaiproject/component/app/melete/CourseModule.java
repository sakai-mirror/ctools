package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.sakaiproject.api.app.melete.CourseModuleService;


/** @author Hibernate CodeGenerator */
public class CourseModule implements Serializable,CourseModuleService {

    /** identifier field */
    private Integer moduleId;

    /** nullable persistent field */
    private String courseId;

    /** persistent field */
    private int seqNo;

    /** nullable persistent field */
    private boolean archvFlag;

    /** nullable persistent field */
    private Date dateArchived;

    /** identifier field */
    private org.sakaiproject.component.app.melete.Module module;

    /** full constructor */
    public CourseModule(String courseId, int seqNo, boolean archvFlag, Date dateArchived, org.sakaiproject.component.app.melete.Module module) {
        this.courseId = courseId;
        this.seqNo = seqNo;
        this.archvFlag = archvFlag;
        this.dateArchived = dateArchived;
        this.module = module;
    }

    /** default constructor */
    public CourseModule() {
    }

    /** minimal constructor */
    public CourseModule(int seqNo) {
        this.seqNo = seqNo;
    }

    public Integer getModuleId() {
        return this.moduleId;
    }

    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public String getCourseId() {
        return this.courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public int getSeqNo() {
        return this.seqNo;
    }

    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    public boolean isArchvFlag() {
        return this.archvFlag;
    }

    public void setArchvFlag(boolean archvFlag) {
        this.archvFlag = archvFlag;
    }

    public Date getDateArchived() {
        return this.dateArchived;
    }

    public void setDateArchived(Date dateArchived) {
        this.dateArchived = dateArchived;
    }



    public org.sakaiproject.api.app.melete.ModuleObjService getModule() {
        return this.module;
    }

    public void setModule(org.sakaiproject.api.app.melete.ModuleObjService module) {
        this.module = (Module) module;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("moduleId", getModuleId())
            .toString();
    }

}
