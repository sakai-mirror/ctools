package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.ToStringBuilder;

import org.sakaiproject.api.app.melete.SectionObjService;


/** @author Hibernate CodeGenerator */
public class Section implements Serializable,SectionObjService {

    /** identifier field */
    private Integer sectionId;

    /** nullable persistent field */
    private int moduleId;

    /** nullable persistent field */
    private int seqNo;

    /** persistent field */
    private String title;

    /** persistent field */
    private String createdByFname;

    /** persistent field */
    private String createdByLname;

    /** nullable persistent field */
    private String modifiedByFname;

    /** nullable persistent field */
    private String modifiedByLname;

    /** nullable persistent field */
    private String instr;

    /** persistent field */
    private String contentType;

    /** nullable persistent field */
    private String contentPath;

    /** nullable persistent field */
    private String uploadPath;

    /** nullable persistent field */
    private String link;

    /** nullable persistent field */
    private boolean audioContent;

    /** nullable persistent field */
    private boolean videoContent;

    /** nullable persistent field */
    private boolean textualContent;

    /** persistent field */
    private Date creationDate;

    /** persistent field */
    private Date modificationDate;

    /** nullable persistent field */
    private int version;

    /** nullable persistent field */
    private org.sakaiproject.component.app.melete.Module module;

    /** full constructor */
    public Section(int moduleId, int seqNo, String title, String createdByFname, String createdByLname, String modifiedByFname, String modifiedByLname, String instr, String contentType, String contentPath, String uploadPath, String link, boolean audioContent, boolean videoContent, boolean textualContent, Date creationDate, Date modificationDate, int version, org.sakaiproject.component.app.melete.Module module) {
        this.moduleId = moduleId;
        this.seqNo = seqNo;
        this.title = title;
        this.createdByFname = createdByFname;
        this.createdByLname = createdByLname;
        this.modifiedByFname = modifiedByFname;
        this.modifiedByLname = modifiedByLname;
        this.instr = instr;
        this.contentType = contentType;
        this.contentPath = contentPath;
        this.uploadPath = uploadPath;
        this.link = link;
        this.audioContent = audioContent;
        this.videoContent = videoContent;
        this.textualContent = textualContent;
        this.creationDate = creationDate;
        this.modificationDate = modificationDate;
        this.version = version;
        this.module = module;
    }

    /** default constructor */
    public Section() {
    }

    /** minimal constructor */
    public Section(String title, String createdByFname, String createdByLname, String contentType, Date creationDate, Date modificationDate) {
        this.title = title;
        this.createdByFname = createdByFname;
        this.createdByLname = createdByLname;
        this.contentType = contentType;
        this.creationDate = creationDate;
        this.modificationDate = modificationDate;
    }

    public Integer getSectionId() {
        return this.sectionId;
    }

    public void setSectionId(Integer sectionId) {
        this.sectionId = sectionId;
    }

    public int getModuleId() {
        return this.moduleId;
    }

    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }

    public int getSeqNo() {
        return this.seqNo;
    }

    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCreatedByFname() {
        return this.createdByFname;
    }

    public void setCreatedByFname(String createdByFname) {
        this.createdByFname = createdByFname;
    }

    public String getCreatedByLname() {
        return this.createdByLname;
    }

    public void setCreatedByLname(String createdByLname) {
        this.createdByLname = createdByLname;
    }

    public String getModifiedByFname() {
        return this.modifiedByFname;
    }

    public void setModifiedByFname(String modifiedByFname) {
        this.modifiedByFname = modifiedByFname;
    }

    public String getModifiedByLname() {
        return this.modifiedByLname;
    }

    public void setModifiedByLname(String modifiedByLname) {
        this.modifiedByLname = modifiedByLname;
    }

    public String getInstr() {
        return this.instr;
    }

    public void setInstr(String instr) {
        this.instr = instr;
    }

    public String getContentType() {
        return this.contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getContentPath() {
        return this.contentPath;
    }

    public void setContentPath(String contentPath) {
        this.contentPath = contentPath;
    }

    public String getUploadPath() {
        return this.uploadPath;
    }

    public void setUploadPath(String uploadPath) {
        this.uploadPath = uploadPath;
    }

    public String getLink() {
        return this.link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public boolean isAudioContent() {
        return this.audioContent;
    }

    public void setAudioContent(boolean audioContent) {
        this.audioContent = audioContent;
    }

    public boolean isVideoContent() {
        return this.videoContent;
    }

    public void setVideoContent(boolean videoContent) {
        this.videoContent = videoContent;
    }

    public boolean isTextualContent() {
        return this.textualContent;
    }

    public void setTextualContent(boolean textualContent) {
        this.textualContent = textualContent;
    }

    public Date getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getModificationDate() {
        return this.modificationDate;
    }

    public void setModificationDate(Date modificationDate) {
        this.modificationDate = modificationDate;
    }

    public int getVersion() {
        return this.version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public org.sakaiproject.api.app.melete.ModuleObjService getModule() {
        return this.module;
    }

    public void setModule(org.sakaiproject.api.app.melete.ModuleObjService module) {
        this.module = (Module)module;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("sectionId", getSectionId())
            .toString();
    }

}
