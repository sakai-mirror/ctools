/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-component-shared/src/java/org/sakaiproject/component/app/melete/CourseDB.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.util.*;
// import java.sql.*;

import net.sf.hibernate.*;
//import net.sf.hibernate.type.*;
//import net.sf.hibernate.Session.*;
import java.io.Serializable;

import org.sakaiproject.service.framework.log.Logger;

/**
 * @author Rashmi
 *
 * implements actual operations to the section table
 * and related tables
 *
 * Mallika - 4/22/05 - Added the association to display module label
 * Mallika - 5/12/05 - Commented all upload sizes code
 * Mallika - 5/19/05 - Changed code for module label so it is refreshed each time
 */

public class CourseDB implements Serializable{
	CoursePrefs coursePrefs;
	private HibernateUtil hibernateUtil;
	private Logger logger;
	/**
	 * constructor
	 */
	public CourseDB(){}

	/**
	 * @param course_id
	 * if course is null then create an instance of course.
	 */
	private void getCourse(String course_id)
	{
		logger.info("Before coursePrefs condition");
		if(coursePrefs == null || !coursePrefs.getCourseId().equals(course_id))
		{
		try{
		     Session session = hibernateUtil.currentSession();
	      	try
			{

		  	String q=new String("Select c from CoursePrefs c where c.courseId='"+course_id+"'");
		  	List courses = session.find(q);
            logger.info("Before finding coursePrefs");
		    coursePrefs = (CoursePrefs)courses.get(0);

		    logger.info("CourseDB: found Course "+ coursePrefs);

			}catch (HibernateException he)
		     {
				logger.error(he.toString());
		//		he.printStackTrace();
				throw he;
		     }
		   	finally{
				hibernateUtil.closeSession();
				 }
		}catch(Exception ex){
				// Throw application specific error
			}
		}
		return;
	}
	/**
	 * @param course_id
	 * @return
	 * Revised -- Rashmi - 2/1/05 to set upto max size
	 * till user gets preferences tab
	 */
	/*public int getUploadSize(String course_id)
	{
		getCourse(course_id);
		int sz = 0;
		if(coursePrefs != null)
		{
			sz = coursePrefs.getUploadSize();
		}
//		if size is null or empty, then default size is max size
		if (sz > 0) return sz;
		else return 2048;
	}*/

	/**
	 * @param size
	 */
	/*public void setUploadSize(int size, String course_id)
	{
		getCourse(course_id);
		coursePrefs.setUploadSize(size);
		try{
		     Session session = hibernateUtil.currentSession();
		     Transaction tx = null;
	      	try
			{
	      	  tx = session.beginTransaction();
	      	  session.save(coursePrefs);
	      	  tx.commit();
			}catch (HibernateException he)
		     {
				if(tx !=null) tx.rollback();
				logger.error(he.toString());
			//	he.printStackTrace();
				throw he;
		     }
		   	finally{
				hibernateUtil.closeSession();
				 }
		}catch(Exception ex){
				// Throw application specific error
			}
	}*/
	public String getModuleLabel(String course_id)
	{
		logger.info("Coming to getModuleLabel in CourseDB");
		/*getCourse(course_id);
		String moduleLabel = null;
		if(coursePrefs != null)
		{
			moduleLabel = coursePrefs.getModuleLabel();
		}
		logger.info("Courseprefs is "+coursePrefs);
		logger.info("Module label is "+moduleLabel);*/
		String moduleLabel = null;
		try{
		     Session session = hibernateUtil.currentSession();
	      	try
			{

		  	String q=new String("Select c from CoursePrefs c where c.courseId='"+course_id+"'");
		  	List courses = session.find(q);
           logger.info("Before finding coursePrefs");
		    coursePrefs = (CoursePrefs)courses.get(0);

		    logger.info("CourseDB: found Course "+ coursePrefs);
		    moduleLabel = coursePrefs.getModuleLabel();

			}catch (HibernateException he)
		     {
				logger.error(he.toString());
		//		he.printStackTrace();
				throw he;
		     }
		   	finally{
				hibernateUtil.closeSession();
				 }
		}catch(Exception ex){
				// Throw application specific error
			}		
		logger.info("Module label in courseDB is "+moduleLabel);		
		return moduleLabel;
	}
	public void setModuleLabel(String course_id, String modLabel)
	{
		boolean entryExists = false;
		logger.info("Entering setmodulelabel in coursedb");
		getCourse(course_id);
		logger.info("Got course "+coursePrefs);
		if (coursePrefs != null)
		{
		  coursePrefs.setModuleLabel(modLabel);
		}
		else
		{
			coursePrefs = new CoursePrefs();
			coursePrefs.setCourseId(course_id);
			//Defaulting upload size to 2 MB
			//coursePrefs.setUploadSize(2048);
			coursePrefs.setModuleLabel(modLabel);
			entryExists = true;
		}
		logger.info("Got course and set modlabel to "+modLabel);
		try{
		     Session session = hibernateUtil.currentSession();
		     Transaction tx = null;
	      	try
			{
	      	  tx = session.beginTransaction();
	      	  if (entryExists == true)
	      	  {
	      	    session.save(coursePrefs);
	      	  }
	      	  else
	      	  {
	      	  	session.update(coursePrefs);
	      	  }
	      	  
	      	  tx.commit();
			}catch (HibernateException he)
		     {
				if(tx !=null) tx.rollback();
				logger.error(he.toString());
			//	he.printStackTrace();
				throw he;
		     }
		   	finally{
				hibernateUtil.closeSession();
				 }
		}catch(Exception ex){
				// Throw application specific error
			}
		logger.info("Saved courseprefs");
		logger.info("Courseprefs module label is "+coursePrefs.getModuleLabel());
	}

	/**
	 * @return Returns the hibernateUtil.
	 */
	public HibernateUtil getHibernateUtil() {
		return hibernateUtil;
	}
	/**
	 * @param hibernateUtil The hibernateUtil to set.
	 */
	public void setHibernateUtil(HibernateUtil hibernateUtil) {
		this.hibernateUtil = hibernateUtil;
	}
	/**
	 * @return Returns the logger.
	 */
	public Logger getLogger() {
		return logger;
	}
	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
}