package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;
import org.apache.commons.lang.builder.ToStringBuilder;

import org.sakaiproject.api.app.melete.ModuleObjService;


/** @author Hibernate CodeGenerator */
public class Module implements Serializable,ModuleObjService {

    /** identifier field */
    private Integer moduleId;

    /** persistent field */
    private String title;

    /** nullable persistent field */
    private String learnObj;

    /** nullable persistent field */
    private String description;

    /** persistent field */
    private String keywords;

    /** persistent field */
    private String createdByFname;

    /** persistent field */
    private String createdByLname;

    /** persistent field */
    private String userId;

    /** nullable persistent field */
    private String modifiedByFname;

    /** nullable persistent field */
    private String modifiedByLname;

    /** nullable persistent field */
    private String institute;

    /** nullable persistent field */
    private int licenseCode;

    /** nullable persistent field */
    private String ccLicenseUrl;

    /** nullable persistent field */
    private boolean reqAttr;

    /** nullable persistent field */
    private boolean allowCmrcl;

    /** nullable persistent field */
    private int allowMod;

    /** nullable persistent field */
    private String whatsNext;

    /** persistent field */
    private Date creationDate;

    /** nullable persistent field */
    private Date modificationDate;

    /** nullable persistent field */
    private int version;

    /** nullable persistent field */
    private org.sakaiproject.component.app.melete.ModuleShdates moduleshdate;

    /** nullable persistent field */
    private org.sakaiproject.component.app.melete.CourseModule coursemodule;

    /** nullable persistent field */
    private org.sakaiproject.component.app.melete.ModuleLicense moduleLicense;

    /** persistent field */
    private List sections;

    /** persistent field */
    private Set modulestudentprivs;

    /** full constructor */
    public Module(String title, String learnObj, String description, String keywords, String createdByFname, String createdByLname, String userId, String modifiedByFname, String modifiedByLname, String institute, int licenseCode, String ccLicenseUrl, boolean reqAttr, boolean allowCmrcl, int allowMod, String whatsNext, Date creationDate, Date modificationDate, int version, org.sakaiproject.component.app.melete.ModuleShdates moduleshdate, org.sakaiproject.component.app.melete.CourseModule coursemodule, org.sakaiproject.component.app.melete.ModuleLicense moduleLicense, List sections, Set modulestudentprivs) {
        this.title = title;
        this.learnObj = learnObj;
        this.description = description;
        this.keywords = keywords;
        this.createdByFname = createdByFname;
        this.createdByLname = createdByLname;
        this.userId = userId;
        this.modifiedByFname = modifiedByFname;
        this.modifiedByLname = modifiedByLname;
        this.institute = institute;
        this.licenseCode = licenseCode;
        this.ccLicenseUrl = ccLicenseUrl;
        this.reqAttr = reqAttr;
        this.allowCmrcl = allowCmrcl;
        this.allowMod = allowMod;
        this.whatsNext = whatsNext;
        this.creationDate = creationDate;
        this.modificationDate = modificationDate;
        this.version = version;
        this.moduleshdate = moduleshdate;
        this.coursemodule = coursemodule;
        this.moduleLicense = moduleLicense;
        this.sections = sections;
        this.modulestudentprivs = modulestudentprivs;
    }

    /** default constructor */
    public Module() {
    }

    /** minimal constructor */
    public Module(String title, String keywords, String createdByFname, String createdByLname, String userId, Date creationDate, List sections, Set modulestudentprivs) {
        this.title = title;
        this.keywords = keywords;
        this.createdByFname = createdByFname;
        this.createdByLname = createdByLname;
        this.userId = userId;
        this.creationDate = creationDate;
        this.sections = sections;
        this.modulestudentprivs = modulestudentprivs;
    }

    public Integer getModuleId() {
        return this.moduleId;
    }

    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLearnObj() {
        return this.learnObj;
    }

    public void setLearnObj(String learnObj) {
        this.learnObj = learnObj;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getKeywords() {
        return this.keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getCreatedByFname() {
        return this.createdByFname;
    }

    public void setCreatedByFname(String createdByFname) {
        this.createdByFname = createdByFname;
    }

    public String getCreatedByLname() {
        return this.createdByLname;
    }

    public void setCreatedByLname(String createdByLname) {
        this.createdByLname = createdByLname;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getModifiedByFname() {
        return this.modifiedByFname;
    }

    public void setModifiedByFname(String modifiedByFname) {
        this.modifiedByFname = modifiedByFname;
    }

    public String getModifiedByLname() {
        return this.modifiedByLname;
    }

    public void setModifiedByLname(String modifiedByLname) {
        this.modifiedByLname = modifiedByLname;
    }

    public String getInstitute() {
        return this.institute;
    }

    public void setInstitute(String institute) {
        this.institute = institute;
    }

    public int getLicenseCode() {
        return this.licenseCode;
    }

    public void setLicenseCode(int licenseCode) {
        this.licenseCode = licenseCode;
    }

    public String getCcLicenseUrl() {
        return this.ccLicenseUrl;
    }

    public void setCcLicenseUrl(String ccLicenseUrl) {
        this.ccLicenseUrl = ccLicenseUrl;
    }

    public boolean isReqAttr() {
        return this.reqAttr;
    }

    public void setReqAttr(boolean reqAttr) {
        this.reqAttr = reqAttr;
    }

    public boolean isAllowCmrcl() {
        return this.allowCmrcl;
    }

    public void setAllowCmrcl(boolean allowCmrcl) {
        this.allowCmrcl = allowCmrcl;
    }

    public int getAllowMod() {
        return this.allowMod;
    }

    public void setAllowMod(int allowMod) {
        this.allowMod = allowMod;
    }

    public String getWhatsNext() {
        return this.whatsNext;
    }

    public void setWhatsNext(String whatsNext) {
        this.whatsNext = whatsNext;
    }

    public Date getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getModificationDate() {
        return this.modificationDate;
    }

    public void setModificationDate(Date modificationDate) {
        this.modificationDate = modificationDate;
    }

    public int getVersion() {
        return this.version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public org.sakaiproject.api.app.melete.ModuleShdatesService getModuleshdate() {
        return this.moduleshdate;
    }

    public void setModuleshdate(org.sakaiproject.api.app.melete.ModuleShdatesService moduleshdate) {
        this.moduleshdate = (ModuleShdates) moduleshdate;
    }

    public org.sakaiproject.api.app.melete.CourseModuleService getCoursemodule() {
        return this.coursemodule;
    }

    public void setCoursemodule(org.sakaiproject.api.app.melete.CourseModuleService coursemodule) {
        this.coursemodule = (CourseModule) coursemodule;
    }

    public org.sakaiproject.api.app.melete.ModuleLicenseService getModuleLicense() {
        return this.moduleLicense;
    }

    public void setModuleLicense(org.sakaiproject.api.app.melete.ModuleLicenseService moduleLicense) {
        this.moduleLicense = (ModuleLicense)moduleLicense;
    }

    public List getSections() {
        return this.sections;
    }

    public void setSections(List sections) {
        this.sections = sections;
    }

    public Set getModulestudentprivs() {
        return this.modulestudentprivs;
    }

    public void setModulestudentprivs(Set modulestudentprivs) {
        this.modulestudentprivs = modulestudentprivs;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("moduleId", getModuleId())
            .toString();
    }

}
