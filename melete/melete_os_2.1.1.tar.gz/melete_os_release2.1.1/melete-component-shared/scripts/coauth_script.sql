set @meldocs='/var/meleteDocs';
set @meldocs_instr=concat(@meldocs,'/instr_%');
drop table if exists melete_section_bkup;
create table melete_section_bkup as select * from melete_section;
update melete_section set content_path=(concat(left(content_path,locate('instr_',content_path)-1), right(content_path,length(content_path)-locate('course_',content_path)+1))) where content_path is not null and content_path like @meldocs_instr; 
update melete_section set upload_path=(concat(left(upload_path,locate('instr_',upload_path)-1), right(upload_path,length(upload_path)-locate('course_',upload_path)+1))) where upload_path is not null and upload_path like @meldocs_instr; 


