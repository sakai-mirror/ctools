#!/usr/bin/perl -w

########## IMPORTANT####################################
#
# Please be sure to back up your meleteDocs directory
# before doing anything.
# Also, this is where I'm supposed to say I'm not liable
# for any loss of data, hardware/software damage, loss of wages,
# bruised ego, lack of sex life, global poverty, etc.
# This script is distributed as is and use at your own risk.
# Kyong Kim, Foothill College
#
#######################################################

use strict;
use File::Find;;
use File::Path;

################### Edit these settings ####################### 
# Set to 1 if your installation is running on Windows
my $windows_flag = 0;

# Path to your meleteDocs. Typically, it's /var/MeleteDocs
my $base_path = "/home/kyongk/meleteDocs_test";

my ($uid, $gid);

# sakai username and groupname. Typically tomcat.tomcat on UNIX...Windows people can ignore.
if ($windows_flag) {
	$uid = "Bill Gates";
}
else {
	# edit "tomcat" if not tomcat
	$uid = getpwnam("tomcat");
}

# Sakai group name. Typically tomcat
if ($windows_flag) {
	$gid = "Owns You";
}
else {
	#edit "tomcat" if not tomcat
	$gid = getgrnam("tomcat");
}
################################################################

### Verify Input Args #################################################

my $progname; ($progname = $0) =~ s!^.*/!!;

my $usage =<<EOTEXT;

usage: $progname <option> ...

	descends into each directory and processes all Section_*.html files
	by removing the higher level instructor directory and saves the most recent .html version
	-s scans the directories without moving anything
	-h prints this usage message
	
	Examples:
	$progname
	$progname -s

EOTEXT


# die $usage unless ( $ARGV[0] );
my $scan_flag;
if (@ARGV) {
	my $option = $ARGV[0];
	if ($option eq "-s") {
		$scan_flag = 1;
	}
	else {
		die $usage;
	}
}


#### Main ##############################################
	# traverse down from melete doc root and move dir and files using Perl's File::Find
	find(\&proc_file, "$base_path");

	print "-----Completed Replication of dir structure----\n";

	# this subroutine will read through melete doc root and remove all instr directories
	cleanup();
	print "-----Removed old instr directories and contents----\n";

	find(\&proc_html, "$base_path");
	print "----Updated all meleteDoc path references in .html files----\n";	

	exit(0);

#### Subroutines ########################################

sub proc_file {
	my $entry = "$File::Find::name";

	# skip top_level melete directory and start from course directories
	if (-d $entry) {
		# skip top-level dir
		if ($entry eq $base_path) {
			print "Skipping $entry\n";
		}
		# skip instr directories
		elsif ($entry =~ /\/instr_[^\^\/\\%\*\?\n\r\t\b\f]*$/) {
			print "Skipping $entry\n";
		}
		else {
#			print "src: $entry";
			my $dest_dir = $entry;
			# stripping instr_* from the path
			$dest_dir =~ s/\/instr_[^\^\/\\%\*\?\n\r\t\b\f]*\//\//;


                	#skip replicating the directory if it exists and set uid, gid, permission
	        	if (-e $dest_dir) {
                        	print "Skipping $entry -> $dest_dir -- Already exists\n";
	            	}
			else {

                        	mkdir $dest_dir, 0755 unless $scan_flag;
				unless ($windows_flag) {
                        		chown($uid, $gid, $dest_dir) unless $scan_flag;
                        	}
				print "$entry -> $dest_dir -- uid:$uid gid:$gid permission:0755\n";
			}

		}	
	}
	# for files, newer version must be moved
	elsif (-f $entry) {
		
		my $dest_file = $entry;
		$dest_file =~ s/\/instr_[^\^\/\\%\*\?\n\r\t\b\f]*\//\//;

		if (-e $dest_file) {
			# compare last modified dates ancd copy only if the existing file is newer
			
			if (-M $dest_file > -M $entry) {
				# need \" to process filenames with spaces on UNIX
				if ($windows_flag) {
					system "copy \"$entry\" \"$dest_file\"" unless $scan_flag;
				}
				else {
					system "cp -p \"$entry\" \"$dest_file\"" unless $scan_flag;
				}


#				copy($entry, $dest_file) unless $scan_flag;
#	                       	chmod(0644, $dest_file) unless $scan_flag;
#	                       	chown($uid, $gid, $dest_file) unless $scan_flag;
				print "$entry -> $dest_file -- uid:$uid gid:$gid permission:0644\n";
                	}
			else {
				print "Skipping $entry -> $dest_file -- Newer version already exists\n";
			}
		}
		else {
			if ($windows_flag) {
				system "copy \"$entry\" \"$dest_file\"" unless $scan_flag;
			}
			else {
				system "cp -p \"$entry\" \"$dest_file\"" unless $scan_flag;
			}		
#			copy($entry, $dest_file) unless $scan_flag;
#	                chmod(0644, $dest_file) unless $scan_flag;
#	                chown($uid, $gid, $dest_file) unless $scan_flag;
			print "$entry -> $dest_file -- uid:$uid gid:$gid permission:0644\n";
		}
		 
	}
}


sub cleanup {

	my $file;
	# open dir handle and list all it content
	opendir(D,"$base_path") or die("Can't open $base_path",$!);
        	while ($file = readdir(D)) {
			# if file is instr directory, then remove it and its content
            		if ($file =~ /instr_[^\^\/\\%\*\?\n\r\t\b\f]*$/) {          
				rmtree("$base_path/$file", 1, 1) unless $scan_flag;
				print "Removing $base_path/$file\n"
            		}
         	}
      	closedir(D); 
	return;
}

sub proc_html 
{
	my $entry = "$File::Find::name";
	
	if ($entry =~ /Section_\d+\.html/) {
		my $r_data = read_data($entry);
		my @new_lines;
		my $hit_flag=0;
		foreach my $line (@$r_data) {
			# remove http://server_url here
			if ($line =~ /http.*\/instr_[^\^\/\\%\*\?\n\r\t\b\f]*\//) {
				$line =~ s/\/instr_[^\^\/\\%\*\?\n\r\t\b\f]*\//\//g;
				$hit_flag +=1;
			}
			
			$line .= "\n";
			push(@new_lines, $line);
		}
		re_write_array($entry, \@new_lines) unless $scan_flag;
		print "Processed $entry -- $hit_flag replacements\n"; 
	}
}

#===============================================================#
# function read data                                            
# passes $data_file: returns reference to array                 
#===============================================================#
sub read_data {
   my ($data_file) = @_;
   my (@data);   
   # open data file and read into @data1
   open (F, "$data_file") || die ("Error: can't open $data_file -", $!);
      chomp(@data = <F>);
   close (F);      
   return \@data;
}

#===============================================================#
# function rewrite array                                        
# passes $data_file, reference to array: returns 1              
#===============================================================#
sub re_write_array {
	my ($data_file, $r_data1) = @_;
	#add newline since earlier chomped
	
	#open file and overwrite regardless

	open (F, ">$data_file") ||
			die ("Error: can't open $data_file - ", $!);
				print F @$r_data1;
	close (F);

	return 1;
}
