/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-api/src/java/org/sakaiproject/api/app/melete/ModuleDateBeanService.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.api.app.melete;

import java.util.List;

/**
 * Filename:
 * Description:
 * Author:
 * Date:
 * Copyright 2004, Foothill College
 */
public interface ModuleDateBeanService {
	public abstract boolean isSelected();

	public abstract void setSelected(boolean selected);

	public abstract boolean isDateFlag();

	public abstract void setDateFlag(boolean dateFlag);

	public abstract String getTruncTitle();

	public abstract void setTruncTitle(String truncTitle);

	public abstract int getModuleId();

	public abstract void setModuleId(int moduleId);

	public abstract org.sakaiproject.api.app.melete.ModuleObjService getModule();

	public abstract void setModule(
			org.sakaiproject.api.app.melete.ModuleObjService module);

	public abstract org.sakaiproject.api.app.melete.ModuleShdatesService getModuleShdate();

	public abstract void setModuleShdate(
			org.sakaiproject.api.app.melete.ModuleShdatesService moduleShdate);

	public abstract org.sakaiproject.api.app.melete.CourseModuleService getCmod();

	public abstract void setCmod(
			org.sakaiproject.api.app.melete.CourseModuleService cmod);

	public abstract List getSectionBeans();

	public abstract void setSectionBeans(List sectionBeans);

	public abstract String toString();
}