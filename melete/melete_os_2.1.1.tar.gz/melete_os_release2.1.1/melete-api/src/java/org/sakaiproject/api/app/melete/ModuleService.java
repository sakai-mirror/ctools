/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-api/src/java/org/sakaiproject/api/app/melete/ModuleService.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/

package org.sakaiproject.api.app.melete;

import java.util.*;

/* Mallika - 3/22/05 - Added methods for moduledatebeanservice 
 * Mallika - 3/28/05 - Catching exception in updateProperties
 * Mallika - 4/18/05 - Added method to delete module
 * Rashmi - 4/21-22 add methods for sort modules
 * Rashmi - 07/07/07 - removed season and yr from method signature of insert properties
 */

public interface ModuleService{
	public void insertProperties(ModuleObjService module, ModuleShdatesService moduleshdates,String userId, String courseId);
	
	public ArrayList getModuleLicenses();
	
	public String[] getCCLicenseURL(boolean reqAttr, boolean allowCmrcl, int allowMod);
	
	public List getModuleDateBeans(String courseId);

	public void setModuleDateBeans(List moduleDateBeansList);
	
	public ModuleDateBeanService getModuleDateBean(String courseId,  int moduleId);

	public void setModuleDateBean(ModuleDateBeanService mdBean);
	
	public List getModules(String courseId);

	public void setModules(List modules) ;

	public List getModuleDatePrivBeans(String userId,String courseId);

	public void setModuleDatePrivBeans(List moduleDatePrivBeansList) ;

	public void updateModuleDateBeans(List moduleDateBeans) throws Exception;

	public void updateProperties(Object mdbean)  throws Exception;
	
	public void archiveModule(Object mdBean) throws Exception;
	
	public ModuleObjService getModule(int moduleId);

	public void setModule(ModuleObjService mod);
	
	public List getArchiveModules(String course_id);
	
	public void restoreModules(List modules) throws Exception;
	
	
	public CourseModuleService getCourseModule(int moduleId,  String courseId) throws Exception;
	public void deleteModule(Object mdbean, String dataPath);	
    public List getSortModules(String course_id);
	public void updateModuleSequence(List newSeqList) throws Exception;

}