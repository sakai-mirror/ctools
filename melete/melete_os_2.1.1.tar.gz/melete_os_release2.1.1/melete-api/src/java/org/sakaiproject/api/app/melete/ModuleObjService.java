/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-api/src/java/org/sakaiproject/api/app/melete/ModuleObjService.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.api.app.melete;

import java.util.Date;
import java.util.List;
import java.util.Set;



/**
 * Filename:
 * Description:
 * Author:
 * Date:
 * Copyright 2004, Foothill College
 */
public interface ModuleObjService {
	public abstract Integer getModuleId();

	public abstract void setModuleId(Integer moduleId);

	public abstract String getTitle();

	public abstract void setTitle(String title);

	public abstract String getLearnObj();

	public abstract void setLearnObj(String learnObj);

	public abstract String getDescription();

	public abstract void setDescription(String description);

	public abstract String getKeywords();

	public abstract void setKeywords(String keywords);

	public abstract String getCreatedByFname();

	public abstract void setCreatedByFname(String createdByFname);

	public abstract String getCreatedByLname();

	public abstract void setCreatedByLname(String createdByLname);

    public abstract String getUserId();

	public abstract void setUserId(String userId);

	public abstract String getModifiedByFname();

	public abstract void setModifiedByFname(String modifiedByFname);

	public abstract String getModifiedByLname();

	public abstract void setModifiedByLname(String modifiedByLname);

	public abstract String getInstitute();

	public abstract void setInstitute(String institute);

	public abstract int getLicenseCode();

	public abstract void setLicenseCode(int licenseCode);

	public abstract String getCcLicenseUrl();

	public abstract void setCcLicenseUrl(String ccLicenseUrl);

	public abstract boolean isReqAttr();

	public abstract void setReqAttr(boolean reqAttr);

	public abstract boolean isAllowCmrcl();

	public abstract void setAllowCmrcl(boolean allowCmrcl);

	public abstract int getAllowMod();

	public abstract void setAllowMod(int allowMod);

	public abstract String getWhatsNext();

	public abstract void setWhatsNext(String whatsNext);

	public abstract Date getCreationDate();

	public abstract void setCreationDate(Date creationDate);

	public abstract Date getModificationDate();

	public abstract void setModificationDate(Date modificationDate);

	public abstract int getVersion();

	public abstract void setVersion(int version);

	public abstract org.sakaiproject.api.app.melete.ModuleLicenseService  getModuleLicense();

	public abstract void setModuleLicense(
			org.sakaiproject.api.app.melete.ModuleLicenseService  moduleLicense);

	public abstract List getSections();

	public abstract void setSections(List sections);
	
    public abstract org.sakaiproject.api.app.melete.ModuleShdatesService getModuleshdate();
   
    public abstract void setModuleshdate(org.sakaiproject.api.app.melete.ModuleShdatesService moduleshdate);
   

	public abstract Set getModulestudentprivs();

	public abstract void setModulestudentprivs(Set modulestudentprivs);
	
	public abstract org.sakaiproject.api.app.melete.CourseModuleService getCoursemodule();
    
    public abstract void setCoursemodule(org.sakaiproject.api.app.melete.CourseModuleService coursemodule);
  

	public abstract String toString();
}