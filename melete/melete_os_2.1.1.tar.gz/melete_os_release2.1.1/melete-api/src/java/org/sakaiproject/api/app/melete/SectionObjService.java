/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-api/src/java/org/sakaiproject/api/app/melete/SectionObjService.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.api.app.melete;

import java.util.Date;

/**
 * Filename:
 * Description:
 * Author:
 * Date:
 * Copyright 2004, Foothill College
 */
public interface SectionObjService {
	public Integer getSectionId();

    public void setSectionId(Integer sectionId);
    
	public abstract int getModuleId();

	public abstract void setModuleId(int moduleId);

	public abstract int getSeqNo();

	public abstract void setSeqNo(int seqNo);

	public abstract String getTitle();

	public abstract void setTitle(String title);

	public abstract String getCreatedByFname();

	public abstract void setCreatedByFname(String createdByFname);

	public abstract String getCreatedByLname();

	public abstract void setCreatedByLname(String createdByLname);

	public abstract String getModifiedByFname();

	public abstract void setModifiedByFname(String modifiedByFname);

	public abstract String getModifiedByLname();

	public abstract void setModifiedByLname(String modifiedByLname);

	public abstract String getInstr();

	public abstract void setInstr(String instr);

	public abstract String getContentType();

	public abstract void setContentType(String contentType);

	public abstract String getContentPath();

	public abstract void setContentPath(String contentPath);

	public abstract String getUploadPath();

	public abstract void setUploadPath(String uploadPath);

	public abstract String getLink();

	public abstract void setLink(String link);

	public abstract boolean isAudioContent();

	public abstract void setAudioContent(boolean audioContent);

	public abstract boolean isVideoContent();

	public abstract void setVideoContent(boolean videoContent);

	public abstract boolean isTextualContent();

	public abstract void setTextualContent(boolean textualContent);

	public abstract Date getCreationDate();

	public abstract void setCreationDate(Date creationDate);

	public abstract Date getModificationDate();

	public abstract void setModificationDate(Date modificationDate);

	public abstract int getVersion();

	public abstract void setVersion(int version);

	public abstract org.sakaiproject.api.app.melete.ModuleObjService getModule();

	public abstract void setModule(
			org.sakaiproject.api.app.melete.ModuleObjService module);

	public abstract String toString();

	public abstract boolean equals(Object other);

	public abstract int hashCode();
}