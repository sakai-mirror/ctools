/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-api/src/java/org/sakaiproject/api/app/melete/SectionService.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.api.app.melete;

import java.util.List;
/**
 * Mallika - 4/20/05 - Added method to delete section
* Revised by rashmi 4/26 add signature for sort sections
 */
public interface SectionService{
	public void insertSection(ModuleObjService module, SectionObjService section, String contentPath) throws Exception;
	public void editSection(ModuleObjService module, SectionObjService section,String dataPath) throws Exception;
	public SectionObjService getSection(int moduleId, int seqNo);
	
	// used by view pages -- Mallika pages
   public void setSection(SectionObjService sec);
   public List getSections(int moduleId);
   public void setSections(List sections);
   public void deleteSection(SectionObjService sec);
   public void updateSectionsSequence(List newSeqList) throws Exception;
	
	
}