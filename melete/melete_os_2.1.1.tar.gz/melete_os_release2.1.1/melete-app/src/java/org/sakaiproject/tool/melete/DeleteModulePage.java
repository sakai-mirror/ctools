/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-app/src/java/org/sakaiproject/tool/melete/DeleteModulePage.java,v 1.2 2006/03/09 19:43:10 mallikat Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.tool.melete;

import java.io.File;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
//import org.sakaiproject.jsf.ToolBean;
import org.sakaiproject.service.framework.log.Logger;
import org.sakaiproject.api.app.melete.ModuleDateBeanService;
import org.sakaiproject.api.app.melete.ModuleService;
import org.sakaiproject.api.app.melete.SectionService;
import org.sakaiproject.api.app.melete.SectionObjService;
/**
 * @author Mallika
 *
 * Delete Module Page is the backing bean for the page delete_module.jsp.
 * It also connects to other jsp pages like confirm_delete.jsp and
 * list_auth_modules.jsp
 * 
 * Mallika - 5/2/05 - Added functionality to delete module directory
 * Mallika - 3/7/06 - Removing instr_id from path
 */

public class DeleteModulePage implements Serializable/*,ToolBean*/{
	protected ModuleDateBeanService mdbean;
	protected SectionObjService section;
	 /** Dependency:  The logging service. */
	protected Logger logger = null;
	protected ModuleService moduleService;
	protected SectionService sectionService;
	private boolean success;
	private boolean moduleSelected;
	private boolean sectionSelected;
	
    public DeleteModulePage(){
       	this.mdbean = null;
    	this.section = null;     	
    }

  	/*
	 * setting module 
	 */
	public void setMdbean(ModuleDateBeanService mdbean)
	{
		this.mdbean = mdbean;
	}

	public ModuleDateBeanService getMdbean()
	{
		return this.mdbean;
	}
  	/*
	 * setting section 
	 */
	public void setSection(SectionObjService section)
	{
		this.section = section;
	}	
	public SectionObjService getSection()
	{
		return this.section;
	}
	
	public void setSuccess(boolean success)
	{
		this.success = success;
	}   	
	public boolean getSuccess()
	{
		return success;
	}	
	public void setModuleSelected(boolean moduleSelected)
	{
		this.moduleSelected = moduleSelected;
	}   	
	public boolean getModuleSelected()
	{
		return moduleSelected;
	}	
	public void setSectionSelected(boolean sectionSelected)
	{
		this.sectionSelected = sectionSelected;
	}   	
	public boolean getSectionSelected()
	{
		return sectionSelected;
	}	
	protected String createDataPath()
	{
	     StringBuffer dataPath=new StringBuffer();
	     	     	// get instructor_id    	// get course_id     	
	     FacesContext context = FacesContext.getCurrentInstance();
		 Map sessionMap = context.getExternalContext().getSessionMap();
	     String instr_id=(String)sessionMap.get("userId");
	     String courseId=(String)sessionMap.get("courseId");
	     String homeDir = context.getExternalContext().getInitParameter("homeDir");
	     //System.out.println("homedirectory in sectionpage found"+homeDir);
			
	    
	     //Mallika - comments beg
	     //dataPath.append(homeDir+File.separator+"meleteDocs"+File.separator+"instr_"+instr_id+File.separator+"course_"+courseId+File.separator);
	     //Mallika - comments end
	     
	     //Mallika - new code beg
	     dataPath.append(homeDir+File.separator+"meleteDocs"+File.separator+"course_"+courseId+File.separator);
	     //Mallika - new code end
	     
	     
	     //dataPath.append("module_"+this.module.getModuleId()+File.separator);
	    
	  //  logger.info("DATAPATH :" + dataPath); 	 
	    return dataPath.toString();	     
	}	
    /*
     * Called by the jsp page to delete the module or section and redirect to the confirmation page.
     */
    public String deleteAction()
    {
        //logger.info("addContentSections called");
        if(moduleService == null)
        	moduleService = getModuleService();    	
        FacesContext context = FacesContext.getCurrentInstance();
        ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
        		context.getViewRoot().getLocale());        
        // actual delete
		try{
			if (getModuleSelected() == true)
			{
			  String dataPath = createDataPath();	
			  logger.info("Delete path is "+dataPath);
			  moduleService.deleteModule(this.mdbean, dataPath+"module_"+this.mdbean.getModuleId());
			}
			if (getSectionSelected() == true)
			{
			  sectionService.deleteSection(this.section);	
			}
			
		}catch(Exception ex)
		{
			//logger.error("mbusiness insert module failed:" + ex.toString());
			String errMsg = bundle.getString("delete_module_fail");
	     	context.addMessage (null, new FacesMessage(errMsg));
			return "delete_module";
		}
		setSuccess(true);
       return "confirm_delete_module";
    }
    
	public String backToModules()
	{
		setMdbean(null);
		setModuleSelected(false);
		setSection(null);
		setSectionSelected(false);
		return "list_auth_modules";
	}

	/**
	 * @return naviagtion rule on click of cancel button
	 */
	public String cancel()
	{
		setMdbean(null);
		setModuleSelected(false);
		setSection(null);
		setSectionSelected(false);		
		return "list_auth_modules";
	}    
	/**
	 * @return Returns the ModuleService.
	 */
	public ModuleService getModuleService() {
		return moduleService;
	}
	/**
	 * @param ModuleService The ModuleService to set.
	 */
	public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	}	
	/**
	 * @return Returns the SectionService.
	 */
	public SectionService getSectionService() {
		return sectionService;
	}
	/**
	 * @param SectionService The SectionService to set.
	 */
	public void setSectionService(SectionService sectionService) {
		this.sectionService = sectionService;
	}		
	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	/**
	 * @return Returns the logger.
	 */
	public Logger getLogger() {
		return logger;
	}	
 }
