/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-app/src/java/org/sakaiproject/tool/melete/RemoteBrowserFile.java,v 1.2 2006/03/09 19:43:10 mallikat Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/

package org.sakaiproject.tool.melete;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.faces.component.UIColumn;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import org.sakaiproject.service.framework.log.Logger;
import org.sakaiproject.service.framework.config.ServerConfigurationService;
import org.sakaiproject.service.framework.portal.cover.PortalService;

/**
 * @author Rashmi
 * Created on Jan 7, 2005
 * 
 * To get the server side files for wysiwyg editor remote browse 
 *
 * revised on 3/17/05 by rashmi to get home directory from web.xml
 * and file separator linux and window compatibility
 * Mallika - 3/7/06 - Removing instr_id from path
 */
class FileExtensionFilter implements FilenameFilter
{
	private String ext="*";
	private String ext1=".gif";
	private String ext2=".jpg";
	   public FileExtensionFilter(String ext){
	     this.ext = ext;
	   }
	   public boolean accept(File dir, String name){
	     if (name.endsWith(ext1) ||name.endsWith(ext2) )
	       return true;
	     return false;
	   }

}
public class RemoteBrowserFile{
	private String fileName;
	private long size;
	private Date modifiedDate;
	String instr_id="1";
    String course_id="0";

    private HtmlPanelGrid filesTable = new HtmlPanelGrid();
    private ServerConfigurationService serverConfigurationService;
    private Logger logger = null;
    private String remoteDirLocation;
    private String commonDirLocation;
    	
	public RemoteBrowserFile()
	{
		this.fileName = null;
		this.size = 0;
		this.modifiedDate = null;
	}
	
	public RemoteBrowserFile(String filename, long sz, long mdate)
	{
		this.fileName = filename;
		this.size = sz;
		this.modifiedDate = new Date(mdate);
	}
	
	public String getFileName()
	{
		return fileName;
	}
	
	public long getSize()
	{
		return size;
	}
	
	public Date getModifiedDate()
	{
		return modifiedDate;
	}
	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}
	
	public void setSize(long size)
	{
		this.size = size;
	}
	
	public void setModifiedDate(Date modifiedDate)
	{
		this.modifiedDate = modifiedDate;
	}
	
	/**
	 * @return remote directory location 
	 */
	public String getRemoteDirLocation()
	{
		logger.info("###########getRemoteDirLocation"+serverConfigurationService.getServerUrl());
		return serverConfigurationService.getServerUrl()+"/sakai-melete-tool/melete/remotefilebrowser.jsf";
	}
	
	/**
	 * @return remote server common uploads location
	 */
	public String getCommonDirLocation()
	{
		return serverConfigurationService.getServerUrl()+"/sakai-melete-tool/melete/commonfilebrowser.jsf";
	}
	
	/*
	 * revised on 1/24
	 * to fix bug#238
	 * revised to make it work for linux - rashmi 03/17
	 */
	public List getRemoteBrowserFiles()
	{
			
		ArrayList remoteFiles = new ArrayList();
		try{
		// 1.1 file name
		 FacesContext context = FacesContext.getCurrentInstance();
		 Map sessionMap = context.getExternalContext().getSessionMap();	
	   
		 String instr_id=(String)sessionMap.get("userId");
	     String course_id=(String)sessionMap.get("courseId");
	     
	     ValueBinding binding =
            Util.getBinding("#{meleteSiteAndUserInfo}");
	     MeleteSiteAndUserInfo mPage = (MeleteSiteAndUserInfo)
        binding.getValue(context);
		 course_id=mPage.getCourse_id();
     	     
	     String homeDir = context.getExternalContext().getInitParameter("homeDir");  
	     
	     //Mallika - comments beg
	     //String dataPath =homeDir+File.separator+"meleteDocs"+File.separator+"instr_"+instr_id+File.separator+"course_" +course_id+File.separator+"uploads";
	     //Mallika - comments end
	     
	     //Mallika - new code beg
	     String dataPath =homeDir+File.separator+"meleteDocs"+File.separator+"course_" +course_id+File.separator+"uploads";
	     //Mallika - new code end
	     
	     logger.info("get remote browser files fn called"+dataPath);
	     
	     File f = new File(dataPath);
	 //    FileExtensionFilter filter = new FileExtensionFilter(".gif");
	//     File[] fs = f.listFiles(filter);
	     File[] fs = f.listFiles();
	     
	     if(fs == null || fs.length == 0)
	     {
	     	return remoteFiles;
	     }
	     // 2. add to list the instance of class
	     for(int i=0; i < fs.length; i++)
	     {
	     	if(fs[i].isFile())
	     	{
	     	RemoteBrowserFile ob = new RemoteBrowserFile(fs[i].getName(), fs[i].length(), fs[i].lastModified());
	     	remoteFiles.add(ob);
	     	}
	     }
	 	
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return remoteFiles;
	}
	
	/*
	 * revised on 1/24
	 * to fix bug#238
	 * revised for directory structure linux compatibility - rashmi - 03/17
	 */		
	public List getRemoteCommonFiles()
	{
		ArrayList remoteCommonFiles = new ArrayList(); 
		try{
		// 1.1 file name
		 FacesContext context = FacesContext.getCurrentInstance();
		 Map sessionMap = context.getExternalContext().getSessionMap();	
	   
		 String instr_id=(String)sessionMap.get("userId");
		 String homeDir = context.getExternalContext().getInitParameter("homeDir");
		 
		 
	     String dataPath =homeDir+File.separator+"meleteDocs"+File.separator+"instr_"+instr_id+File.separator+"common_files";
	  
	     
	  //   System.out.println("get common files fn called" + dataPath);
	     File f = new File(dataPath);
	     FileExtensionFilter filter = new FileExtensionFilter(".gif");
	     File[] fs = f.listFiles();
	    
	     if(fs == null || fs.length == 0)
	     {
	     	return remoteCommonFiles;
	     }
	     // 2. add to list the instance of class
	     for(int i=0; i < fs.length; i++)
	     {
	     	if(fs[i].isFile())
	     	{
	     	RemoteBrowserFile ob = new RemoteBrowserFile(fs[i].getName(), fs[i].length(), fs[i].lastModified());
	     	remoteCommonFiles.add(ob);
	     	}
	     }
	 	
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return remoteCommonFiles;
	}
	
	public String showRemoteCommonFiles()
	{
		// getRemoteCommonFiles();
		// and set the h:datatable contents to this list
		return "common";
	}
	
	public HtmlPanelGrid getFilesTable() {
		return null;
	}
	
	public void setFilesTable(HtmlPanelGrid filesTable){
		try
		{
		String var="rbf";
		filesTable.setColumns(2);
		List list = filesTable.getChildren();
		list.clear();
		
		UIColumn col,col1,col3;
		HtmlOutputText out;
	
		ArrayList remoteCommonFiles = (ArrayList)getRemoteCommonFiles();
		 for(int i=0; i < remoteCommonFiles.size(); i++)
			{
	
		 	HtmlCommandButton cbutton = new HtmlCommandButton();
		 	RemoteBrowserFile cm = (RemoteBrowserFile)remoteCommonFiles.get(i);
		    cbutton.setValue(cm.getFileName());
		 	 col1 = new UIColumn();
			 col1.getChildren().add(cbutton);
			 HtmlOutputText headerText = new HtmlOutputText();
			 headerText.setValue(new Long(cm.getSize()));
		 	 col = new UIColumn();
	         col.getChildren().add(headerText);
	         HtmlOutputText headerText3 = new HtmlOutputText();
			 headerText3.setValue(cm.getModifiedDate());
		 	 col3 = new UIColumn();
	         col3.getChildren().add(headerText3);
             list.add(col1);	
			 list.add(col);
			 list.add(col3);
			}
		 	
		 	this.filesTable = filesTable;
		 	
		// System.out.println("out of files table ");
		}catch(Exception e)
		{
			e.printStackTrace();
		}		
	}
	
	/**
	 * @return Returns the serverConfigurationService.
	 */
	public ServerConfigurationService getServerConfigurationService() {
		return serverConfigurationService;
	}
	/**
	 * @param serverConfigurationService The serverConfigurationService to set.
	 */
	public void setServerConfigurationService(
			ServerConfigurationService serverConfigurationService) {
		this.serverConfigurationService = serverConfigurationService;
	}
	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
	
}

