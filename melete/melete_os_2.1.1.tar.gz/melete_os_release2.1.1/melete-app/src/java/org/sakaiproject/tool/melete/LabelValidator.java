/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-app/src/java/org/sakaiproject/tool/melete/LabelValidator.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.tool.melete;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.faces.application.FacesMessage;

//import com.sun.faces.util.MessageFactory;

import java.util.ResourceBundle;
import java.util.StringTokenizer;
/**
 * @author Mallika
 *
 * This class validates user input for module label 
 * Mallika - 5/23/05 - Did bug fix for space code
 **/

public class LabelValidator implements Validator {
	
	public void validate(FacesContext context, UIComponent component, Object value)
	throws ValidatorException
	{
		String val = (String) value;
		val = val.trim();
		int len =val.length();
	
		if(len < 3 || len > 15)
		{
			ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
            		context.getViewRoot().getLocale());
			String errMsg = "";
	     	errMsg = bundle.getString("invalid_label_len");
	        throw new ValidatorException(new FacesMessage(errMsg));
		}
		if (!isValidLabel(val))
		{
			ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
            		context.getViewRoot().getLocale());
			String errMsg = "";
	     	errMsg = bundle.getString("invalid_label");
	        throw new ValidatorException(new FacesMessage(errMsg));
		}
	}
	/**
	 * @param title
	 * @return
	 * Revision -- 11/29 Rashmi 
	 * check if string is empty or just spaces
	 *
	 */
	public boolean isValidLabel(String label)
	{
		String[] spaces = label.split("\\s");
		
		if (spaces.length > 2)
		{
			System.out.println("Too many spaces");
			return false;
		}

		int len =label.length();
			
		for(int i=0; i < len; i++)
		{
			char c = label.charAt(i);
			
			if (!Character.isLetter(c)&&!Character.isSpace(c))
				{
					System.out.println("label is not valid.");
					return false;
				}					
		}
		return true;
	}
	

}