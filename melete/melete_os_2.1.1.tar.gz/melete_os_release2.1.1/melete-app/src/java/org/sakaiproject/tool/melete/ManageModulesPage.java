/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-app/src/java/org/sakaiproject/tool/melete/ManageModulesPage.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/

package org.sakaiproject.tool.melete;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIColumn;
import javax.faces.component.UIInput;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.sakaiproject.component.app.melete.Module;
//import org.sakaiproject.jsf.ToolBean;
import org.sakaiproject.service.framework.log.Logger;
import org.sakaiproject.api.app.melete.CourseModuleService;
import org.sakaiproject.api.app.melete.ModuleObjService;
import org.sakaiproject.api.app.melete.ModuleService;
import org.sakaiproject.api.app.melete.SectionObjService;
import org.sakaiproject.api.app.melete.SectionService;
/**
 * @author Rashmi
 * Created on Jan 11, 2005
 * revised on 3/29 by rashmi to make restore button unclickable if no modules are present 
 * Mallika - 4/22/05 - Added the association to go to module label
 * Rashmi - 5/23/05 - sort sections went blank when there are no modules
 */
public class ManageModulesPage implements Serializable/*,ToolBean*/{

	// attributes
	// restore modules
	int count;
	private List archiveModulesList;
	private List restoreModulesList;
	private boolean shouldRenderEmptyList;
	private boolean falseBool = false;
	
	// sort modules
	private List currModulesList;
	private List currList;
	private String currSelectedModule;
	private int size =0;
	private int isOne = 1;
	private List newModulesList;
	private List newList;
	private String newSelectedModule;
	// sort sections
	private String formName;
	private List allModulesList;
	private List allModules;
	private String currModule;
	private int showSize;
	
	 private HtmlPanelGrid seqTable,seqTable1;
	/** Dependency:  The logging service. */
	protected Logger logger = null;
	protected ModuleService moduleService;
	protected SectionService sectionService;
	/**
	 * constructor
	 */
	public ManageModulesPage() {
		count=0;
		restoreModulesList = new ArrayList();
		shouldRenderEmptyList=false;
		archiveModulesList = null;
		currModulesList = null;
		currList = new ArrayList();
		newList = new ArrayList();
		newSelectedModule="1";
		formName=" ";
		allModulesList = new ArrayList();
	//	currModule = "1";
	//	noModuleSelected = false;
	}
		
	/**
	 * @return
	 */
	public List getArchiveModulesList()
	{
		try{
			if(archiveModulesList == null)
			{
			restoreModulesList=null;
			FacesContext context = FacesContext.getCurrentInstance();
			Map sessionMap = context.getExternalContext().getSessionMap();	
			
			String courseId = (String)sessionMap.get("courseId");
			
			archiveModulesList = getModuleService().getArchiveModules(courseId);
			}
		} catch(Exception e)
		{
			logger.error("getting archived modules list "+e.toString());
		}
		return archiveModulesList;
	}
	
	/**
	 * @return
	 */
	public List getRestoreModulesList()
	{
		return restoreModulesList;
	}
	
	/**
	 * @return
	 */
	public boolean getShouldRenderEmptyList()
	{
		if (archiveModulesList == null || archiveModulesList.size() == 0)
		{
			return true;
		}else return false;
	}
	
	/*
	 * added by rashmi on 3/29 to not render restore commandlink if modules are not present
	 */
	public boolean getFalseBool()
	{
		return false;
	}
	/*
	 * adding listener
	 */
  public void selectedRestoreModule(ValueChangeEvent event)throws AbortProcessingException 
	{
  		FacesContext context = FacesContext.getCurrentInstance();
		UIInput mod_Selected = (UIInput)event.getComponent();
		
		if(((Boolean)mod_Selected.getValue()).booleanValue() == true)
		  {
			String selclientId = mod_Selected.getClientId(context);
			selclientId = selclientId.substring(selclientId.indexOf(':')+1);
			selclientId = selclientId.substring(selclientId.indexOf(':')+1);
			
			String modId = selclientId.substring(0,selclientId.indexOf(':'));
		//	System.out.println("mod id:" +modId);
			int selectedModIndex=Integer.parseInt(modId);
			
			if(restoreModulesList == null)
				restoreModulesList = new ArrayList();
			
			restoreModulesList.add(archiveModulesList.get(selectedModIndex));
			count++;
			
		  }
		return;
	}
  
	  /**
	 * @return
	 */
	public String restoreModules()
	  {
		
		FacesContext context = FacesContext.getCurrentInstance();
	    ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
	                		context.getViewRoot().getLocale());
	    
		if(count <=0)
		{
			String errMsg = bundle.getString("no_module_selected");
			context.addMessage (null, new FacesMessage(errMsg));
			return "restore_modules";
		}
		// 1. restore modules
		try{
			getModuleService().restoreModules(restoreModulesList);
			count=0;
			} 
		catch(Exception me)
			{
				
				String errMsg = bundle.getString("restore_module_fail");
				context.addMessage (null, new FacesMessage(errMsg));
				return "restore_modules";
			} 
		
		// 2. clear archivelist
			archiveModulesList = null;
			
	  	return "confirm_restore_modules";
	  }
	
	/**
	 * clear lists on cancel
	 */
	public String cancelRestoreModules()
	{
		archiveModulesList = null;
		restoreModulesList= null;
		count=0;
		return "modules_author_manage";
	}
	
	/**
	 *navigates manage modules page on cancel
	 */
	public String cancel()
	{
		return "modules_author_manage";
	}
	
	/**
	 * sort in ascending order
	 */
	public String sortOnDate()
	{
	//	System.out.println("sort function called");
		if(archiveModulesList == null)
		{
			return "restore_modules";
		}
		Collections.sort(archiveModulesList, new MeleteDateComparator());
//		System.out.println(archiveModulesList);
		return "restore_modules";
	}
	
	/*
	 * navigation rule to go to restore page 
	 */
	public String goToRestoreModules(){
		return "restore_modules";
	}
	
	/*
	 * navigation rule for Return  
	 */
	public String returnToModules(){
		return "list_auth_modules";
	}
	public String changeModuleLabel(){
		return "module_label";
	}	
	
	/**
	 * gets navigation page to import export modules
	 * @return
	 */
	public String importExportModules(){
		return "importexportmodules";
	}
	
	/*
	 * Reset all values
	 */
	public void resetValues()
	{
		archiveModulesList = null;
		restoreModulesList= null;
		count=0;
		currModulesList = null;
		currList= null;
		size =0;
		newModulesList= null;
		newList= null;
		newSelectedModule="1";	
		allModules=null;
		allModulesList=null;
		formName=" ";
		currModule=null;
	}
	
	/**
	 * @return navigation for sort modules
	 */
	public String goToSortModules(){
		resetValues();
		return "modules_sort";
	}
	
	/**
	 * @return navigation for sort modules
	 */
	public String saveSortSequence(){

		FacesContext context = FacesContext.getCurrentInstance();
	    ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
	                		context.getViewRoot().getLocale());	
		try{
			getModuleService().updateModuleSequence(newModulesList);
			String infoMsg = bundle.getString("save_module_seq_success");
			FacesMessage msg =
		  		new FacesMessage("Changes Saved", infoMsg);
		  	msg.setSeverity(FacesMessage.SEVERITY_INFO);
		  	context.addMessage (null, msg);
		} 
		catch(Exception me)
			{
				
				String errMsg = bundle.getString("save_module_seq_fail");
				FacesMessage msg =
			  		new FacesMessage("Changes Saved", errMsg);
			  	msg.setSeverity(FacesMessage.SEVERITY_ERROR);
				context.addMessage (null, msg);
				return "modules_sort";
			} 
		
		return "modules_author_manage";
	}
	
	/**
	 * @return navigation on cancel of sort modules
	 */
	public String cancelSort(){
		return "modules_author_manage";
	}
	
	/*
	 * get the current seq of modules
	 */
	public List getCurrList()
	{
		try{
			if(currModulesList == null)
			{
			FacesContext context = FacesContext.getCurrentInstance();
			Map sessionMap = context.getExternalContext().getSessionMap();	
			
			String courseId = (String)sessionMap.get("courseId");
			currModulesList = new ArrayList();
			if(!formName.equals("SortSectionForm"))
				{
					currModulesList = getModuleService().getSortModules(courseId);
				}
			else 
				{
					if (allModules.size() > 0)
					{
						if(currModule == null || currModule.length()==0)
						{
						Object[] pair = (Object[]) allModules.get(0);
						currModule = ((ModuleObjService)pair[0]).getModuleId().toString();
						}
						int modId= new Integer(currModule).intValue();
						currModulesList = getSectionService().getSections(modId);
					}
					else currModulesList = null;
				}
			currList  = forSelectItemsList(currModulesList);
		//	System.out.println("currList size is "+ currList.size());
			}
		} catch(Exception e)
		{
			logger.error("error in getting currList "+e.toString());
		}
		return currList;
	}
	
	/*
	 * converts the coursemodule list to selectItems for displaying at 
	 * the list boxes in the JSF page 
	 */
	private List forSelectItemsList(List list)
	{
		List selectList = new ArrayList();
		   // Adding available list to select box
	      if(list == null || list.size()==0)
	      {
	      	 if(formName.equals("SortSectionForm"))
	      	 {
	      	 	selectList.add(new SelectItem("0", "No Sections"));
	      	 }
	      	 else
	      	 	selectList.add(new SelectItem("0", "No Modules"));
	      	 return selectList;
	      }

	      Iterator itr = list.iterator();
	      int countidx=0;
	      if(!formName.equals("SortSectionForm"))
	      {
		  	  while (itr.hasNext()) {
		  	  		countidx++;
		  	  		CourseModuleService  cm = (CourseModuleService) itr.next();
		  	  		String value = new Integer(countidx).toString();
		  	  		String label = cm.getModule().getTitle();
		  	 		selectList.add(new SelectItem(value, label));
		  		}
	      }
	      else
	      {
	        while (itr.hasNext()) {
	  	  		countidx++;
	  	  		SectionObjService  ss = (SectionObjService) itr.next();
	  	  		String value = new Integer(countidx).toString();
	  	  		String label = ss.getTitle();
	  	  		selectList.add(new SelectItem(value, label));
	  		}
	      }
		return selectList;
	}
	
	public String getCurrSelectedModule()
	{
		return currSelectedModule;
	}
	
	/**
	 * @param currSelectedModule The currSelectedModule to set.
	 */
	public void setCurrSelectedModule(String currSelectedModule) {
		this.currSelectedModule = currSelectedModule;
	}
	
	/**
	 * @return Returns the size.
	 */
	public int getSize() {
		if(currList !=null)
		{
		size = currList.size();
		} 
		return size;
	}
	
	public int getIsOne()
	{
		return isOne;
	}
	/**
	 * @return Returns the ModuleService.
	 */
	public ModuleService getModuleService() {
		return moduleService;
	}
	/**
	 * @param ModuleService The ModuleService to set.
	 */
	public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	}
	/**
	 * @return Returns the logger.
	 */
	
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
	
	
	/**
	 * @return Returns the newList.
	 */
	public List getNewList() {
		try{
			if(newModulesList == null)
			{
				newModulesList = currModulesList;
				newList  = forSelectItemsList(newModulesList);
			}
			
		} catch(Exception e)
		{
			logger.error("error in getting currList "+e.toString());
		}
		return newList;
	}
	/**
	 * @param newList The newList to set.
	 */
	public void setNewList(List newList) {
		this.newList = newList;
	}
	/**
	 * @return Returns the newSelectedModule.
	 */
	public String getNewSelectedModule() {
		return newSelectedModule;
	}
	/**
	 * @param newSelectedModule The newSelectedModule to set.
	 */
	public void setNewSelectedModule(String newSelectedModule) {
		this.newSelectedModule = newSelectedModule;
	}
	
	/**
	 * move the selected item to the top of the list
	 */
	public String upEnd()
	{
		System.out.println("up end called");
		int selIndex = new Integer(newSelectedModule).intValue() -1;
		if(selIndex > 0)
		{
			 int startIdx = selIndex;
			  Object lastTemp = newModulesList.get(selIndex);
			  while(startIdx > 0)
			  {
			  		Object temp = newModulesList.get(startIdx);
			  		newModulesList.set(startIdx,newModulesList.get(startIdx-1));
			  		newModulesList.set(startIdx-1,temp);
			  		startIdx--;
			  }
		newList  = forSelectItemsList(newModulesList);
		newSelectedModule="1";
		}
		if(!formName.equals("SortSectionForm"))
			return "modules_sort";
		else return "sections_sort";
	}
	
	/**
	 * move the selected item one up the list
	 */
	public String upOne()
	{
		int selIndex = new Integer(newSelectedModule).intValue() -1;
		if(selIndex > 0)
		{
		Object temp = newModulesList.get(selIndex);
		newModulesList.set(selIndex,newModulesList.get(selIndex-1));
		newModulesList.set(selIndex-1,temp);
		newList  = forSelectItemsList(newModulesList);
		newSelectedModule = new Integer(selIndex).toString();
		}
		if(!formName.equals("SortSectionForm"))
			return "modules_sort";
		else return "sections_sort";
	}
	
	/**
	 * move the selected item to the last of the list
	 */
	public String downEnd()
	{
		int selIndex = new Integer(newSelectedModule).intValue() -1;
		int lastIndex = newModulesList.size() -1;
		if(selIndex > -1)
		{
		  int startIdx = selIndex;
		  Object lastTemp = newModulesList.get(selIndex);
		  while(startIdx <lastIndex)
		  {
		  	Object temp = newModulesList.get(startIdx);
		  	newModulesList.set(startIdx,newModulesList.get(startIdx+1));
		  	newModulesList.set(startIdx+1,temp);
		  	startIdx++;
		  }
		  
		newList  = forSelectItemsList(newModulesList);
		newSelectedModule = new Integer(lastIndex+1).toString();
		}
		if(!formName.equals("SortSectionForm"))
			return "modules_sort";
		else return "sections_sort";
	}
	
	/**
	 * move the selected item one down the list
	 */
	public String downOne()
	{
		int selIndex = new Integer(newSelectedModule).intValue() -1;
		if(selIndex > -1 && selIndex < newModulesList.size() -1)
		{
		Object temp = newModulesList.get(selIndex);
		newModulesList.set(selIndex,newModulesList.get(selIndex+1));
		newModulesList.set(selIndex+1,temp);
		newList  = forSelectItemsList(newModulesList);
		if(selIndex == newModulesList.size() -1)
		{
			newSelectedModule = new Integer(selIndex+1).toString();
		}
		else newSelectedModule = new Integer(selIndex+2).toString();
		}
		if(!formName.equals("SortSectionForm"))
			return "modules_sort";
		else return "sections_sort";
	}
	
	public String gotoSortSections()
	{
			resetValues();
			//fetch the first module and its sections
			setFormName("SortSectionForm");
			return "sections_sort";
	}
	/**
	 * @return Returns the formName.
	 */
	public String getFormName() {
		return formName;
	}
	/**
	 * @param formName The formName to set.
	 */
	public void setFormName(String formName) {
		this.formName = formName;
	}
	
	public List getAllModulesList()
	{
		if(allModules == null || allModulesList == null )
		{
		FacesContext context = FacesContext.getCurrentInstance();
		Map sessionMap = context.getExternalContext().getSessionMap();	
		
		String courseId = (String)sessionMap.get("courseId");
		allModules = moduleService.getModules(courseId);
		allModulesList = new ArrayList();
		   // Adding available list to select box
	      if(allModules == null || allModules.size()==0)
	      {
	      	allModulesList.add(new SelectItem("0", "No Modules"));
	      	 return allModulesList;
	      }

	      Iterator itr = allModules.iterator();
	      int countidx=0;
	      while (itr.hasNext()) {
		  	  	Object[] pair = (Object[]) itr.next();
		     	ModuleObjService  module = (ModuleObjService) pair[0];
		     	if(module !=null)
		     		{
			     	String value = module.getModuleId().toString();
			  	  	String label = "Module "+(++countidx)+": "+module.getTitle();
			  	 	//	System.out.println("sort modules page value label: " + value + label);
			  	  	allModulesList.add(new SelectItem(value, label));
			     	}
		  		}
		}
		return allModulesList;
	}
	/**
	 * @return Returns the currModule.
	 */
	public String getCurrModule() {
		return currModule;
	}
	/**
	 * @param currModule The currModule to set.
	 */
	public void setCurrModule(String currModule) {
		this.currModule = currModule;
	}
	
	public int getShowSize()
	{
		showSize = 6;
		if(currList !=null && currList.size() > 6)
		{
			showSize = currList.size();
		}
		return showSize;
	}
	
	public void nextModuleSections(ValueChangeEvent event)throws AbortProcessingException
	{
		UIInput moduleSelect = (UIInput)event.getComponent();
		String selModId = (String)moduleSelect.getValue();
		int modId= new Integer(selModId).intValue();
		currModulesList = getSectionService().getSections(modId);
		currList  = forSelectItemsList(currModulesList);
		newModulesList = null;
		newList = null;
	}
	
	public String saveSortSectionsSeq(){

		FacesContext context = FacesContext.getCurrentInstance();
	    ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
	                		context.getViewRoot().getLocale());	
		try{
			getSectionService().updateSectionsSequence(newModulesList);
			String infoMsg = bundle.getString("save_section_seq_success");
			FacesMessage msg =
		  		new FacesMessage("Changes Saved", infoMsg);
		  	msg.setSeverity(FacesMessage.SEVERITY_INFO);
		  	context.addMessage (null, msg);
		} 
		catch(Exception me)
			{
				String errMsg = bundle.getString("save_section_seq_fail");
				FacesMessage msg =
			  		new FacesMessage(errMsg, errMsg);
			  	msg.setSeverity(FacesMessage.SEVERITY_ERROR);
				context.addMessage (null, msg);
				return "sections_sort";
			} 
		
		return "modules_author_manage";
	}
	
	public HtmlPanelGrid getSeqTable() {
		return null;
	}

	public void setSeqTable(HtmlPanelGrid seqTable){
		try
		{
		String var="seqs";
		seqTable.setColumns(1);
		List list = seqTable.getChildren();
		list.clear();

		UIColumn col;
		HtmlOutputText out;

		
		 for(int i=1; i <= getSize(); i++)
			{
		 	HtmlOutputText headerText1 = new HtmlOutputText();
			 headerText1.setValue(new Integer(i));
		 	 col = new UIColumn();
			 col.getChildren().add(headerText1);
			  list.add(col);
			}

		 	this.seqTable = seqTable;

		 // System.out.println("out of finish table section part");
		}catch(Exception e)
		{
			logger.error(e.toString());
		}
	}
	
	public HtmlPanelGrid getSeqTable1() {
		return null;
	}

	public void setSeqTable1(HtmlPanelGrid seqTable1){
		try
		{
		String var="seqs";
		seqTable1.setColumns(1);
		List list = seqTable1.getChildren();
		list.clear();

		UIColumn col;
		HtmlOutputText out;

		
		 for(int i=1; i <= getSize(); i++)
			{
		 	HtmlOutputText headerText1 = new HtmlOutputText();
			 headerText1.setValue(new Integer(i));
		 	 col = new UIColumn();
			 col.getChildren().add(headerText1);
			  list.add(col);
			}

		 	this.seqTable1 = seqTable1;

		 // System.out.println("out of finish table section part");
		}catch(Exception e)
		{
			logger.error(e.toString());
		}
	}
	
	/**
	 * @return Returns the sectionService.
	 */
	public SectionService getSectionService() {
		return sectionService;
	}
	/**
	 * @param sectionService The sectionService to set.
	 */
	public void setSectionService(SectionService sectionService) {
		this.sectionService = sectionService;
	}
}
