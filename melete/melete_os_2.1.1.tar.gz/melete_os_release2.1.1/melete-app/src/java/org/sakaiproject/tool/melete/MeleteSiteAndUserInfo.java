/*
 * Created on 02 Feb 2005
 *
 */


package org.sakaiproject.tool.melete;

import java.util.Map;

import javax.faces.context.FacesContext;

import org.sakaiproject.api.app.melete.MeleteSecurityService;
import org.sakaiproject.api.app.melete.ModuleService;
import org.sakaiproject.exception.IdUnusedException;
import org.sakaiproject.service.framework.config.ServerConfigurationService;
import org.sakaiproject.service.framework.log.Logger;
import org.sakaiproject.service.framework.portal.cover.PortalService;
import org.sakaiproject.service.legacy.entity.ResourceProperties;
import org.sakaiproject.service.legacy.site.Site;
import org.sakaiproject.service.legacy.site.cover.SiteService;
import org.sakaiproject.service.legacy.user.User;
import org.sakaiproject.service.legacy.user.cover.UserDirectoryService;

/**
 * @author Foothill college
 *
 * 5/10/05 - Mallika - added getuploadsize to add max upload size to sessionMap
 * Rashmi - 5/26/05 revised processnavigate() and added refresh of sessionmap
 * Rashmi - 06/13/05 - add commondirlocation() and revised remote location function for the right url
 * Rashmi - 06/23/05 - add editorarchivelocation() to get the full path for applet jar for Mac installs
 * Mallika - 3/7/06 - Removing instr_id from path 
 **/
public class MeleteSiteAndUserInfo {

	/*
	 * course site properties
	 */
	//Names of state attributes corresponding to properties of a site - From siteAction.java
	private final static String PROP_SITE_TERM = "term";

	/*******************************************************************************
	* Dependencies
	*******************************************************************************/
	/** Dependency:  The logging service. */
	protected Logger logger = null;

    /** Dependency: The Melete Security service. */
    protected MeleteSecurityService meleteSecurityService;

    protected ModuleService moduleService;

	// added by rashmi
	private ServerConfigurationService serverConfigurationService;

	private String course_id;
	
	/**
	 * constructor added by rashmi
	 */
	public MeleteSiteAndUserInfo() {
	}

	/**
	 * gets the current user
	 * @return Returns the user currently logged in to the system
	 */
	public User getCurrentUser(){
	    return UserDirectoryService.getCurrentUser();
	}

	/**
	 * gets the current site infromation
	 * @return Returns the site object
	 */
	public Site getCurrenSite()throws Exception{
	    try {
			return SiteService.getSite(PortalService.getCurrentSiteId());
		} catch (IdUnusedException e) {
			throw new Exception(e);
		}
	}


	/**
	 * gets the assigned term to the course
	 * @return Returns the course term as Month Year
	 */
	public String getCourseTerm() throws Exception{
		try {
			return getSiteProperties().getProperty(PROP_SITE_TERM);
		} catch (Exception e) {
			throw new Exception(e);
		}
	}
	
	/**
	 * gets the title of the course
	 * @return Returns the course title
	 */
	public String getCourseTitle()throws Exception{
		try {
			return SiteService.getSite(PortalService.getCurrentSiteId()).getTitle();
		} catch (Exception e) {
			logger.error(e.toString());
			throw new Exception(e);
		}
	}
	
	/**
	 * gets the description of the course
	 * @return Returns the course description
	 */
	public String getCourseDescription()throws Exception{
		try {
			return SiteService.getSite(PortalService.getCurrentSiteId()).getDescription();
		} catch (Exception e) {
			throw new Exception(e);
		}
	}
	
	/**
	 * Check if the current user has permission as author.
	 * @return true if the current user has permission to perform this action, false if not.
	 */
	public boolean isUserAuthor()throws Exception{

		try {
			return meleteSecurityService.allowAuthor();
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * Check if the current user has permission as student.
	 * @return true if the current user has permission to perform this action, false if not.
	 */
	public boolean isUserStudent()throws Exception{
		try {
			return meleteSecurityService.allowStudent();
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * gets the current site id
	 * @return the current site id
	 */
	public String getCurrentSiteId(){
	    return PortalService.getCurrentSiteId();
	}

	/**
	 * gets the window name encoded
	 * @return
	 */
	public String getWinEncodeName(){
		String element = null;
		String pid = PortalService.getCurrentToolId();
		if (pid != null){
			element = escapeJavascript("Main" + pid);
		}

		return element;
	}

	public void populateMeleteSession()
	{
		FacesContext context = FacesContext.getCurrentInstance();
		Map sessionMap = context.getExternalContext().getSessionMap();
		try {
			//sessionMap.clear();
			

			
			sessionMap.put("courseId", getCurrentSiteId());
			sessionMap.put("userId", getCurrentUser().getId());
			setCourse_id( getCurrentSiteId());
			sessionMap.put("firstName", getCurrentUser().getFirstName());
			sessionMap.put("lastName", getCurrentUser().getLastName());
			sessionMap.put("institute", "Foothill College");
            sessionMap.put("maxSize", String.valueOf(getMaxUploadSize()));
		
			logger.info("Is Author is "+ isUserAuthor());

			if (isUserAuthor()){
				sessionMap.put("role", "INSTRUCTOR");
			}
			else if (isUserStudent()){
				sessionMap.put("role", "STUDENT");
			}
		}catch (Exception e) {
				logger.error(e.toString());
		}
	}
	
	

	/**
	 * Navigates to related landing page based on user is either student or author
	 * @return the name the page to naviagate
	 */
	public String processNavigate(){
		
		try{
		populateMeleteSession();

			if (isUserAuthor()){
				return "list_auth_modules";
			}
			else if (isUserStudent()){
				return "list_modules_student";
			}
		} catch (Exception e) {
			logger.error(e.toString());
		}
		return "list_modules_student";
	}
	
	
	/**
	 * gets the season and year of the term
	 * @return season and year
	 * @throws Exception
	 */
	public String[] getTermSeasonYear() throws Exception {
		String strterm = getCourseTerm();
		if (strterm != null && strterm.trim().length() > 0)
			return strterm.split(" ");
		
		return null;
	}
	
	/**
	 * to get site properties like term(PROP_SITE_TERM), contactemail etc
	 * @return
	 */
	private ResourceProperties getSiteProperties()throws Exception{
		ResourceProperties siteProperties;
		try {
			Site site = SiteService.getSite(PortalService.getCurrentSiteId());
			siteProperties = site.getProperties();
			
			return siteProperties;

		} catch (IdUnusedException e) {
			throw new Exception(e);
		}
	}

	/*
	 * server location
	 */

	/**
	* Return a string based on value that is safe to place into a javascript / html identifier:
	* anything not alphanumeric change to 'x'. If the first character is not alphabetic, a
	* letter 'i' is prepended.
	* @param value The string to escape.
	* @return value fully escaped using javascript / html identifier rules.
	*/
	protected String escapeJavascript(String value){
		if (value == null || value == "") return "";
		try
		{
			StringBuffer buf = new StringBuffer();

			// prepend 'i' if first character is not a letter
			if(! java.lang.Character.isLetter(value.charAt(0)))
			{
				buf.append("i");
			}

			// change non-alphanumeric characters to 'x'
			for (int i = 0; i < value.length(); i++)
			{
				char c = value.charAt(i);
				if (! java.lang.Character.isLetterOrDigit(c))
				{
					buf.append("x");
				}
				else
				{
					buf.append(c);
				}
			}

			String rv = buf.toString();
			return rv;
		}
		catch (Exception e)
		{
			return value;
		}

	}	// escapeJavascript

	/*
	 * server location
	 */
	public String getRemoteBrowseLocation()
	{
		//String remoteurl = serverConfigurationService.getServerUrl() + "/sakai-melete-tool/melete/remotefilebrowser.jsf";
		String remoteurl = serverConfigurationService.getServerUrl() +"/portal/tool/" +PortalService.getCurrentToolId() + "/remotefilebrowser#";
		return remoteurl;
	}

	public String getMeleteDocsLocation()
	{
		//Mallika - comments beg
		//String remoteurl = serverConfigurationService.getServerUrl() + "/meleteDocs/instr_"+getCurrentUser().getId()+"/course_"+getCurrentSiteId()+"/uploads/";
		//Mallika - comments end
		
		//Mallika - new code beg
		String remoteurl = serverConfigurationService.getServerUrl() + "/meleteDocs"+"/course_"+getCurrentSiteId()+"/uploads/";
		//Mallika - new code end
		
		return remoteurl;
	}

	public String getMeleteDocsSaveLocation()
	{
		String remoteurl = serverConfigurationService.getServerUrl() + "/sakai-melete-tool/melete/save.jsf";
		return remoteurl;
	}
	
	public String getCommonDirLocation()
	{
		String remoteurl = serverConfigurationService.getServerUrl() +"/portal/tool/" +PortalService.getCurrentToolId() + "/commonfilebrowser#";
		return remoteurl;
	}
	
	public String getEditorArchiveLocation()
	{
		String remoteurl = serverConfigurationService.getServerUrl() + "/sakai-melete-tool/HTMLEditorAppletEnterprise.jar";
		return remoteurl;
	}
	
	public int getMaxUploadSize()
	{
		int maxSize = serverConfigurationService.getInt("content.upload.max", 2);
		return maxSize;
	}
	/*******************************************************************************
	* setter methods
	*******************************************************************************/

	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	/**
	 * @param meleteSecurityService The meleteSecurityService to set.
	 */
	public void setMeleteSecurityService(
			MeleteSecurityService meleteSecurityService) {
		this.meleteSecurityService = meleteSecurityService;
	}

	/**
	 * @param moduleService The moduleService to set.
	 */
	public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	}

	/**
	 * @param serverConfigurationService The serverConfigurationService to set.
	 */
	public void setServerConfigurationService(
			ServerConfigurationService serverConfigurationService) {
		this.serverConfigurationService = serverConfigurationService;
	}
	/**
	 * @return Returns the course_id.
	 */
	public String getCourse_id() {
		return course_id;
	}
	/**
	 * @param course_id The course_id to set.
	 */
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}
}
