/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-app/src/java/org/sakaiproject/tool/melete/ListModulesPage.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html 
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/

package org.sakaiproject.tool.melete;
import org.sakaiproject.api.app.melete.*;

import java.util.*;
import javax.faces.component.*;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.io.Serializable;

import javax.faces.context.FacesContext;
import javax.faces.el.PropertyNotFoundException;
import javax.faces.el.ValueBinding;
import javax.faces.application.FacesMessage;

//import com.sun.faces.util.Util;
import java.sql.Timestamp;
import java.io.File;
import org.w3c.dom.Document;
import org.w3c.dom.*;


import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.sakaiproject.service.framework.log.Logger;
import org.sakaiproject.api.app.melete.ModuleService;
import org.sakaiproject.component.app.melete.*;
//import org.sakaiproject.jsf.ToolBean;

/**
 * @author Faculty
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
/*
 * 3/21/05 - Mallika - added code to handle linked and uploaded sections
 * 3/30/05 - Mallika - added resetvalues method and null check in constructor
 * Mallika - 4/22/05 - Added the association to display module label
 * Mallika - 5/23/05 - For better performance, changed the getCourseModule code
 * Mallika - 5/24/05 - Added setLicenseCode to viewsections 
 */
public class ListModulesPage implements Serializable/*,ToolBean */{
	/** Dependency:  The logging service. */
	protected Logger logger = null;
	  private List moduleDateBeans = null;
	  private List moduleDatePrivBeans = null;
	  /** identifier field */
      private int showModuleId;

      private String formName;
      private Date currentDate;
      private Timestamp currentTimestamp;
      private boolean instFlag;
      private boolean studFlag;
      private String role;
      private String typeEditor;
      private String typeLink;
      private String typeUpload;
      private boolean nomodsFlag;
      private ModuleStudentPrivsService  nullMsp = null;
      private ModuleService moduleService;
      private CoursePrefsService coursePrefsService;      
      private Section nullSection = null;
      private List nullList = null;
      private String isNull = null;
      private String mval;
      
	  //This needs to be set later using Utils.getBinding
	  String courseId;
	  String userId;

	  public ListModulesPage(){
	  	
	  	instFlag = true;
	  	studFlag = false;
	  	FacesContext context = FacesContext.getCurrentInstance();
	  	Map sessionMap = context.getExternalContext().getSessionMap();
	  	role = (String)sessionMap.get("role");
	  	courseId = (String)sessionMap.get("courseId");
	  	userId = (String)sessionMap.get("userId");
	  	nomodsFlag = false;
	  	setShowModuleId(-1);
	  }

	  public void resetValues()
	  {
	  	instFlag = true;
	  	studFlag = false;
	  	nomodsFlag = false;
	  	setShowModuleId(-1);
	  }


 /**
	   * @return Returns the ModuleService.
	   */
	  public ModuleService getModuleService() {
		return moduleService;
	  }

	 /**
	  * @param moduleService The moduleService to set.
	  */
	  public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	  }
	  /**
		 * @return Returns the CoursePrefsService.
		 */
		public CoursePrefsService getCoursePrefsService() {
			return coursePrefsService;
		}
		/**
		 * @param CoursePrefsService The CoursePrefsService to set.
		 */
		public void setCoursePrefsService(CoursePrefsService coursePrefsService) {
			this.coursePrefsService = coursePrefsService;
		}	  	  
	  /**
		 * @return Returns the logger.
		 */
		public Logger getLogger() {
			return logger;
		}
		/**
		 * @param logger The logger to set.
		 */
		public void setLogger(Logger logger) {
			this.logger = logger;
		}
	  public String getRole() {
	  	return role;
	  }

	  public void setRole(String role) {
	  	this.role = role;
	  }

	  public boolean getInstFlag() {
	  	return instFlag;
	  }

	  public void setInstFlag(boolean instFlag) {
	  	this.instFlag = instFlag;
	  }

	  public boolean getStudFlag() {
	  	return studFlag;
	  }

	  public void setStudFlag(boolean studFlag) {
	  	this.studFlag = studFlag;
	  }
	  public List  getNullList() {
	  	return nullList;
	  }

	  public void setNullList(List nullList) {
	  	this.nullList = nullList;
	  }
	  public boolean getNomodsFlag() {
	  	return nomodsFlag;
	  }

	  public void setNomodsFlag(boolean nomodsFlag) {
	  	this.nomodsFlag = nomodsFlag;
	  }

	  public ModuleStudentPrivsService  getNullMsp() {
	  	return nullMsp;
	  }

	  public void setNullMsp(ModuleStudentPrivsService  nullMsp) {
	  	this.nullMsp = nullMsp;
	  }

	  public Section  getNullSection() {
	  	return nullSection;
	  }

	  public void setNullSection(Section  nullSection) {
	  	this.nullSection = nullSection;
	  }

	  public String getTypeEditor(){
	  	return "typeEditor";
	  }
	  public void setTypeEditor(String typeEditor){
	  	this.typeEditor = typeEditor;
	  }

	  public String getTypeLink(){
	  	return "typeLink";
	  }
	  public void setTypeLink(String typeLink){
	  	this.typeLink = typeLink;
	  }

	  public String getTypeUpload(){
	  	return "typeUpload";
	  }
	  public void setTypeUpload(String typeUpload){
	  	this.typeUpload = typeUpload;
	  }
	  public String getIsNull()
	  {
	  	return isNull;
	  }
	  public void setMval(String mval)
	  {
			this.mval = mval;
	  }
		
	  public String getMval()
	  {
		  logger.info("coming to getmval");
		  return mval;
	   }	  
	  
	  public List getModuleDateBeans() {
	  	int hideFlagSize = 0;
	  	logger.info("Coming to getModuleDateBeans");
	  	setCurrentDate(Calendar.getInstance().getTime());
	  	setCurrentTimestamp(new java.sql.Timestamp(Calendar.getInstance().getTimeInMillis()));
	  	try {
	  		moduleDateBeans = getModuleService().getModuleDateBeans(courseId);
	  		for (ListIterator i = moduleDateBeans.listIterator(); i.hasNext(); ) {
		        ModuleDateBean mdbean = (ModuleDateBean) i.next();
		        if (mdbean.getModuleShdate().isHideFlag() == true)
		        {
		        	hideFlagSize = hideFlagSize + 1;
		        }
		        //logger.info("secs is "+mdbean.getModule().getSections());
	  		}
	  	}catch (Exception e)
		{
	  		//e.printStackTrace();
	  		logger.error(e.toString());
		}
	  	logger.info("Size is "+moduleDateBeans.size());
	  	//If list of modules returned is zero or if all of them are hidden
	  	if ((moduleDateBeans.size() == 0)||(moduleDateBeans.size() == hideFlagSize))
	  	{
	  	  nomodsFlag = true;
	  	  FacesContext ctx = FacesContext.getCurrentInstance();
  		  addNoModulesMessage(ctx);
	  	}
		mval = getCoursePrefsService().getModuleLabel(courseId);
		if (mval == null)
		{
			mval = "Module ";
		}
		setMval(mval);	  	
	  	return moduleDateBeans;
	  }

	  public void setModuleDateBeans(List moduleDateBeansList) {
	    moduleDateBeans = moduleDateBeansList;
	  }

	  public List getModuleDatePrivBeans() {
		int hideFlagSize = 0;
	  	logger.info("Coming to getModuleDatePrivBeans");
	  	setCurrentDate(Calendar.getInstance().getTime());
	  	setCurrentTimestamp(new java.sql.Timestamp(Calendar.getInstance().getTimeInMillis()));
	  	try {
	  		moduleDatePrivBeans = getModuleService().getModuleDatePrivBeans(userId, courseId);

	  	}catch (Exception e)
		{
	  		//e.printStackTrace();
	  		logger.error(e.toString());
		}
	  	if (moduleDatePrivBeans.size() == 0)
	  	{
	  	  nomodsFlag = true;
	  	  FacesContext ctx = FacesContext.getCurrentInstance();
  		  addNoModulesMessage(ctx);
	  	}
		mval = getCoursePrefsService().getModuleLabel(courseId);
		if (mval == null)
		{
			mval = "Module ";
		}
		setMval(mval);	  		  	
	  	return moduleDatePrivBeans;
	  }

	  public void setModuleDatePrivBeans(List moduleDatePrivBeansList) {
	    moduleDatePrivBeans = moduleDatePrivBeansList;
	  }
	  public Date getCurrentDate() {
	  	return currentDate;
	  }

	  public void setCurrentDate(Date currentDate) {
	  	this.currentDate = currentDate;
	  }

	  public Date getCurrentTimestamp() {
	  	return currentTimestamp;
	  }

	  public void setCurrentTimestamp(java.sql.Timestamp currentTimestamp) {
	  	this.currentTimestamp = currentTimestamp;
	  }

	  public int getShowModuleId() {
	        return this.showModuleId;
	  }

	  public void setShowModuleId(int moduleId) {
	        this.showModuleId = moduleId;
	  }




	  public String showSections() {
	  	ModuleDatePrivBean mdpbean = null;
	  	ModuleDateBean mdbean = null;
	  	logger.info("SHOW SECTIONS BEING INVOKED : LISTMODULESPAGE");
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	 UIViewRoot root = ctx.getViewRoot();
	        UIData table = (UIData)
	            root.findComponent("listmodulesform").findComponent("table");
	        ValueBinding binding =
	            Util.getBinding("#{listModulesPage}");
	        ListModulesPage lmPage = (ListModulesPage)
	            binding.getValue(ctx);
	        if (getRole().equals("INSTRUCTOR")) {
	        	mdbean = (ModuleDateBean) table.getRowData();
	        	lmPage.setShowModuleId(mdbean.getModuleId());
	        }
	        if (getRole().equals("STUDENT")) {
	        	mdpbean = (ModuleDatePrivBean) table.getRowData();
	        	lmPage.setShowModuleId(mdpbean.getModuleId());
	        }

	    String retVal = "list_modules_student";
	    if (getRole().equals("INSTRUCTOR"))
	    {
	    	retVal = "list_modules_inst";
	    }
	    if (getRole().equals("STUDENT"))
	    {
	    	retVal = "list_modules_student";
	    }
	  	return retVal;
	  }
	  public String hideSections() {
	  	setShowModuleId(-1);
	  	String retVal = "list_modules_student";
	    if (getRole().equals("INSTRUCTOR"))
	    {
	    	retVal = "list_modules_inst";
	    }
	    if (getRole().equals("STUDENT"))
	    {
	    	retVal = "list_modules_student";
	    }
	  	return retVal;
	  }

	  public String viewModule() {
	  	ModuleDatePrivBean mdpbean = null;
	  	ModuleDateBean mdbean = null;
	  	logger.info("VIEW MODULE BEING INVOKED");
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	 UIViewRoot root = ctx.getViewRoot();
	        UIData table = (UIData)
	            root.findComponent("listmodulesform").findComponent("table");
	    ValueBinding binding =
	            Util.getBinding("#{viewModulesPage}");
	    ViewModulesPage vmPage = (ViewModulesPage)
	            binding.getValue(ctx);
	    binding =
            Util.getBinding("#{modBcPage}");
        ModBcPage mbcPage = (ModBcPage)
            binding.getValue(ctx);
	        if (getRole().equals("INSTRUCTOR")) {
	        	mdbean = (ModuleDateBean) table.getRowData();
	        	vmPage.setModuleId(mdbean.getModuleId());
	        	vmPage.setModule(null);
	        	//vmPage.setShowModuleId(mdbean.getModuleId());
	        	mbcPage.setShowModuleId(mdbean.getModuleId());
	        	//Additional line of code
	        	logger.info("Size of moddatebeans is "+moduleDateBeans.size());
	        	mbcPage.setModuleDateBeans(moduleDateBeans);
	        	//Change without having to iterate through cmods
	        	CourseModuleService cmod = (CourseModuleService) mdbean.getCmod();
	        	logger.info("Seq no is "+cmod.getSeqNo());
	        	vmPage.setModuleSeqNo(cmod.getSeqNo());


	        }
	        if (getRole().equals("STUDENT")) {
	        	mdpbean = (ModuleDatePrivBean) table.getRowData();
	        	vmPage.setModuleId(mdpbean.getModuleId());
	        	vmPage.setModule(null);
	        	mbcPage.setShowModuleId(mdpbean.getModuleId());
	        	mbcPage.setModuleDatePrivBeans(moduleDatePrivBeans);
	        	//vmPage.setShowModuleId(mdpbean.getModuleId());
	        
//	        	//Change without having to iterate through cmods
	        	CourseModuleService cmod = (CourseModuleService) mdpbean.getCmod();
	        	logger.info("Seq no is "+cmod.getSeqNo());
	        	vmPage.setModuleSeqNo(cmod.getSeqNo());
	        }
	    String retVal = "view_module_student";
	    if (getRole().equals("INSTRUCTOR"))
	    {
	    	retVal = "view_module";
	    }
	    if (getRole().equals("STUDENT"))
	    {
	    	retVal = "view_module_student";
	    }
	  	return retVal;
	  }

	  public String viewSection() {
	  	logger.info("VIEW SECTION BEING INVOKED");
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	 UIViewRoot root = ctx.getViewRoot();
	        UIData table = (UIData)
	            root.findComponent("listmodulesform").findComponent("table").findComponent("tablesec");

	    ValueBinding binding =
	            Util.getBinding("#{viewSectionsPage}");
	    ViewSectionsPage vsPage = (ViewSectionsPage)
	            binding.getValue(ctx);
	            SectionBean secBean = (SectionBean) table.getRowData();
	            Section sec = secBean.getSection();
	            vsPage.setModuleId(sec.getModuleId());
	            vsPage.setSeqNo(sec.getSeqNo());
	            vsPage.setSection(null);
	            //vsPage.setSecOffset(0);
	            ModuleObjService mod = (ModuleObjService)getModuleService().getModule(sec.getModuleId());
	            logger.info("Module title is "+mod.getTitle());
	            vsPage.setModuleTitle(mod.getTitle());
	            vsPage.setLicenseCode(mod.getLicenseCode());
	            List sections = mod.getSections();
	            try {
	    	  		ModuleService modServ = getModuleService();
	    	  		CourseModule cMod = (CourseModule)modServ.getCourseModule(mod.getModuleId().intValue(),courseId);
	    	  		vsPage.setModuleSeqNo(cMod.getSeqNo());
	    		}
	    		catch (Exception e)
	    		{
	    	  		//e.printStackTrace();
	    	  		logger.error(e.toString());
	    		}	            
	       
	            binding =
	                Util.getBinding("#{modBcPage}");
	             ModBcPage mbcPage = (ModBcPage) binding.getValue(ctx);
	             mbcPage.setShowModuleId(sec.getModuleId());
	             if (getRole().equals("INSTRUCTOR")) {
	             	mbcPage.setModuleDateBeans(moduleDateBeans);
	             }
	             if (getRole().equals("STUDENT")) {
	             	mbcPage.setModuleDatePrivBeans(moduleDatePrivBeans);
	             }
                 binding =
		            Util.getBinding("#{secBcPage}");
		    SecBcPage sbcPage = (SecBcPage)binding.getValue(ctx);
		            sbcPage.setModuleId(sec.getModuleId());
		            //sbcPage.setSections(sections);
		            sbcPage.setShowModuleId(sec.getModuleId());
		            sbcPage.setShowSeqNo(sec.getSeqNo());
		            sbcPage.setEditMode(false);
		            sbcPage.setShowTextOnly(false);

	    String retVal = "view_section_student";
	    //3/21/05 - Mallika - added this code in to handle linked and uploaded sections
	    if (getRole().equals("INSTRUCTOR"))
	    {
	    	if(sec.getContentType().equals("typeEditor"))
	    	{
	    	logger.info("RASHMI instructor returning editor page");
	       	retVal = "view_section";
	    	}
	    	else
	    	{
	    		retVal = "view_section_link";
	    	}
	    }
	    if (getRole().equals("STUDENT"))
	    {
	    	 if (sec.getContentType().equals("typeEditor"))
		      {
		    	logger.info("RASHMI returning student page");
		    	retVal = "view_section_student";
		      }
		      else
		      {
		      	retVal = "view_section_student_link";
		      }
	    }
	  	return retVal;
	  }

	  private void addNoModulesMessage(FacesContext ctx){
	  	FacesMessage msg =
	  		new FacesMessage("No modules", "No modules are available for the course at this time.");
	  	ctx.addMessage(null,msg);
	  }

}
