/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-app/src/java/org/sakaiproject/tool/melete/ViewModulesPage.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html 
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/

package org.sakaiproject.tool.melete;
import org.sakaiproject.api.app.melete.*;

import javax.faces.application.*;
import java.util.*;
import javax.faces.component.*;
import javax.faces.component.html.*;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.io.Serializable;
import javax.faces.event.ActionEvent;

import javax.faces.context.FacesContext;
import javax.faces.el.PropertyNotFoundException;
import javax.faces.el.ValueBinding;
import javax.faces.el.MethodBinding;
import javax.faces.application.FacesMessage;

//import com.sun.faces.util.Util;
import java.sql.Timestamp;

import org.sakaiproject.component.app.melete.*;
import org.sakaiproject.api.app.melete.ModuleService;
//import org.sakaiproject.jsf.ToolBean;
import org.sakaiproject.service.framework.log.Logger;

/**
 * @author Faculty
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
/*
 * 
 * modified by rashmi - 03/10/05 bug#282- added seperate page for links and upload to show them in frame
 * mallika - 3/21/05 - if condition in view section method change
 * mallika - 3/30/05 - added null check in constructor
 * Mallika - 4/22/05 - Added the association to display module label
 * Mallika - 5/23/05 - For better performance, changed the getCourseModule code
 * Mallika - 5/24/05 - Added setLicenseCode to viewsections
 * Rashmi - 6/14/05 - Added setModule to null for FairUse license bug.   
 */


public class ViewModulesPage implements Serializable/*,ToolBean*/ {


	  /** identifier field */
      private int moduleId;
      private int moduleSeqNo;
      public ModuleObjService module;
      private List moduleDateBeans = null;

      private boolean instRole;
      private int sectionSize;
      private String role;
      private String nullString = null;

//    This needs to be set later using Utils.getBinding
	  String courseId;
	  

	  private ModuleService moduleService;
	  private CoursePrefsService coursePrefsService;	  
	  /** Dependency:  The logging service. */
  	  protected Logger logger = null;
  	  private String mval;
  	  
	  public ViewModulesPage(){
	  	
	  	FacesContext context = FacesContext.getCurrentInstance();
	  	Map sessionMap = context.getExternalContext().getSessionMap();
	  	courseId = (String)sessionMap.get("courseId");
	  	
		role = (String)sessionMap.get("role");
		if (role.equals("INSTRUCTOR"))
		{
			setInstRole(true);
		}
		else
		{
			setInstRole(false);
		}
	  }

     /**
	   * @return Returns the ModuleService.
	   */
	  public ModuleService getModuleService() {
		return moduleService;
	  }

	 /**
	  * @param moduleService The moduleService to set.
	  */
	  public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	  }
	  /**
		 * @return Returns the CoursePrefsService.
		 */
		public CoursePrefsService getCoursePrefsService() {
			return coursePrefsService;
		}
		/**
		 * @param CoursePrefsService The CoursePrefsService to set.
		 */
		public void setCoursePrefsService(CoursePrefsService coursePrefsService) {
			this.coursePrefsService = coursePrefsService;
		}	  	  
	  /**
		 * @param logger The logger to set.
	  */
	  public void setLogger(Logger logger) {
			this.logger = logger;
	  }
	  public String getNullString() {
	  	return nullString;
	  }

	  public void setNullString(String nullString) {
	  	this.nullString = nullString;
	  }


	  public int getModuleId() {
        return this.moduleId;
    }

    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }
    public int getModuleSeqNo() {
        return this.moduleSeqNo;
    }

    public void setModuleSeqNo(int moduleSeqNo) {
        this.moduleSeqNo = moduleSeqNo;
    }
    public ModuleObjService getModule()
    {
      if (this.module == null)
 	  {
    	try {

  	  	  this.module = (ModuleObjService) getModuleService().getModule(this.moduleId);
  	  	}
  	  	catch (Exception e)
          {
  		  //e.printStackTrace();
  	  		logger.error(e.toString());
          }
 	  }
  	  	return this.module;
    }

    public void setModule(ModuleObjService module){
      this.module = module;
    }
    public int getSectionSize() {
    	if (getModule().getSections() != null)
    	{	
    	  this.sectionSize = getModule().getSections().size();
    	}
    	else
    	{
    		this.sectionSize = 0;
    	}
        return this.sectionSize;
    }

    public void setSectionSize(int sectionSize) {
        this.sectionSize = sectionSize;
    }

    public List getModuleDateBeans() {
    	logger.info("getModuleDateBeans being invoked in viewmodulespage");
    	
    	try {
	  		moduleDateBeans = getModuleService().getModuleDateBeans(courseId);
	  	}catch (Exception e)
		{
	  		//e.printStackTrace();
	  		logger.error(e.toString());
		}

	  	return moduleDateBeans;
    }
    public void setModuleDateBeans(List moduleDateBeans) {
    	this.moduleDateBeans = moduleDateBeans;
    }

    public boolean getInstRole()
    {
    	FacesContext context = FacesContext.getCurrentInstance();
	  	Map sessionMap = context.getExternalContext().getSessionMap();
		this.instRole = ((String)sessionMap.get("role")).equals("INSTRUCTOR");
    	return instRole;
    }

    public void setInstRole(boolean instRole)
    {
    	this.instRole = instRole;
    }
    public void setMval(String mval)
	  {
			this.mval = mval;
	  }
		
	  public String getMval()
	  {
		  logger.info("coming to getmval");
		  mval = getCoursePrefsService().getModuleLabel(courseId);
			if (mval == null)
			{
				mval = "Module ";
			}
			setMval(mval);		  
		  return mval;
	   }	  
    /*
     * 
     * modified by rashmi - 03/10/05
     *  added seperate page for links and upload to show them in frame
     */
	
    public String viewSection() {

	  	logger.info("VIEW SECTION BEING INVOKED  in viewmodulespage");
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	 UIViewRoot root = ctx.getViewRoot();
	  	
	        UIData table = (UIData)
	            root.findComponent("viewmoduleform").findComponent("tablesec");
	       
	    ValueBinding binding =
	            Util.getBinding("#{viewSectionsPage}");
	    
	    ViewSectionsPage vsPage = (ViewSectionsPage)
	            binding.getValue(ctx);
	         
	            SectionObjService sec = (SectionObjService) table.getRowData();
	            vsPage.setModuleId(sec.getModuleId());
	            vsPage.setSeqNo(sec.getSeqNo());
	            vsPage.setSection(null);
	            //added by rashmi on 6/14/05
	            vsPage.setModule(null);
	            //vsPage.setSecOffset(0);
	            ModuleObjService mod = (ModuleObjService) getModuleService().getModule(sec.getModuleId());
	            vsPage.setModuleTitle(mod.getTitle());
	            vsPage.setLicenseCode(mod.getLicenseCode());
	            try {
	    	  		ModuleService modServ = getModuleService();
	    	  		CourseModule cMod = (CourseModule)modServ.getCourseModule(sec.getModuleId(),courseId);
	    	  		vsPage.setModuleSeqNo(cMod.getSeqNo());
	    		}
	    		catch (Exception e)
	    		{
	    	  		//e.printStackTrace();
	    	  		logger.error(e.toString());
	    		}	            
	          
	            binding =
	                Util.getBinding("#{modBcPage}");
	             ModBcPage mbcPage = (ModBcPage) binding.getValue(ctx);
	             mbcPage.setShowModuleId(sec.getModuleId());
                 binding = Util.getBinding("#{secBcPage}");
		         SecBcPage sbcPage = (SecBcPage) binding.getValue(ctx);
		            sbcPage.setModuleId(sec.getModuleId());
		            sbcPage.setShowModuleId(sec.getModuleId());
		            sbcPage.setShowSeqNo(sec.getSeqNo());
		            sbcPage.setEditMode(false);
		            sbcPage.setShowTextOnly(false);
	    
	    String retVal = "view_section_student";
	    
	    //03/10/05  rashmi - added seperate page for links and upload to show them in frame
	    //3/21/05 - mallika - the if condition was slightly ambiguous, so needed to change that
		logger.info("RASHMI - get Role in viewModules is called and contentt type"+ getInstRole()+  sec.getContentType().equals("typeEditor"));
		
	    if (getInstRole() == true)
	    {
	    	if(sec.getContentType().equals("typeEditor"))
	    	{
	    	logger.info("RASHMI instructor returning editor page");
	       	retVal = "view_section";
	    	}   
	    	else 
	    	{
	    		retVal = "view_section_link";
	    	}
	    }
	    else  
	    {
	      if (sec.getContentType().equals("typeEditor"))
	      {
	    	logger.info("RASHMI returning student page");
	    	retVal = "view_section_student";
	      } 
	      else 
	      {
	      	retVal = "view_section_student_link";
	      }
	    }
	  	return retVal;
	  }

    public void viewModule(ActionEvent evt) {
    	FacesContext ctx = FacesContext.getCurrentInstance();
    	logger.info("ViewModulesPage viewModule being invoked "+((UICommand)evt.getComponent()).getId());
    	UICommand cmdLink = (UICommand)evt.getComponent();
    	List cList = cmdLink.getChildren();
    	UIParameter param = new UIParameter();
    	for (int i=0; i< cList.size(); i++)
    	{
    		Object obj = cList.get(i);
    		if (obj instanceof UIParameter)
    		{
    		  param = (UIParameter) cList.get(i);
    		}
    	}
    	ValueBinding binding =
            Util.getBinding("#{viewModulesPage}");
         ViewModulesPage vmPage = (ViewModulesPage) binding.getValue(ctx);
         vmPage.setModuleId(((Integer)param.getValue()).intValue());
         vmPage.setModule(null);
         try {
	  		ModuleService modServ = getModuleService();
	  		CourseModule cMod = (CourseModule)modServ.getCourseModule(((Integer)param.getValue()).intValue(),courseId);
	  		vmPage.setModuleSeqNo(cMod.getSeqNo());
		}
		catch (Exception e)
		{
	  		//e.printStackTrace();
	  		logger.error(e.toString());
		}	                     
    
         binding =
            Util.getBinding("#{modBcPage}");
         ModBcPage mbcPage = (ModBcPage) binding.getValue(ctx);
         mbcPage.setShowModuleId(((Integer)param.getValue()).intValue());
    }

    public String redirectToViewModule(){
    	String retVal = "view_module_student";
	    if (getInstRole() == true)
	    {
	    	retVal = "view_module";
	    }
	    if (getInstRole() == false)
	    {
	    	retVal = "view_module_student";
	    }
	  	return retVal;

    }
}
