/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-app/src/java/org/sakaiproject/tool/melete/SectionPage.java,v 1.5 2006/03/09 19:43:10 mallikat Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/
package org.sakaiproject.tool.melete;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIColumn;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.component.html.HtmlSelectBooleanCheckbox;
import javax.faces.component.html.HtmlSelectOneMenu;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.validator.ValidatorException;

import org.sakaiproject.api.app.melete.CoursePrefsService;
import org.sakaiproject.api.app.melete.ModuleObjService;
import org.sakaiproject.api.app.melete.ModuleService;
import org.sakaiproject.api.app.melete.SectionObjService;
import org.sakaiproject.api.app.melete.SectionService;
import org.sakaiproject.component.app.melete.CourseModule;
import org.sakaiproject.component.app.melete.MeleteException;
import org.sakaiproject.component.app.melete.Module;
import org.sakaiproject.component.app.melete.ModuleDateBean;
import org.sakaiproject.component.app.melete.ModuleShdates;
import org.sakaiproject.component.app.melete.Section;
import org.sakaiproject.service.framework.config.ServerConfigurationService;
import org.sakaiproject.service.framework.log.Logger;

/**
 * @author Rashmi
 *
 * This class is the backing bean for AddModuleSections.jsp and addModuleFinish page.
 *
 *  revised by rashmi 03/15/05 -- to make FS compatabile for linux and windows
 *  Rashmi - 3/8/05 bug #285 required error message for content type
 * method validateModalityInfo and validateContents and validateEditorContents
 * rashmi - 03/23 set form name and changed methods to get component based on formName
 * rashmi - 03/23 seggregated setmodule null part from setsection function
 * rashmi - 3/23 -- ids to modality check boxes
 * rashmi - 3/25  revised check of upload file name condition
 * added by rashmi 04/01/05 to create uploads directory if not present
 * revised by rashmi 04/07/05 contentEditor as protected attrib, module null check in
 * createDatapath() and removed sytem.out stmt from getContentEditor()
 * mallika - 5/10 - changed reference for upload size from courseprefs to sessionmap
 * Mallika - 5/23/05 - For better performance, changed the getCourseModule code to previewModule
 * Rashmi - 5/25/05 - finish pages has one dynamic table containg all info
 * Rashmi - 5/25/05 - Bad url format error is introduced.
 * Rashmi - 6/01/05 - preview of new uploaded file in edit section
 * Mallika - 6/6/05 - setting default content type to notype
 * Rashmi - 6/20/05 - setting default back to editor
 * Rashmi - 6/27/05 -- revising getModule() to get the right value
 * Rashmi - 6/29/05 -- validate modality code is also moved in validatecontents as the validator clause is removed from checkbox
 * Murthy - 01/08/06 -- updated getUploadFile() to fix path problem in preview
 * David Roldan y Diego del Blanco (tanto monta monta tanto) - 2/14/06 -- Allowing paste images from Microsoft Word.
 * Mallika - 3/7/06 - Removing instr_id from path
 */

public abstract class SectionPage implements Serializable{
	protected ModuleObjService module;
	protected SectionObjService section;
	private StringBuffer author;
	protected String contentEditor;
	protected String hiddenUpload;
	protected String checkUploadChange;
	private String uploadFile;
	private boolean shouldRenderuploadFileName=false;
	private String uploadFileName;
	private int moduleNumber;

	// rendering flags
	private boolean shouldRenderEditor=false;
    private boolean shouldRenderLink=false;
    private boolean shouldRenderUpload=false;
    private boolean success = false;
    private boolean renderInstr=false;
    private HtmlPanelGrid finishTable;

    protected String homeDir;

	protected String previewTempUpload;

	/** Dependency:  The logging service. */
	protected Logger logger = null;
	protected SectionService sectionService;
	protected CoursePrefsService coursePrefsService;
	protected ModuleService moduleService;

	  protected ServerConfigurationService serverConfigurationService;
	  public String serverLocation;
	  public String formName;

    /*
     * Revision -- 12/20
     */
	public SectionPage()
		{
		System.out.println("Section page constructor executes");
		module=null;
		section=null;
		contentEditor=null;
		uploadFileName=null;
		hiddenUpload=null;
		checkUploadChange=null;
		uploadFile=null;
		finishTable = new HtmlPanelGrid();
		serverLocation = "http://localhost:8080";
		homeDir="";
		moduleNumber=0;
		previewTempUpload = null;
		}
	/**
	   * @return Returns the ModuleService.
	   */
	  public ModuleService getModuleService() {
		return moduleService;
	  }

	 /**
	  * @param moduleService The moduleService to set.
	  */
	  public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	  }


	/**
	 * @param event
	 * @throws AbortProcessingException
	 * show hides the input boxes to specify the uploaded file name,
	 * link or writing new content. based on the user radio button selection.
	 */
	public void showHideContent(ValueChangeEvent event)throws AbortProcessingException
	{
		//System.out.println("@@@@@@@@@RASHMI SectionPage:showHideContent called");
		UIInput contentTypeRadio = (UIInput)event.getComponent();

		shouldRenderEditor = contentTypeRadio.getValue().equals("typeEditor");
		shouldRenderLink = contentTypeRadio.getValue().equals("typeLink");
		shouldRenderUpload = contentTypeRadio.getValue().equals("typeUpload");
//		System.out.println("Form name in section page is "+getFormName());
//		System.out.println("render value editor" + shouldRenderEditor + "link " + shouldRenderLink + "upload " + shouldRenderUpload);

		if(contentTypeRadio.findComponent(getFormName()).findComponent("uploadPath") != null)
			{
			contentTypeRadio.findComponent(getFormName()).findComponent("uploadPath").setRendered(shouldRenderUpload);
			contentTypeRadio.findComponent(getFormName()).findComponent("BrowsePath").setRendered(shouldRenderUpload);
			}

		if(contentTypeRadio.findComponent(getFormName()).findComponent("link") != null)
		{
//			System.out.println("find component: setting link rendering for link");
			contentTypeRadio.findComponent(getFormName()).findComponent("link").setRendered(shouldRenderLink);
		}

		if(contentTypeRadio.findComponent(getFormName()).findComponent("contentEditor") != null)
			{
			contentTypeRadio.findComponent(getFormName()).findComponent("contentEditorView").setRendered(shouldRenderEditor);
			}

	}

	// get rendering flags

	public boolean getShouldRenderEditor()
	{
		if(this.section != null && this.section.getContentType() != null)
		{
		shouldRenderEditor = this.section.getContentType().equals("typeEditor");
		}
		return shouldRenderEditor;
	}

	public boolean getShouldRenderLink()
	{
		shouldRenderLink = false;
		if(this.section != null && this.section.getContentType() != null)
		{
			shouldRenderLink = this.section.getContentType().equals("typeLink");
		}
		return shouldRenderLink;
	}

	public boolean getShouldRenderUpload()
	{
		if(this.section != null && this.section.getContentType() != null)
		{
		shouldRenderUpload = this.section.getContentType().equals("typeUpload");
		}
		return shouldRenderUpload;
	}

	/**
	 * @return success
	 * render sucess message if this flag is true
	 */
	public boolean getSuccess()
	{
		return this.success;
	}

	/**
	 * @param success
	 * to set sucess to true if section save is successful.
	 */
	public void setSuccess(boolean success)
	{
		this.success = success;
	}

	/**
	 * @return uploadfile name
	 *  stripping off the path where its stored
	 */
	public String getUploadFileName()
	{
		if(section!=null && section.getUploadPath()!=null)
		{
			String str=section.getUploadPath();
		//	System.out.println("in edit section getupload file name" + str);
			uploadFileName = str.substring(str.lastIndexOf(File.separator)+1);
			uploadFileName = uploadFileName.trim();
			shouldRenderuploadFileName = true;
		}
		return this.uploadFileName;
	}

	/*
	 * Revised -- Rashmi 11/18
	 * to show the message
	 */
	public boolean getShouldRenderuploadFileName()
	{
		if(section!=null && section.getUploadPath()!=null)
		{
			shouldRenderuploadFileName = true;
		}
		return this.shouldRenderuploadFileName;
	}

	/**
	 * @return module
	 * if module is not set, get the module from session.
	 * revision -- 12/20 Rashmi -- to refresh module to currModule
	 */
	public ModuleObjService getModule()
	{
		logger.info("get module of section page called");
		FacesContext context = FacesContext.getCurrentInstance();
		Map sessionMap = context.getExternalContext().getSessionMap();
		ModuleObjService nextModule =null;
		if(section.getModule()!= null )
		{
			module=(Module)section.getModule();
		//	System.out.println("setting module from section in getModule()" + module.getTitle());
			return module;
		}
		if(sessionMap.containsKey("currModule"))
		{
			nextModule= (ModuleObjService)sessionMap.get("currModule");
		//	System.out.println("contains currModule in sessionMap and next curr module and module" + nextModule + module);
		}
		if(module == null || (nextModule!=null && nextModule.getModuleId() != module.getModuleId()))
		{
	//	System.out.println("get module of add section page called and module is null");
		module = (ModuleObjService)sessionMap.get("currModule");
		}
		logger.info("setting module of section page as " + module.getTitle());
		return module;
	}

	/**
	 * @return section.
	 * create a new instance of section and assign default values.
	 * set name from user
	 *
	 * Revision -- 11/22 user info from session
	 */
	public SectionObjService getSection()
	{
		FacesContext context = FacesContext.getCurrentInstance();
	    Map sessionMap = context.getExternalContext().getSessionMap();
		  if (null == this.section) {
		  		logger.info("get section is null so creating one");
		      this.section = new Section();
		      this.section.setLink("http://");
		      this.section.setContentType("typeEditor");

		      // user info from session
		      this.section.setCreatedByFname((String)sessionMap.get("firstName"));
		      this.section.setCreatedByLname((String)sessionMap.get("lastName"));
		      this.section.setTextualContent(true);
		    }

		return this.section;
	}

	/*
	 * set section. This method is called to set section for edit
	 * by breadcrumps hyperlinks in editmodulesections.jsp page and
	 * also by editmodule.jsp and list_modules_auth.jsp
	 *
	 * Revision -- Rashmi 12/20 to set section as null
	 */
	public void setSection(SectionObjService sec)
	{

		try{
			this.section = null;

			if(sec !=null)
			{
				logger.info("setSection called and section is not null");
				this.module = (Module)sec.getModule();
	//			System.out.println("set section sets module as"+ this.module.getTitle());
				this.section = sec;
			//	System.out.println("set success of section  "+ this.section.getTitle());
			} /*else System.out.println("setSection called to set it to null");*/

		}catch(Exception ex){logger.error(ex.toString());}
	}
/*
 *  added to set module null. seggregated from the setSection method
 */
	public void setModuleNull()
	{
		this.module = null;
	}
	/*
	 * get the max uploads size allowed for the course.
	 * revision - get course from session 11/22 Rashmi
	 *
	 * revision -- Rashmi 2/1/05 in accordance to service etc
	 *
	 */
	public int getMaxUploadSize()
	{
	//	logger.info("get course of add section page called and course is null");
		/*
		 * get from session
		 */
		  FacesContext context = FacesContext.getCurrentInstance();
		  Map sessionMap = context.getExternalContext().getSessionMap();

		  //int sz = getCoursePrefsService().getUploadSize((String)sessionMap.get("courseId"));
		  int sz = Integer.parseInt((String)sessionMap.get("maxSize"));
		  logger.info("Size is "+sz);

		return sz;
	}


	/**
	 * concatenates first name and last name of the creator of this section.
	 * @return author name
	 */
	public String getAuthor()
	  {
		if(author == null)
		{
			author = new StringBuffer();
			author.append(this.section.getCreatedByFname() + " ");
			author.append(this.section.getCreatedByLname());
		}
		return author.toString();
	  }
	  /**
	   * not required as the fields are disabled.
	   */
	  public void setAuthor(String author){ }

	  /**
	   * read back content from section content file
	  */
	  private void readfromFile(String contentpath)
	  {
		StringBuffer lines= new StringBuffer();
	//	logger.info("reading content file and populating content editor");
	  	try{
	   	BufferedReader br
		   = new BufferedReader(new FileReader(contentpath));
	   	String line;

		while ( (line= br.readLine()) != null)
		{
			lines.append(line);
		}
		br.close();
	  	}catch(Exception ex){
	  		logger.error(ex.toString());
	  	}
		this.contentEditor = lines.toString();
	  }

	  /**
	   * return content editor
	  */
	  public String getContentEditor()
	  {
	//  	logger.info("get content editor called");
	  	if(this.contentEditor == null || this.contentEditor.length()== 0)
	  	{
		  	this.contentEditor = new String("");
		  	if(this.section!=null && this.section.getContentPath()!=null)
		  		{
		  		readfromFile(this.section.getContentPath());
		  		}
	  	}
	   	return this.contentEditor;
	  }

	  /**
	 * @param contentEditor
	 *
	 */
	public void setContentEditor(String contentEditor){
		logger.info("###############setting content editor :"+contentEditor);
	  	  	this.contentEditor = contentEditor;
	  	}

	/**
	 * @return
	 */
	public String getHiddenUpload()
	{
		if(section!=null && section.getUploadPath()!=null)
		{
			String str=section.getUploadPath();
			hiddenUpload = str.substring(str.lastIndexOf(File.separator)+1);
			checkUploadChange = hiddenUpload;
		}
		else if(hiddenUpload !=null)
		{
			hiddenUpload = hiddenUpload.substring(hiddenUpload.lastIndexOf(File.separator)+1);
		}
		return hiddenUpload;
	}

	/**
	 * @param hiddenUpload
	 */
	public void setHiddenUpload(String hiddenUpload)
	{
		this.hiddenUpload = hiddenUpload;
		//System.out.println("in add section setting hidden upload ");
	}

	/**
	 * @return uploadfile name
	 *  get file name in reference to tomcat root
	 *
	 * revised for linux
	 */
	public String getUploadFile()
	{
		String uploadFile1="";
		FacesContext context = FacesContext.getCurrentInstance();
		homeDir = context.getExternalContext().getInitParameter("homeDir");

	/*	if(previewTempUpload != null)*/
		if(previewTempUpload != null && !hiddenUpload.equals(checkUploadChange))
		{
			System.out.println("previewTempUpload in getUploadFile is "+ previewTempUpload);
			uploadFile1 =  previewTempUpload;
		}
		else if(section!=null && section.getUploadPath()!=null)
		{
			String str=section.getUploadPath();

		//	System.out.println("in add section getupload file name" + str + str.indexOf(homeDir));
		// revised by rashmi 03/25-- condition to -1
			/*if(str.indexOf("\\") != -1)
			{
				uploadFile1 = str.substring(str.indexOf("\\"));
			}
			else
			{
				// for linux paths are /var/meleteDocs
				str= str.substring(str.indexOf("/")+1);
				uploadFile1 = str.substring(str.indexOf("/"));
			}
			*/
			//01/08/06 Murthy : updated to fix path problem in preview
			if(str.indexOf("\\") != -1)
            {
                    uploadFile1 = str.substring(str.indexOf("\\"));
                    uploadFile1 = str.substring(str.indexOf("\\meleteDocs"));
            }
            else
            {
                    // for linux paths are /var/meleteDocs
                    str= str.substring(str.indexOf("/")+1);
                    uploadFile1 = str.substring(str.indexOf("/"));
                    uploadFile1 = str.substring(str.indexOf("/meleteDocs"));
            }
		}
		//	System.out.println("in add section upload file name after substring" + uploadFile1);
			 String patternStr = "\\\\";
	         String replacementStr = "/";

		  // Compile regular expression
	            Pattern pattern = Pattern.compile(patternStr);

	            // Replace all occurrences of pattern in input
	            Matcher matcher = pattern.matcher(uploadFile1);
	            System.out.println("uploadFile 1 value before replaceAll :" + uploadFile1);
	            this.uploadFile = matcher.replaceAll(replacementStr);

	        //    logger.info("in add section final upload file name" + uploadFile);

		return this.uploadFile;
	}

	/**
	 * @return datapath for storing uploaded file or new content file
	 * Directory structure is
	 * Instructor
	 * 	|_ Course
	 * 		|_Images
	 * 			|_Module
	 * 				|_Section_seq.html
	 *
	 * revised -- 1/6 to get ids from session Rashmi
	 * revised -- 3/14-15 to make path linux/windows compatible
	 */
	protected String createDataPath()
	{
	     StringBuffer dataPath=new StringBuffer();
	     	     	// get instructor_id    	// get course_id
	     FacesContext context = FacesContext.getCurrentInstance();
		 Map sessionMap = context.getExternalContext().getSessionMap();
	     String instr_id=(String)sessionMap.get("userId");
	     String courseId=(String)sessionMap.get("courseId");
	     homeDir = context.getExternalContext().getInitParameter("homeDir");
	     //System.out.println("homedirectory in sectionpage found"+homeDir);

	     if(module == null)
			{
		//		System.out.println("module is null in function create dataPath and checking value" +  section.getModule() );
				//getModule();
				this.module=section.getModule();
			}

	     //Mallika - comments beg
	     //dataPath.append(homeDir+File.separator+"meleteDocs"+File.separator+"instr_"+instr_id+File.separator+"course_"+courseId+File.separator);
	     //Mallika - comments end
	     //Mallika - new code beg
	     dataPath.append(homeDir+File.separator+"meleteDocs"+File.separator+"course_"+courseId+File.separator);
	     //Mallika - new code end

	     	 if(this.section.getContentType().equals("typeEditor"))
	     	 	dataPath.append("module_"+this.module.getModuleId()+File.separator);

	    logger.info("DATAPATH :" + dataPath);
	    return dataPath.toString();
	}

	/*
	 * code for uploading content
	 */
	public void uploadContent(String fieldname)
	{
		  // upload code
     try{
     	 FacesContext context = FacesContext.getCurrentInstance();
	     org.apache.commons.fileupload.FileItem fi = (org.apache.commons.fileupload.FileItem) context.getExternalContext().getRequestMap().get(fieldname);
	     homeDir = context.getExternalContext().getInitParameter("homeDir");

	     if(fi !=null)
				{
						// filename on the client
	     		logger.info("Fi in sectionpage: " + fi + "getFieldName(): " + fi.getFieldName() +",getSize(): " +fi.getSize() +", getname():" +fi.getName());
	        	String fileName = fi.getName();

				if(fileName !=null && fileName.length() > 0)
				{
					logger.info("Filename is "+fileName);
					// save filename to database
//					 revised by rashmi 03/25-- condition to -1
					if(fileName.indexOf("\\") != -1)
					{
					fileName=fileName.substring(fileName.lastIndexOf("\\")+1);
				//	System.out.println("new filename inside uploadcontents in windows style" + fileName);
					}
					else
					{
						fileName=fileName.substring(fileName.lastIndexOf("/")+1);
				//		System.out.println("new filename inside uploadcontents in linux style" + fileName);
					}
					File f = new File(homeDir+File.separator+"uploads"+File.separator+fileName);
					logger.info("writing file at " + f.getName() + f.getPath());
	        	// write the file
	    		byte[] data= new byte[(int)fi.getSize()];
				InputStream is = fi.getInputStream();
				 is.read(data);

				 FileOutputStream fos = new FileOutputStream(f) ;
				fos.write(data);
				fos.close();

				logger.info("file upload success");
				}
			}
	     }catch(Exception e)
		 {
	     	logger.error("file upload FAILED" + e.toString());
		 }

	}
	/**
	 *
	 * uploaded or new content written file is temp stored at c:\\uploads.
	 * filename format of temporary file is moduleidSectionTitle.html
	 * later on, when saving module, this file will be stored under right directory
	 * structure under module dir with name as section_"seq".html
	 *
	 * Revision by rashmi on 1/19/05 to save uploaded images from the local machine
	 * as the content of content editor.
	 *
	 * Revision -- rashmi 1/27/04 change url from LOCALHOST to IP address
	 *
	 * IMP NOTE: NEED TO READ IP ADDRESS FROM SESSION OR SOMEWHERE ELSE
	 **/
	protected void createContentTempFile()
	{
//		System.out.println("creating section content temp file in uploads dir again");

//	  	 save uploaded img inside content editor to destination directory

			String checkforimgs = contentEditor;
			  		int imgindex = -1;
					int idx=0;

					String fileName;
					String patternStr;
					String fileNameSave;  // (DDBO,DRM) For naming the file if original name it's the same that another uploaded file.
			  		int secuencia=1;


// Diego del Blanco y David Rold�n - 2/14/06 -- Allowing paste images from Microsoft Word.
// New code... note (see org.sakaiproject.tool.melete.Util.replace)
						while(checkforimgs !=null && (imgindex = checkforimgs.indexOf("file:/")) != -1)
							  	   	{
							 	 		// store at right place
							 	 	checkforimgs = checkforimgs.substring(imgindex);
						  	  		fileName = checkforimgs.substring(0,checkforimgs.indexOf("\""));
						  	  		logger.info("---Filename= " + fileName);


						  	  		patternStr = fileName;
						  	  		patternStr=Util.replace(patternStr,"\\","/");
						  	  		logger.info("---patternStr= " + patternStr);



									logger.info("---content Editor= " + contentEditor);
									contentEditor=Util.replace(contentEditor,fileName,patternStr);
								   	imgindex = -1;
								   	idx=fileName.lastIndexOf("/")+1;
								   	checkforimgs = checkforimgs.substring(idx);

					  	  	}
// End new code






		 checkforimgs = contentEditor;
	  	 imgindex = -1;
	  	 FacesContext context = FacesContext.getCurrentInstance();
	  	 Map sessionMap = context.getExternalContext().getSessionMap();
	  	 homeDir = context.getExternalContext().getInitParameter("homeDir");

	 	 while(checkforimgs !=null && (imgindex = checkforimgs.indexOf("file:/")) != -1)
	  	   	{
	 	 		// store at right place
	 	 	checkforimgs = checkforimgs.substring(imgindex);
  	  		fileName = checkforimgs.substring(0,checkforimgs.indexOf("\""));
  	  		patternStr = fileName;

  	  		idx=fileName.lastIndexOf("/")+1;
  	  		fileName = fileName.substring(idx);

//	  	  	 temprorily upload image first to uploads directory
//	  	  		System.out.println("finding uploaded image file in request " + fileName);
//	  	  		uploadContent(fileName);

	  	  		String instr_id=(String)sessionMap.get("userId");
			    String courseId=(String)sessionMap.get("courseId");

			    //Mallika - comments beg
		  	  	//String storeimgat = homeDir+File.separator+"meleteDocs"+File.separator+"instr_"+instr_id+File.separator+"course_" +courseId+File.separator+"uploads";
		  	  	//Mallika - comments end

		  	  	//Mallika - new code beg
		  	    String storeimgat = homeDir+File.separator+"meleteDocs"+File.separator+"course_" +courseId+File.separator+"uploads";
		  	  	//Mallika - new code end


		  	  	File parent = new File(storeimgat);

		  	  	// added by rashmi 04/01/05 to create uploads directory if not present
		  	  	if(!parent.exists())
		  	  		{
					parent.mkdirs();
		  	  		}


				// (DDBO,DRM) For naming the file if original name it's the same that another uploaded file.
				Date date=new Date();
		  	  	SimpleDateFormat filedate = new SimpleDateFormat("yyMMddHHmmss");
		  	  	fileNameSave=filedate.format(date) + Integer.toString(secuencia) + "_" + fileName;
				// (DDBO,DRM) End naming the file if original name it's the same that another uploaded file.

		  	  	//File f=new File(parent,fileName);
		  	  	File f=new File(parent,fileNameSave); //(DDBO,DRM) For naming the file if original name it's the same that another uploaded file.
		  	  	File re = new File(homeDir+File.separator+"uploads"+File.separator+fileName);
		  	  	if(re.exists())
				{
		  	  		logger.info("uploaded image file found");
					re.renameTo(f);
				}

		  	  	checkforimgs = checkforimgs.substring(idx);

		  	  	// RASHMI __ ADD PORTAL SERVICE HERE
		  	  	//absolute img src change in context to meleteDocs with content

		  	  	//Mallika - comments beg
		  	  	//String replacementStr = serverConfigurationService.getServerUrl() + "/meleteDocs/instr_"+instr_id+"/course_"+courseId+"/uploads/"+fileNameSave; //(DDBO,DRM) For naming the file if original name it's the same that another uploaded file.
		  	  	//Mallika - comments end

		  	  	//Mallika - new code beg
		  	    String replacementStr = serverConfigurationService.getServerUrl() + "/meleteDocs"+"/course_"+courseId+"/uploads/"+fileNameSave; //(DDBO,DRM) For naming the file if original name it's the same that another uploaded file.
		  	    //Mallika - new code end


		  	  	Pattern pattern = Pattern.compile(patternStr);

		  	  	// Replace all occurrences of pattern in input
		        Matcher matcher = pattern.matcher(contentEditor);
		        contentEditor = matcher.replaceAll(replacementStr);
		   	  	imgindex = -1;
		   	  	secuencia++;// (DDBO,DRM) For naming the file if original name it's the same that another uploaded file.

	  	  	}
//	 	 System.out.println("after replacing image location" + contentEditor);

		try{
		String fname = new String(homeDir+File.separator+"uploads"+File.separator+this.module.getModuleId().toString()+this.section.getTitle()+".html");
		PrintWriter out
		   = new PrintWriter(new BufferedWriter(new FileWriter(fname)));
		out.write(contentEditor);
		out.flush();
		out.close();
		}catch(Exception e)
		{
			logger.error("error while creating content file"+ e.toString());

		}
	}

	/*
	 * modality is required. check if one is selected or not
	 */
	protected boolean validateModality()
	{
		if(!(this.section.isAudioContent()|| this.section.isTextualContent()|| this.section.isVideoContent()))
			return false;
		return true;
	}

	/**
	 * @return
	 */
	protected boolean validateContent()
	{
		//System.out.println("validate content --" + this.section.getContentType());
		if(this.section.getContentType().equals("typeUpload"))
		  {
		  	return( hiddenUpload!= null && hiddenUpload.trim().length()!=0);
		   }
		 if(this.section.getContentType().equals("typeEditor"))
		  {
		  	return(contentEditor!= null && contentEditor.trim().length()!= 0);
		  }
		 if(this.section.getContentType().equals("typeLink") )
		  {
		 //		return (this.section.getLink() != null && this.section.getLink().startsWith("http://") && !this.section.getLink().equals("http://"));
		 	return (this.section.getLink() != null && !this.section.getLink().equals("http://"));
		  }

		return true;
	}

	/*
	 *  Validator attached to the select menu tag to report required error message
	 * bug #285
	 */
	public void validateContents(FacesContext context, UIComponent component, Object value)
	throws ValidatorException
	{
		String val_content = (String) value;
		val_content = val_content.trim();

		ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
        		context.getViewRoot().getLocale());

		 if(val_content.equals("notype"))
	     {
			String errMsg = bundle.getString("section_content_type_required");
	     	throw new ValidatorException(new FacesMessage(errMsg));
	     }
	}

	/*
	 *  validates the content of editor. if no text is typed,throw required error message
	 */
	public void validateEditorContents(FacesContext context, UIComponent component, Object value)
	throws ValidatorException
	{
	//	logger.info("validateEditorContents");
		String errMsg1="";
		HtmlSelectBooleanCheckbox textual_comp = (HtmlSelectBooleanCheckbox)context.getViewRoot().findComponent(getFormName()).findComponent("contentext");
		HtmlSelectBooleanCheckbox video_comp = (HtmlSelectBooleanCheckbox)context.getViewRoot().findComponent(getFormName()).findComponent("contentvideo");
		HtmlSelectBooleanCheckbox audio_comp = (HtmlSelectBooleanCheckbox)context.getViewRoot().findComponent(getFormName()).findComponent("contentaudio");

		if(!(textual_comp.isSelected() || video_comp.isSelected()  || audio_comp.isSelected()))
	     {
		 	//System.out.println("validate modality throwing exception");
			ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
            		context.getViewRoot().getLocale());
			errMsg1 = bundle.getString("add_section_modality_reqd");
	     	//throw new ValidatorException(new FacesMessage(errMsg));
		 }

		String val_content = (String) value;
		val_content = val_content.trim();
	//	logger.info("validateEditorContents"+val_content +val_content.length() + val_content.equals("<p>&#160;</p>") + val_content.equals("<p>\r&#160;\r</p>"));
		ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
        		context.getViewRoot().getLocale());

		HtmlSelectOneMenu content_menu = (HtmlSelectOneMenu)context.getViewRoot().findComponent(getFormName()).findComponent("contentType");

		if(content_menu.getLocalValue().equals("typeEditor"))
		{
			if(val_content == null || val_content.length() <= 17)
			{
			String errMsg = bundle.getString("section_content_required");
			String errMsg2 = errMsg1 + errMsg;
			logger.error("validateEditorContents throws exception");
		   	throw new ValidatorException(new FacesMessage(errMsg2));
			}
		}
	}

	/**
	 * checks if modality required field is there or not
	 * @param context
	 * @param component
	 * @param value
	 * @throws ValidatorException
	 */
	public void validateModalityInfo(FacesContext context, UIComponent component, Object value)
	throws ValidatorException
	{
		HtmlSelectBooleanCheckbox textual_comp = (HtmlSelectBooleanCheckbox)context.getViewRoot().findComponent(getFormName()).findComponent("contentext");
		HtmlSelectBooleanCheckbox video_comp = (HtmlSelectBooleanCheckbox)context.getViewRoot().findComponent(getFormName()).findComponent("contentvideo");
		HtmlSelectBooleanCheckbox audio_comp = (HtmlSelectBooleanCheckbox)context.getViewRoot().findComponent(getFormName()).findComponent("contentaudio");

		if(!(textual_comp.isSelected() || video_comp.isSelected()  || audio_comp.isSelected()))
	     {
		 	//System.out.println("validate modality throwing exception");
			ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
            		context.getViewRoot().getLocale());
			String errMsg = bundle.getString("add_section_modality_reqd");
	     	throw new ValidatorException(new FacesMessage(errMsg));
		 }
	}


	/*
	 * this method guesses if the link provided by user is broken or not.
	 * if its a valid http:// url then returns "OK" other wise error message.
	 */
	protected String validateLink(String urlname) throws MalformedURLException,UnknownHostException,MeleteException
	{
		try{
		  	URL url = new URL(urlname);
		  	HttpURLConnection uc = (HttpURLConnection) url.openConnection();
		  	String serverReplies = uc.getResponseMessage();
		  	// if link is ok server replies "OK" otherwise its
		  	// null or "Not Found"
		  	if(serverReplies != null && serverReplies.equals("OK"))
		  		return "OK";
		  	else return "Link possibly broken or not found";
		 }
		catch(MalformedURLException me)
		{
			logger.error(me.toString());
			throw me;
		}
		catch(UnknownHostException ue)
		{
			logger.error(ue.toString());
			throw ue;
		}
		catch(Exception e)
		{
			logger.error(e.toString());
			throw new MeleteException("add_section_bad_link");
		}

	}

	public abstract String saveHere();

	/*
	 * Edit Module page
	 * Rashmi -- 11/23 bug fix#125
	 * revision 12/20 -- to save automatically rather than prompting
	 */
	public String base_editModulefromSection()
	{
		//System.out.println("Hello Rashmi ------editModulefromSection called");
		 FacesContext context = FacesContext.getCurrentInstance();
			if(!success)
			{
				success=false;
				if(!saveHere().equals("failure"))
				{
				success=true;
				}else return "failure";
			}
			// setting for breadcrumbs
			ValueBinding binding = Util.getBinding("#{secBcPage}");
	  	    SecBcPage sbcPage = (SecBcPage) binding.getValue(context);
	  	    sbcPage.setModuleId(section.getModuleId());
	  	    sbcPage.setShowSeqNo(-1);
	  	    sbcPage.setEditMode(true);
	  	    sbcPage.setShowTextOnly(false);

	  	    ModuleDateBean mdBean = new ModuleDateBean();
	  	    mdBean.setModuleId(this.module.getModuleId().intValue());
		    mdBean.setModule((Module)this.module);
		    ModuleShdates mshdates = (ModuleShdates) this.module.getModuleshdate();

		    mdBean.setModuleShdate(mshdates);
		    binding = Util.getBinding("#{editModulePage}");
		  	EditModulePage emPage = (EditModulePage) binding.getValue(context);
		  	emPage.setEditInfo(mdBean);
	  	    return "success";
	}

	/*
	 * listener to set action for save button for setting data from html editor
	 */
	public void saveListener(ActionEvent event)
	{
		System.out.println("Hello Rashmi ------saveListener called");
	}

	/*
	 * Render instructions on preview page
	 */
	public boolean getRenderInstr()
	{
		if (this.section.getInstr()== null ||this.section.getInstr().length() == 0 )
			renderInstr=false;
		else renderInstr=true;
		return renderInstr;
	}


	/*
	 * Preview Section
	 */
	public String PreviewSection()
	{
		//System.out.println("pre view sec called");
		FacesContext ctx = FacesContext.getCurrentInstance();

		ValueBinding binding =
            Util.getBinding("#{viewSectionsPage}");
		ViewSectionsPage vsPage = (ViewSectionsPage)
            binding.getValue(ctx);
            vsPage.setModuleId(section.getModuleId());
            vsPage.setSeqNo(section.getSeqNo());
          //  vsPage.setSecOffset(0);
            return "preview_section_student";
	}

	/*
	 * Preview Module
	 */

	public String PreviewModule()
	{
		//System.out.println("pre view mod called");
		FacesContext ctx = FacesContext.getCurrentInstance();
		Map sessionMap = ctx.getExternalContext().getSessionMap();
		ValueBinding binding =
            Util.getBinding("#{viewModulesPage}");
		ViewModulesPage vmPage = (ViewModulesPage)
            binding.getValue(ctx);
		vmPage.setModuleId(module.getModuleId().intValue());
		vmPage.setModule(null);
		try {
	  		ModuleService modServ = getModuleService();
	  		CourseModule cMod = (CourseModule)modServ.getCourseModule(module.getModuleId().intValue(),(String)sessionMap.get("courseId"));
	  		vmPage.setModuleSeqNo(cMod.getSeqNo());
		}
		catch (Exception e)
		{
	  		//e.printStackTrace();
	  		logger.error(e.toString());
		}
        return "preview_module";
	}

	/*
	 * Revised Rashmi on 1/21/05
	 * new var module number set back to 0
	 */
	public void resetSectionValues()
	{
	 this.section= null;
     contentEditor=null;
     setSuccess(false);
     hiddenUpload=null;
     shouldRenderuploadFileName=false;
     uploadFileName=null;
     checkUploadChange=null;
	uploadFile=null;
	moduleNumber=0;
	previewTempUpload = null;
	System.out.println("!!!!!!!!!reseting section values done !!!!!!!");
	}


	/*
	 * get tentative seq# assigned to module. bug fix #211
	 * Rashmi - 1/21
	 */
	public String getModuleNumber()
	{
		try{
		/*if(module == null)
			{
			System.out.println("getmodulenumber method has module as null so get module");
			getModule();
			//this.module = (Module)section.getModule();
			}
			*/
			this.module= getModule();
		CourseModule cm = (CourseModule) this.module.getCoursemodule();
		if (cm == null)
			{
				logger.error("getcourseModules is null");
				return "0";
			}
		moduleNumber = cm.getSeqNo();

	}catch(Exception e)
		{
			logger.error("error in section - get module number "+ e.toString());
			moduleNumber = 0;
			e.printStackTrace();
		}
		if(moduleNumber != 0 )
			return new Integer(moduleNumber).toString();
		else return "0";
	}




	/*
	 * set section titles for module finish page
	 */
	private List getSectionTitles(ModuleObjService module)
	{
		List sections = new ArrayList();
		StringBuffer sectionTitles = new StringBuffer();
		List allSections=module.getSections();
		if(allSections == null)
		{
	//		System.out.println("all sections of module are null");
			sectionTitles.append("Section names will appear here in breadcrumps as they get added.... ");
			sections.add(sectionTitles.toString());
			return sections;
		}
		int sz = allSections.size();
	//	System.out.println("sz of list " + sz);
		if (sz > 0)
		{
			ListIterator itr = allSections.listIterator();
			int count=0;
			while(itr!= null && itr.hasNext())
			{
				sectionTitles = new StringBuffer();
				SectionObjService s = (SectionObjService)itr.next();
				if(s !=null)
				{
					sectionTitles.append(s.getTitle());
					sections.add(sectionTitles.toString());
				}
			}
		}
		return sections;
	}

	/*
	 *
	 * Display sections in add module finish page
	 */

	public HtmlPanelGrid getFinishTable() {
		return null;
	}

	public void setFinishTable(HtmlPanelGrid finishTable){
		try
		{
		String var="sections";
		finishTable.setColumns(2);
		List list = finishTable.getChildren();
		list.clear();

		UIColumn col,col1;
		HtmlOutputText out;

	 	HtmlOutputText headerText1 = new HtmlOutputText();
		 headerText1.setValue("Module Title");
	 	 col1 = new UIColumn();
		 col1.getChildren().add(headerText1);
		 HtmlOutputText headerText = new HtmlOutputText();
		 headerText.setValue(module.getTitle());
	 	 col = new UIColumn();
        col.getChildren().add(headerText);
        list.add(col1);
		 list.add(col);

		 headerText1 = new HtmlOutputText();
		 headerText1.setValue("Description");
	 	 col1 = new UIColumn();
		 col1.getChildren().add(headerText1);
		 headerText = new HtmlOutputText();
		 headerText.setValue(module.getDescription());
	 	 col = new UIColumn();
        col.getChildren().add(headerText);
        list.add(col1);
		 list.add(col);

		 headerText1 = new HtmlOutputText();
		 headerText1.setValue("Author");
	 	 col1 = new UIColumn();
		 col1.getChildren().add(headerText1);
		 headerText = new HtmlOutputText();
		 headerText.setValue(getAuthor());
	 	 col = new UIColumn();
        col.getChildren().add(headerText);
        list.add(col1);
		 list.add(col);

		 headerText1 = new HtmlOutputText();
		 headerText1.setValue("Institution");
	 	 col1 = new UIColumn();
		 col1.getChildren().add(headerText1);
		 headerText = new HtmlOutputText();
		 headerText.setValue(module.getInstitute());
	 	 col = new UIColumn();
        col.getChildren().add(headerText);
        list.add(col1);
		 list.add(col);

		ArrayList sectionTitles = (ArrayList)getSectionTitles(module);
		 for(int i=0; i < sectionTitles.size(); i++)
			{
		 	 headerText1 = new HtmlOutputText();
			 headerText1.setValue("Section "+(i+1));
		 	 col1 = new UIColumn();
			 col1.getChildren().add(headerText1);
			 headerText = new HtmlOutputText();
			 headerText.setValue((String)sectionTitles.get(i));
		 	 col = new UIColumn();
	         col.getChildren().add(headerText);
             list.add(col1);
			 list.add(col);
			}

		 	this.finishTable = finishTable;

		 // System.out.println("out of finish table section part");
		}catch(Exception e)
		{
			logger.error(e.toString());
		}
	}

	/**
	 * @return remove values from session before closing
	 */
	public String cancel()
	{
		FacesContext context = FacesContext.getCurrentInstance();
		Map sessionMap = context.getExternalContext().getSessionMap();
		if(sessionMap.containsKey("currModule"))
		{
			sessionMap.remove("currModule");
	//		System.out.println("removing curr module from session");
		}
		resetSectionValues();
		return "list_auth_modules";
	}


	/**
	 * @return uploaded file or link name for preview page
	 */
	public String getContentLink()
	{
	//	System.out.println("getContentLink fn is called");
		if(this.section.getContentType().equals("typeLink"))
		{
			return this.section.getLink();
		}
		else if(this.section.getContentType().equals("typeUpload"))
		{
			return getUploadFile();
		}
		else return "#";
	}


	public String getFormName(){
		return formName;
		}

	  /**
	  * @param formName
	  */
	  public void setFormName(String formName){
	  	this.formName = formName;
	   }

	  /*
	   * validate uploaded file name to see there are no reserver characters
	   * only allowed pattern is [a-zA-z0-9]_-.
	   * revised on 3/31 to remove path name
	   */
	  public boolean validateUploadFileName(String name)
	  {
	  		//System.out.println("file name for validation is" + name);

	  		if(name.indexOf("\\") != -1)
			{
			name=name.substring(name.lastIndexOf("\\")+1);
		//	System.out.println("new filename inside uploadcontents in windows style" + name);
			}
			else
			{
				name=name.substring(name.lastIndexOf("/")+1);
			//	System.out.println("new filename inside uploadcontents in linux style" + name);
			}
	  		int len =name.length();

	  			for(int i=0; i < len; i++)
	  			{
	  				char c = name.charAt(i);

	  				if (!Character.isLetterOrDigit(c))
	  					if(!(c=='-' || c=='_' || c=='.'))
	  					{
	  						logger.info("upload file name is not valid. It contains " + c +" which is not allowed");
	  						return false;
	  					}
	  			}
	  			return true;
	  }


// to add spring dependency methods
	/**
	 * @return Returns the SectionService.
	 */
	public SectionService getSectionService() {
		return sectionService;
	}
	/**
	 * @param SectionService The SectionService to set.
	 */
	public void setSectionService(SectionService sectionService) {
		this.sectionService = sectionService;
	}

	/**
	 * @return Returns the CoursePrefsService.
	 */
	public CoursePrefsService getCoursePrefsService() {
		return coursePrefsService;
	}
	/**
	 * @param CoursePrefsService The CoursePrefsService to set.
	 */
	public void setCoursePrefsService(CoursePrefsService coursePrefsService) {
		this.coursePrefsService = coursePrefsService;
	}

	/**
	 * @param serverConfigurationService The ServerConfigurationService to set.
	 */
	public void setServerConfigurationService(
			ServerConfigurationService serverConfigurationService) {
		this.serverConfigurationService = serverConfigurationService;
	}

	/**
	 * @return Returns the logger.
	 */

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

}