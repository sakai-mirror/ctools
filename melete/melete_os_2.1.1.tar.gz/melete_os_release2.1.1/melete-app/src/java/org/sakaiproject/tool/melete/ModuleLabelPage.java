/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-app/src/java/org/sakaiproject/tool/melete/ModuleLabelPage.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/

package org.sakaiproject.tool.melete;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ValueChangeEvent;

import org.sakaiproject.api.app.melete.CoursePrefsService;
import org.sakaiproject.service.framework.log.Logger;
//import org.sakaiproject.jsf.ToolBean;
/**
 * @author Mallika
 * Created on Apr 21, 2005 
 * 
 */
public class ModuleLabelPage implements Serializable/*,ToolBean*/{

	// attributes
	int count;
	private String mval;
	String courseId;
	private CoursePrefsService coursePrefsService;
	protected Logger logger = null;

	
	/**
	 * constructor
	 */
	public ModuleLabelPage() {
		//logger.info("Executing ModuleLabelPage constructor");
		
	}
		
	public void setMval(String mval)
	{
		this.mval = mval;
	}
	
	public String getMval()
	{
		logger.info("coming to getmval");
		FacesContext ctx = FacesContext.getCurrentInstance();
	  	Map sessionMap = ctx.getExternalContext().getSessionMap();
	  	courseId = (String)sessionMap.get("courseId");		
	  	logger.info("Got course id "+courseId);
		mval = getCoursePrefsService().getModuleLabel(courseId);
		logger.info("Got mlabel "+mval);
		return mval;
	}

	public String save()
	{
		logger.info("Coming to save");
		FacesContext ctx = FacesContext.getCurrentInstance();
	  	Map sessionMap = ctx.getExternalContext().getSessionMap();
	  	courseId = (String)sessionMap.get("courseId");
	  	logger.info("Courseid "+courseId+" modlabel is "+this.mval);
	  	LabelValidator lv = new LabelValidator();
	  	lv.isValidLabel(this.mval);
	  	try
		{
	  	  getCoursePrefsService().setModuleLabel(courseId, this.mval);
		}
	  	catch (Exception e)
		{
	  		logger.error("Error setting module label "+e.toString());
		}
	  	logger.info("set module label");
	  	FacesMessage msg =
	  		new FacesMessage("Module Label Message", "Label has been successfully changed.");
	  	msg.setSeverity(FacesMessage.SEVERITY_INFO);
	  	ctx.addMessage(null,msg);	  	
	    return "modules_author_manage";  	
	}
	
	public String cancel()
	{
		return "modules_author_manage";
	}
	
	/**
	 * @return Returns the CoursePrefsService.
	 */
	public CoursePrefsService getCoursePrefsService() {
		return coursePrefsService;
	}
	/**
	 * @param CoursePrefsService The CoursePrefsService to set.
	 */
	public void setCoursePrefsService(CoursePrefsService coursePrefsService) {
		this.coursePrefsService = coursePrefsService;
	}
	/**
	 * @return Returns the logger.
	 */
	
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
}
