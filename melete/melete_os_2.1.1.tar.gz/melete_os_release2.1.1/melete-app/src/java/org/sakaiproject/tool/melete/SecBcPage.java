/**********************************************************************************
*
* $Header: /usr/src/sakai/melete_2-1-0/melete-app/src/java/org/sakaiproject/tool/melete/SecBcPage.java,v 1.1 2005/11/23 21:37:24 murthyt Exp $
*
***********************************************************************************
*
* Copyright (c) 2005 Foothill College
*
* Licensed under the Educational Community License Version 1.0 (the "License");
* By obtaining, using and/or copying this Original Work, you agree that you have read,
* understand, and will comply with the terms and conditions of the Educational Community License.
* You may obtain a copy of the License at:
*
*     http://foothillglobalaccess.org/etudes2/sakai/melete_license_1_0.html 
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
**********************************************************************************/

package org.sakaiproject.tool.melete;
import javax.faces.application.*;
import java.util.*;
import javax.faces.component.*;
import javax.faces.component.html.*;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.io.Serializable;
import javax.faces.event.ActionEvent;

import javax.faces.context.FacesContext;
import javax.faces.el.PropertyNotFoundException;
import javax.faces.el.ValueBinding;
import javax.faces.el.MethodBinding;
import javax.faces.application.FacesMessage;

//import com.sun.faces.util.Util;
import java.sql.Timestamp;
import org.sakaiproject.component.app.melete.*;
import org.sakaiproject.api.app.melete.ModuleService;
import org.sakaiproject.api.app.melete.SectionService;
//import org.sakaiproject.jsf.ToolBean;
import org.sakaiproject.service.framework.log.Logger;
/**
 * @author Faculty
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Mallika -3/16/05 changed breadcrumb limit to 25
 * Mallika - 3/17/05, changed case and added in code for section link/upload
 * Mallika - 3/23/05, added this.editMode condition, now edit section breadcrumbs go to edit page
 * Mallika - 3/23/05, added this.showTextOnly condition to get rid of Up link bug on add section page
 **/

public class SecBcPage implements Serializable/*,ToolBean*/ {


	  /** identifier field */
      private int moduleId;
      private int showModuleId;
      private int showSeqNo;
      private boolean editMode;
      private boolean showTextOnly;
      public Module module;
      //private Module moduleBot;
      //private List sectionsBot;
      //private List moduleDateBeans = null;
      public HtmlDataTable tablesec;
      public HtmlPanelGroup pgroup;
      public HtmlPanelGroup pgroupBot;
      private List sections = null;
      private List list = null;

//    This needs to be set later using Utils.getBinding
	  String courseId;
      private ModuleService moduleService;
      private SectionService sectionService;
      
      /** Dependency:  The logging service. */
  	  protected Logger logger = null;


	  public SecBcPage(){
	  		
	  }

      /**
	   * @return Returns the ModuleService.
	   */
	  public ModuleService getModuleService() {
		return moduleService;
	  }

	 /**
	  * @param moduleService The moduleService to set.
	  */
	  public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	  }

    /**
	   * @return Returns the SectionService.
	   */
	  public SectionService getSectionService() {
		return sectionService;
	  }

	 /**
	  * @param sectionService The sectionService to set.
	  */
	  public void setSectionService(SectionService sectionService) {
		this.sectionService = sectionService;
	  }
	  
	  /**
		 * @param logger The logger to set.
	  */
	  public void setLogger(Logger logger) {
			this.logger = logger;
	  }
	  
	  public int getModuleId() {
        return this.moduleId;
    }

    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }

    public int getShowModuleId() {
        return this.showModuleId;
    }

    public void setShowModuleId(int moduleId) {
        this.showModuleId = moduleId;
    }
    public int getShowSeqNo() {
        return this.showSeqNo;
    }

    public void setShowSeqNo(int seqNo) {
        this.showSeqNo = seqNo;
    }

    /*editMode decides if breadcrumbs point to view or edit section pages*/
    public boolean getEditMode() {
    	return this.editMode;
    }
    public void setEditMode(boolean editMode) {
    	this.editMode = editMode;
    }

    /*showTextOnly is set for situations where we don't want hyperlinks for breadcrumbs*/
    public boolean getShowTextOnly() {
    	return this.showTextOnly;
    }
    public void setShowTextOnly(boolean showTextOnly) {
    	this.showTextOnly = showTextOnly;
    }

    public Module getModule()
    {
    	try {
  	  	  logger.info("Executing getmodule in secbcpage");
  	  	  this.module = (Module) getModuleService().getModule(this.moduleId);
  	  	}
  	  	catch (Exception e)
          {
  		  //e.printStackTrace();
  	  		logger.error(e.toString());
          }
  	  	return this.module;
    }

    public void setModule(Module module){
      this.module = module;
    }
    
    /*public Module getModuleBot()
    {
    	return this.moduleBot;
    }
    
    public void setModuleBot(Module moduleBot){
    	this.moduleBot = moduleBot;
    }
    
    public List getSectionsBot()
    {
    	return this.sectionsBot;
    }
    
    public void setSectionsBot(List sectionsBot)
    {
    	this.sectionsBot = sectionsBot;
    }*/


      public HtmlPanelGroup getPgroup() {
        logger.info("get panel group being invoked in secbcpage");
  	  return null;
      }

      public void setPgroup(HtmlPanelGroup pgroup){
      	try
		{
      	logger.info("set pgroup being invoked in secbcPage");
  	    FacesContext context = FacesContext.getCurrentInstance();
  	    //UIViewRoot root= context.getViewRoot();
  	    //UIData breadcrumps =(UIData) root.findComponent("AddSectionForm").findComponent("breadcrumps").findComponent("breadcrumpsTable");
  	    //String var = breadcrumps.getVar();


  	    list = pgroup.getChildren();
  	    list.clear();


  	    Application app = context.getApplication();
  	    this.module = getModule();
  	    //this.moduleBot = this.module;
  	    sections = (List) getSectionService().getSections(this.moduleId);
  	    //sectionsBot = sections;
  	    Class[] param;
  	    UIParameter modidParam = null;
  	    UIParameter seqnoParam = null;
  	    //UIParameter secOffsetParam = null;
  	    HtmlOutputText out = null;
  	    HtmlOutputText headerText = null;
  	    HtmlCommandLink clink = null;
  	    HtmlOutputLink olink = null;
  	    MethodBinding mbalistener = null;
  	    MethodBinding mbaction = null;
  	    ActionEvent evt = null;
  	    String methodListener = null;
  	    String methodAction = null;
  	    Iterator secIterator = sections.iterator();
  	    int i = 0;
  	    int secSize = 0;
  	    if (sections.size() > 0)
  	    {
  	      secSize = sections.size();	
  	      //Add the up link to view module only in view mode
  	      //3/23/05 - put this if condition in to get rid of up link bug
  	      if (this.showTextOnly != true)
  	      {	
  	        if (this.editMode == false)
  	        {
  	        param = new Class[1];
            clink = new HtmlCommandLink();
            evt = new ActionEvent(clink);
            param[0] = evt.getClass();
            mbalistener = app.createMethodBinding("#{viewModulesPage.viewModule}", param);
            mbaction = app.createMethodBinding("#{viewModulesPage.redirectToViewModule}", null);
            clink.setId("up"+i);
            clink.setActionListener(mbalistener);
            clink.setAction(mbaction);
            out = new HtmlOutputText();
            out.setId("uptext"+i);
            //out.setValue(mod.getTitle().toString());
            out.setValue("Up");
            modidParam = new UIParameter();
            modidParam.setName("modid");
            modidParam.setValue(this.module.getModuleId());
            clink.getChildren().add(out);
            clink.getChildren().add(modidParam);
            list.add(clink);
            headerText = new HtmlOutputText();
            headerText.setId("raq"+i);
  		    headerText.setTitle(" "+(char)187+" ");
  		    headerText.setValue(" "+(char)187+" ");
  		    list.add(headerText);
  		    i++;
  		    methodListener = "#{viewSectionsPage.viewSection}";
	      	methodAction = "#{viewSectionsPage.redirectToViewSection}";
  	        }
  	        else
  	        {
  	        methodListener = "#{editSectionPage.editSection}";
	      	methodAction = "#{editSectionPage.redirectToEditSection}";
  	        }
  	      }
  	    }
  	    while (secIterator.hasNext())
  	    {
  	      Section curSec = (Section)secIterator.next();
  	      logger.info("In top group secbc, Sec is "+curSec);

  	      //Need to add this in because of dummy section
  	      if (curSec != null)
  	      {
  	        out = new HtmlOutputText();
  	        out.setId("sectext"+i);
  	        logger.info("In top group, sectext being set to "+i);

  	        if (this.showTextOnly == true)
	        {
  	          if (secSize > 3)
  	          {	
	      	    out.setValue(createBcstr(curSec.getTitle()));
  	          }
  	          else
  	          {
  	            out.setValue(curSec.getTitle());
  	          }
	      	  list.add(out);
            }
	        else
	        {
		      	if ((this.module.getModuleId().intValue() == getShowModuleId())&&(curSec.getSeqNo() == getShowSeqNo()))
	  		    {
		      	  if (secSize > 3)
		  	      {	
			        out.setValue(createBcstr(curSec.getTitle()));
		  	      }
		  	      else
		  	      {
		  	        out.setValue(curSec.getTitle());
		  	      }
	  		  	  list.add(out);
	  		    }
	  		    else
	  		    {
	  		    	param = new Class[1];
			        clink = new HtmlCommandLink();
			        evt = new ActionEvent(clink);
		  	        param[0] = evt.getClass();
		  	        //Mallika - 3/17/05 - to redirect to link/upload 
		  	        //Mallika - 3/23/05 - added this.editMode condition
		  	        if (this.editMode == false)
		  	        {	
		  	          if(curSec.getContentType().equals("typeEditor"))
			    	  {
		  	        	methodAction = "#{viewSectionsPage.redirectToViewSection}";
			    	  }
		  	          else
		  	          {
		  	        	methodAction = "#{viewSectionsPage.redirectToViewLinkSection}";
		  	          }
		  	        }
		  	        mbalistener = app.createMethodBinding(methodListener, param);
		            mbaction = app.createMethodBinding(methodAction, null);
		  	        clink.setId("sec"+i);
		  	        clink.setActionListener(mbalistener);
		  	        clink.setAction(mbaction);
		  	      	modidParam = new UIParameter();
		  	        modidParam.setName("modid");
		  	        modidParam.setValue(this.module.getModuleId());
		  	        if (secSize > 3)
	  	            {	
		      	      out.setValue(createBcstr(curSec.getTitle()));
	  	            }
	  	            else
	  	            {
	  	              out.setValue(curSec.getTitle());
	  	            }
		  	        clink.getChildren().add(out);
		  	        clink.getChildren().add(modidParam);
		  	        seqnoParam = new UIParameter();
		  	        seqnoParam.setName("seqno");
			        seqnoParam.setValue(new Integer(curSec.getSeqNo()));
			        clink.getChildren().add(seqnoParam);
	                list.add(clink);
	                evt = null;
		  		    mbalistener = null;
		  		    mbaction = null;
	  		    }

		        /*secOffsetParam = new UIParameter();
		        secOffsetParam.setName("secoffset");
		        secOffsetParam.setValue(new Integer(0));
		        clink.getChildren().add(secOffsetParam);*/
		      }

  		    headerText = new HtmlOutputText();
  		    headerText.setId("raq"+i);
		    headerText.setTitle(" "+(char)187+" ");
		    headerText.setValue(" "+(char)187+" ");
		    //headerText.setValue(mod.getTitle().toString()+" " + (char)187 + " ");

		    if (secIterator.hasNext())
		    {
		      list.add(headerText);
		    }

  		  i++;
  	      }//end if cursec != null
  		}//end while
  	 	this.pgroup = pgroup;
  	 	//this.pgroupBot = pgroup;
  	 	//logger.info("out of get titles in settablessec in secbc "+list.size());
  	}
  	catch(Exception e)
  	{
  		//e.printStackTrace();
  		logger.error(e.toString());
  	}
      }
      public HtmlPanelGroup getPgroupBot() {
        logger.info("get panel group bot being invoked in secbcpage");
  	  return null;
      }

      public void setPgroupBot(HtmlPanelGroup pgroupBot){
      	/*logger.info("Setting bot panel group");
        List listBot = pgroupBot.getChildren();
  	    listBot.clear();
  	    logger.info("list size here is "+list.size());
  	    Object[] lisArray = list.toArray();
  	    list = null;
 	    logger.info("lisarr size is "+lisArray.length);
 	    for (int i=0; i<lisArray.length; i++)
        { 
 	    	Object obj = lisArray[i];
 	    	logger.info(obj.toString());
 	    	try
			{
 	    	  boolean res = listBot.add(obj);
 	    	  //logger.info("Result is "+res);
			}
 	    	catch (Exception e)
			{
 	    		logger.info(e.toString());
			}
 	    	
        }
 	   logger.info("List bot size is "+listBot.size());
 	    pgroupBot.setStyleClass("center");
 	    this.pgroupBot = pgroupBot;
 	    logger.info("List bot size at end first is "+pgroupBot.getChildren().size());
	    
 	    logger.info("List bot size at end is "+this.pgroupBot.getChildren().size());
 	    */
      	try
		{
      	logger.info("set panel group bot being invoked in secbcpage");
        FacesContext context = FacesContext.getCurrentInstance();
  	    //UIViewRoot root= context.getViewRoot();
  	    //UIData breadcrumps =(UIData) root.findComponent("AddSectionForm").findComponent("breadcrumps").findComponent("breadcrumpsTable");
  	    //String var = breadcrumps.getVar();


  	    List list = pgroupBot.getChildren();
  	    list.clear();


  	    Application app = context.getApplication();
  	    //this.module = getModule();
  	    //sections = (List) getSectionService().getSections(this.moduleId);
  	    Class[] param;
  	    UIParameter modidParam = null;
  	    UIParameter seqnoParam = null;
  	    //UIParameter secOffsetParam = null;
  	    HtmlOutputText out = null;
  	    HtmlOutputText headerText = null;
  	    HtmlCommandLink clink = null;
  	    HtmlOutputLink olink = null;
  	    MethodBinding mbalistener = null;
  	    MethodBinding mbaction = null;
  	    ActionEvent evt = null;
  	    String methodListener = null;
  	    String methodAction = null;
  	    Iterator secIterator = sections.iterator();
  	    int i = 0;
  	    int secSize = 0;
  	    if (sections.size() > 0)
  	    {
  	      secSize = sections.size();
  	      //Add the up link to view module only in view mode
//  	  3/23/05 - put this if condition in to get rid of up link bug
  	      if (this.showTextOnly != true)
  	      {	
  	        if (this.editMode == false)
  	        {
  	        param = new Class[1];
            clink = new HtmlCommandLink();
            evt = new ActionEvent(clink);
            param[0] = evt.getClass();
            mbalistener = app.createMethodBinding("#{viewModulesPage.viewModule}", param);
            mbaction = app.createMethodBinding("#{viewModulesPage.redirectToViewModule}", null);
            clink.setId("up"+i);
            clink.setActionListener(mbalistener);
            clink.setAction(mbaction);
            out = new HtmlOutputText();
            out.setId("uptext"+i);
            //out.setValue(mod.getTitle().toString());
            out.setValue("Up");
            modidParam = new UIParameter();
            modidParam.setName("modid");
            modidParam.setValue(this.module.getModuleId());
            clink.getChildren().add(out);
            clink.getChildren().add(modidParam);
            list.add(clink);
            headerText = new HtmlOutputText();
            headerText.setId("raq"+i);
  		    headerText.setTitle(" "+(char)187+" ");
  		    headerText.setValue(" "+(char)187+" ");
  		    list.add(headerText);
  		    i++;
  		    methodListener = "#{viewSectionsPage.viewSection}";
	      	methodAction = "#{viewSectionsPage.redirectToViewSection}";
  	        }
  	        else
  	        {
  	        methodListener = "#{editSectionPage.editSection}";
	      	methodAction = "#{editSectionPage.redirectToEditSection}";
  	        }
  	      }

  	    }
  	    while (secIterator.hasNext())
  	    {
  	      Section curSec = (Section)secIterator.next();
  	    logger.info("In bot group secbc, Sec is "+curSec);

  	      //Need to add this in because of dummy section
  	      if (curSec != null)
  	      {
  	        out = new HtmlOutputText();
  	        out.setId("sectext"+i);
  	      logger.info("In bot group, sectext being set to "+i);
  	      
  	        if (this.showTextOnly == true)
	        {
  	        	if (secSize > 3)
    	        {	
  	      	      out.setValue(createBcstr(curSec.getTitle()));
    	        }
    	        else
    	        {
    	          out.setValue(curSec.getTitle());
    	        }
	      	  list.add(out);
            }
	        else
	        {
		      	if ((this.module.getModuleId().intValue() == getShowModuleId())&&(curSec.getSeqNo() == getShowSeqNo()))
	  		    {
		      		if (secSize > 3)
		  	        {	
			      	  out.setValue(createBcstr(curSec.getTitle()));
		  	        }
		  	        else
		  	        {
		  	          out.setValue(curSec.getTitle());
		  	        }
	  		  	  list.add(out);
	  		    }
	  		    else
	  		    {
	  		    	param = new Class[1];
			        clink = new HtmlCommandLink();
			        evt = new ActionEvent(clink);
		  	        param[0] = evt.getClass();
		  	        //Mallika - 3/17/05 - to redirect to link/upload 
//		  	        //Mallika - 3/23/05 - added this.editMode condition
		  	        if (this.editMode == false)
		  	        {	
		  	          if(curSec.getContentType().equals("typeEditor"))
			    	  {
		  	        	methodAction = "#{viewSectionsPage.redirectToViewSection}";
			    	  }
		  	          else
		  	          {
		  	        	methodAction = "#{viewSectionsPage.redirectToViewLinkSection}";
		  	          }
		  	        }
		  	        mbalistener = app.createMethodBinding(methodListener, param);
		            mbaction = app.createMethodBinding(methodAction, null);
		  	        clink.setId("sec"+i);
		  	        clink.setActionListener(mbalistener);
		  	        clink.setAction(mbaction);
		  	      	modidParam = new UIParameter();
		  	        modidParam.setName("modid");
		  	        modidParam.setValue(this.module.getModuleId());
		  	        if (secSize > 3)
	  	            {	
		      	      out.setValue(createBcstr(curSec.getTitle()));
	  	            }
	  	            else
	  	            {
	  	              out.setValue(curSec.getTitle());
	  	            }
		  	        clink.getChildren().add(out);
		  	        clink.getChildren().add(modidParam);
		  	        seqnoParam = new UIParameter();
		  	        seqnoParam.setName("seqno");
			        seqnoParam.setValue(new Integer(curSec.getSeqNo()));
			        clink.getChildren().add(seqnoParam);
	                list.add(clink);
	                evt = null;
		  		    mbalistener = null;
		  		    mbaction = null;
	  		    }

		        /*secOffsetParam = new UIParameter();
		        secOffsetParam.setName("secoffset");
		        secOffsetParam.setValue(new Integer(0));
		        clink.getChildren().add(secOffsetParam);*/
		      }

  		    headerText = new HtmlOutputText();
  		    headerText.setId("raq"+i);
		    headerText.setTitle(" "+(char)187+" ");
		    headerText.setValue(" "+(char)187+" ");
		    //headerText.setValue(mod.getTitle().toString()+" " + (char)187 + " ");

		    if (secIterator.hasNext())
		    {
		      list.add(headerText);
		    }
  		   

  		  i++;
  	      }//end if cursec != null
  		}//end while
  	 	this.pgroupBot = pgroupBot;
  	 	//logger.info("out of get titles in settablessec in secbc "+list.size());
  	}
  	catch(Exception e)
  	{
  		//e.printStackTrace();
  		logger.error(e.toString());
  	}      	
      }
    public String createBcstr(String bc_str)
    {
      String newbc_str = null;
      if (bc_str.length() <= 25) return bc_str.trim();
      if (bc_str.length() > 25)
      {
      	newbc_str = bc_str.substring(0,21);
      	newbc_str = newbc_str.concat("...");
      }
      //logger.info("Newbcstr is "+newbc_str);
      return newbc_str;
    }

}
