/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-app/src/java/org/sakaiproject/tool/melete/ModuleValidator.java,v 1.2 2006/06/06 21:51:49 mallikat Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.tool.melete;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.faces.application.FacesMessage;

//import com.sun.faces.util.MessageFactory;

import java.util.ResourceBundle;
import java.util.StringTokenizer;
/**
 * @author Rashmi
 *
 * This class validates user input for title, keywords and if learning objectives or 
 * description is there.
 * 
 * for title , rules are special characters allowed are , / - & _
 * for keywords, rules are warn user if keywords is more than 3 words and not
 *  comma seperated.
 * 
 * Revision -- 12/13 added invalid-title_len for cases like '    5' and '    5'.
 * Revised by rashmi on 6/14/05 - min length allowed is 3 chars
 * Mallika - 4/24/06 - adding + to title
 * Mallika - 5/31/06 - adding ! to title
 **/

public class ModuleValidator implements Validator {
	
	public void validate(FacesContext context, UIComponent component, Object value)
	throws ValidatorException
	{
		String val = (String) value;
		val = val.trim();
		int len =val.length();
	
		if(len < 3 || len > 50)
		{
			ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
            		context.getViewRoot().getLocale());
			String errMsg = "";
	     	errMsg = bundle.getString("invalid_title_len");
	        throw new ValidatorException(new FacesMessage(errMsg));
		}
		if (!isValidTitle(val))
		{
			ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
            		context.getViewRoot().getLocale());
			String errMsg = "";
	     	errMsg = bundle.getString("invalid_title");
	        throw new ValidatorException(new FacesMessage(errMsg));
		}
	}
	/**
	 * @param title
	 * @return
	 * Revision -- 11/29 Rashmi 
	 * check if string is empty or just spaces
	 *
	 */
	public boolean isValidTitle(String title)
	{
		int len =title.length();
			
		for(int i=0; i < len; i++)
		{
			char c = title.charAt(i);
			
			if (!Character.isLetterOrDigit(c))
				if(!(c == ' ' ||c == ',' || c=='/' || c=='-' || c=='&' || c=='_' || c=='\'' || c=='.' || c=='?' || c=='+' || c=='!'))
				{
					System.out.println("title is not valid. It contains " + c +" which is not allowed");
					return false;
				}					
		}
		return true;
	}
	
	/**
	 * @param keywords
	 * @return
	 */
	public boolean isValidKeywords(String keywords)
	{
		StringTokenizer str = new StringTokenizer(keywords);
		if(str.countTokens() > 3 && keywords.indexOf(",") == -1)
		{
			System.out.println("Warning !! Keywords should be seperated by commas.");
			return false;
		}
		return true;
	}
		
}