/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-app/src/java/org/sakaiproject/tool/melete/ViewModulesPage.java,v 1.6 2006/10/19 23:45:33 mallikat Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/

package org.sakaiproject.tool.melete;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.sakaiproject.api.app.melete.*;

import javax.faces.component.*;
import java.util.List;
import java.util.Map;
import java.io.Serializable;
import javax.faces.event.ActionEvent;

import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
//import com.sun.faces.util.Util;
import org.sakaiproject.component.app.melete.*;
import org.sakaiproject.api.app.melete.ModuleService;
//import org.sakaiproject.jsf.ToolBean;

/**
 * @author Faculty
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
/*
 *
 * modified by rashmi - 03/10/05 bug#282- added seperate page for links and upload to show them in frame
 * mallika - 3/21/05 - if condition in view section method change
 * mallika - 3/30/05 - added null check in constructor
 * Mallika - 4/22/05 - Added the association to display module label
 * Mallika - 5/23/05 - For better performance, changed the getCourseModule code
 * Mallika - 5/24/05 - Added setLicenseCode to viewsections
 * Rashmi - 6/14/05 - Added setModule to null for FairUse license bug.
 * Rashmi - 8/2/06 -  navigate TOC
 * Rashmi - 8/4/06 - removed mval and its related code 
 * Rashmi - 8/7/06 - remove coursePrefsService references
 * Rashmi - 8/9/06 - remove modbcpage and secbcpage references and clean up code
 * Mallika - 10/19/06 - changing viewsection method to go to view_section_link only with typeUpload
*/


public class ViewModulesPage implements Serializable/*,ToolBean*/ {


	  /** identifier field */
      private int moduleId;
      private int moduleSeqNo;
      public ModuleObjService module;
      private List moduleDateBeans = null;

      private boolean instRole;
      private int sectionSize;
      private String role;
      private String nullString = null;

//    This needs to be set later using Utils.getBinding
	  String courseId;


	  private ModuleService moduleService;
	   /** Dependency:  The logging service. */
	  protected Log logger = LogFactory.getLog(ViewModulesPage.class);
  	
	  public ViewModulesPage(){

	  	FacesContext context = FacesContext.getCurrentInstance();
	  	Map sessionMap = context.getExternalContext().getSessionMap();
	  	courseId = (String)sessionMap.get("courseId");

		role = (String)sessionMap.get("role");
		if (role != null && role.equals("INSTRUCTOR"))
		{
			setInstRole(true);
		}
		else
		{
			setInstRole(false);
		}
	  }

     /**
	   * @return Returns the ModuleService.
	   */
	  public ModuleService getModuleService() {
		return moduleService;
	  }

	 /**
	  * @param moduleService The moduleService to set.
	  */
	  public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	  }
	 
	  /**
		 * @param logger The logger to set.
	  */
	  public void setLogger(Log logger) {
			this.logger = logger;
	  }
	  public String getNullString() {
	  	return nullString;
	  }

	  public void setNullString(String nullString) {
	  	this.nullString = nullString;
	  }


	  public int getModuleId() {
        return this.moduleId;
    }

    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }
    public int getModuleSeqNo() {
        return this.moduleSeqNo;
    }

    public void setModuleSeqNo(int moduleSeqNo) {
        this.moduleSeqNo = moduleSeqNo;
    }
    public ModuleObjService getModule()
    {
      if (this.module == null)
 	  {
    	try {

  	  	  this.module = (ModuleObjService) getModuleService().getModule(this.moduleId);
  	  	}
  	  	catch (Exception e)
          {
  		  //e.printStackTrace();
  	  		logger.error(e.toString());
          }
 	  }
  	  	return this.module;
    }

    public void setModule(ModuleObjService module){
      this.module = module;
    }
    public int getSectionSize() {
    	if (this.module == null) getModule();
    	
    	if (getModule().getSections() != null)
    	{
    	  this.sectionSize = getModule().getSections().size();
    	}
    	else
    	{
    		this.sectionSize = 0;
    	}
        return this.sectionSize;
    }

    public void setSectionSize(int sectionSize) {
        this.sectionSize = sectionSize;
    }

    public List getModuleDateBeans() {
    	//logger.info("getModuleDateBeans being invoked in viewmodulespage");

    	try {
	  		moduleDateBeans = getModuleService().getModuleDateBeans(courseId);
	  	}catch (Exception e)
		{
	  		//e.printStackTrace();
	  		logger.error(e.toString());
		}

	  	return moduleDateBeans;
    }
    public void setModuleDateBeans(List moduleDateBeans) {
    	this.moduleDateBeans = moduleDateBeans;
    }

    public boolean getInstRole()
    {
    	FacesContext context = FacesContext.getCurrentInstance();
	  	Map sessionMap = context.getExternalContext().getSessionMap();
	  	if ((String)sessionMap.get("role") !=null)
	  		this.instRole = ((String)sessionMap.get("role")).equals("INSTRUCTOR");
	  	else this.instRole = false;
    	return instRole;
    }

    public void setInstRole(boolean instRole)
    {
    	this.instRole = instRole;
    }
     
    /*
     *
     * modified by rashmi - 03/10/05
     *  added seperate page for links and upload to show them in frame
     */

    public String viewSection() {

	  	logger.info("VIEW SECTION BEING INVOKED  in viewmodulespage");
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	 UIViewRoot root = ctx.getViewRoot();

	        UIData table = (UIData)
	            root.findComponent("viewmoduleform").findComponent("tablesec");

	    ValueBinding binding =
	            Util.getBinding("#{viewSectionsPage}");

	    ViewSectionsPage vsPage = (ViewSectionsPage)
	            binding.getValue(ctx);

	            SectionObjService sec = (SectionObjService) table.getRowData();
	            vsPage.setModuleId(sec.getModuleId());
	            vsPage.setSeqNo(sec.getSeqNo());
	            vsPage.setSection(null);
	            //added by rashmi on 6/14/05
	            vsPage.setModule(null);
	            vsPage.setSectionSize(-1);
	            //vsPage.setSecOffset(0);
	           /* ModuleObjService mod = (ModuleObjService) getModuleService().getModule(sec.getModuleId());
	            vsPage.setModuleTitle(mod.getTitle());
	            vsPage.setLicenseCode(mod.getLicenseCode());
	           */
	            
	     String retVal = "view_section_student";

	    //03/10/05  rashmi - added seperate page for links and upload to show them in frame
	    //3/21/05 - mallika - the if condition was slightly ambiguous, so needed to change that
		logger.info("RASHMI - get Role in viewModules is called and contentt type"+ getInstRole()+  sec.getContentType().equals("typeEditor"));

	    if (getInstRole() == true)
	    {
	    	if(!(sec.getContentType().equals("typeUpload")))
	    	{
	    	logger.info("RASHMI instructor returning editor page");
	       	retVal = "view_section";
	    	}
	    	else
	    	{
	    		retVal = "view_section_link";
	    	}
	    }
	    else
	    {
	      if (!(sec.getContentType().equals("typeUpload")))
	      {
	    	logger.info("RASHMI returning student page");
	    	retVal = "view_section_student";
	      }
	      else
	      {
	      	retVal = "view_section_student_link";
	      }
	    }
	  	return retVal;
	  }

    public void viewModule(ActionEvent evt) {
    	FacesContext ctx = FacesContext.getCurrentInstance();
    	//logger.info("ViewModulesPage viewModule being invoked "+((UICommand)evt.getComponent()).getId());
    	UICommand cmdLink = (UICommand)evt.getComponent();
    	List cList = cmdLink.getChildren();
    	UIParameter param = new UIParameter();
    	for (int i=0; i< cList.size(); i++)
    	{
    		Object obj = cList.get(i);
    		if (obj instanceof UIParameter)
    		{
    		  param = (UIParameter) cList.get(i);
    		}
    	}
    	ValueBinding binding =
            Util.getBinding("#{viewModulesPage}");
         ViewModulesPage vmPage = (ViewModulesPage) binding.getValue(ctx);
         vmPage.setModuleId(((Integer)param.getValue()).intValue());
         vmPage.setModule(null);
         try {
	  		ModuleService modServ = getModuleService();
	  		CourseModule cMod = (CourseModule)modServ.getCourseModule(((Integer)param.getValue()).intValue(),courseId);
	  		vmPage.setModuleSeqNo(cMod.getSeqNo());
		}
		catch (Exception e)
		{
	  		//e.printStackTrace();
	  		logger.error(e.toString());
		}         
    }

    public String redirectToViewModule(){
    	String retVal = "view_module_student";
	    if (getInstRole() == true)
	    {
	    	retVal = "view_module";
	    }
	    if (getInstRole() == false)
	    {
	    	retVal = "view_module_student";
	    }
	  	return retVal;

    }
    
    /*
     * add by rashmi to navigate to table of contents
     */
    
    public String goTOC()
	{
		if (instRole) return "list_modules_inst";
		else return "list_modules_student";
	}
}
