/**********************************************************************************
*
* $Header: 
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import java.util.List;



/** @author Hibernate CodeGenerator */
public class ModuleDatePrivBean extends ModuleDateBean implements Serializable {


    
    /** nullable persistent field */
    private org.sakaiproject.component.app.melete.ModuleStudentPrivs moduleStudentPriv;
    private List sectionBeans;

    /** full constructor */
    public ModuleDatePrivBean(int moduleId, org.sakaiproject.component.app.melete.Module module, org.sakaiproject.component.app.melete.ModuleShdates moduleShdate, org.sakaiproject.component.app.melete.ModuleStudentPrivs moduleStudentPriv) {
        this.moduleId = moduleId;
        this.module = module;
        this.moduleShdate = moduleShdate;
        this.moduleStudentPriv = moduleStudentPriv;
    }

    /** default constructor */
    public ModuleDatePrivBean() {
    }

    
    public org.sakaiproject.component.app.melete.ModuleStudentPrivs getModuleStudentPriv() {
        return this.moduleStudentPriv;
    }

    public void setModuleStudentPriv(org.sakaiproject.component.app.melete.ModuleStudentPrivs moduleStudentPriv) {
        this.moduleStudentPriv = moduleStudentPriv;
    }
    public List getSectionBeans() {
        return this.sectionBeans;
    }

    public void setSectionBeans(List sectionBeans) {
        this.sectionBeans = sectionBeans;
    }

    
}
