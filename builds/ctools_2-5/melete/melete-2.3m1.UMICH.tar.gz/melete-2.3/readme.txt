MELETE 2.3 SETUP INSTRUCTIONS
For Sakai 2.2.x or higher
-----------------------------------------------------
SETUP INSTRUCTIONS

1. Melete Source
2. Configuring Melete  
	2.1 Important Settings
		2.1.1 Homedir settings
		2.1.2 Meletedocs settings
		2.1.3 Packagingdir settings
		2.1.4 Uploads settings
	2.2 Settings under Tomcat Instance
		2.2.1 Copy meleteDocs.xml 
		2.2.2 Revise meleteDocs.xml
3. Compile Melete 
	3.1 How to deploy the Melete version with the Sferyx Applet editor
4. Database Configuration
5. Update Sakai Roles (under realms)
6. Max upload size for IMS import file
7. Add configurable properties in sakai.properties
---------------------------------
1. Melete Source

Melete is a lesson builder tool for Sakai. All the source code for the release is included in the .tar.gz and .zip files. To work with Melete source, you need same development environment as Sakai, essentially Java 1.4 and Maven 1.0.2.

Unzip the melete source code zip file and place the melete source under Sakai 2.2.x or 2.3.
	
2. Configuring Melete 2.3 

2.1 Important Settings

    The settings below need to be performed in the /melete-app/src/webapp/WEB-INF/web.xml file.
        
	2.1.1 Homedir settings
	
	Create a "home" directory for Melete in your filesystem. (Note: This is not to be confused with your typical user home dir). Make sure the owner and group of the new directory is the same as that of the tomcat instances.
	
	Specify the absolute path to this Melete home directory in web.xml. 
	
	Eg. If you are on unix/linux, if your Melete home directory is /var, specify this in the following manner in web.xml

               <!-- Settings for Melete home directory -->
               <context-param>
			<param-name>homeDir</param-name>
			<param-value>/var</param-value>
		</context-param>	
        
	2.1.2 Meletedocs settings
        
	Melete stores the content it creates under a certain directory. Create and designate a directory in your filesystem as this directory. Make sure the owner and group of the new directory is the same as that of the tomcat instances.
        
	Specify the absolute path to this directory in the meleteDocsDir parameter of web.xml in Melete.
        
	Eg. If you are on unix/linux, if the directory you designate is /var/meleteDocs, specify this in the following manner in web.xml.
           
                <!-- Settings for meleteDocs directory -->
                <context-param>
				 <param-name>meleteDocsDir</param-name>
				 <param-value>/var/meleteDocs</param-value>
		</context-param>
	
	If you are on windows, if the directory you designate is c:\meleteDocs, specify this in the following manner in web.xml
	   
	       <!-- Settings for meleteDocs directory -->
   	       <context-param>
				 <param-name>meleteDocsDir</param-name>
				 <param-value>C:\meleteDocs</param-value>
		</context-param>
		
	2.1.3 Packagingdir settings
	
	The dependency files for the export process are in the /melete/packagefiles directory in the melete source code. Copy the /melete directory and its contents into your Melete home directory. Ensure that this directory and its children have read and write permissions. Specify the absolute path to this directory in web.xml. 
	
	Eg. If you are on unix/linux, if your packaging directory is /var/melete/packagefiles, specify this in the following manner in web.xml
               
              <!-- Settings for packaging directory --> 
              <context-param>
		 <param-name>packagingdir</param-name>
		 <param-value>/var/melete/packagefiles</param-value>
	      </context-param>		
		
	2.1.4 Uploads settings
	
	Create a directory called 'uploads' under your Melete home directory. Make sure the owner and group of this directory is the same as that of the tomcat instances. Specify the absolute path to this directory in web.xml under the Orielly filter's settings.
	
	Eg. If you are on unix/linux, if your uploads directory is /var/uploads, specify this in the following manner in web.xml
	
               <!-- Settings for uploads directory -->
               <init-param>
	       	        <param-name>uploadDir</param-name>
	       		<param-value>/var/uploads</param-value>
		</init-param>
		
 
2.2 Settings under Tomcat Instance

	2.2.1 Copy meleteDocs.xml provided in the melete source code into tomcat/conf/Catalina/localhost. 
	
	meleteDocs.xml is a configuration file for providing the context path of lessons or modules generated through the use of the application, stored as physical files. 
	
	2.2.2 Revise the meleteDocs.xml to point to the location of the meleteDocs directory. 

	After having created the meleteDocs directory as per step 4.1.2 above, specify the 
	absolute path to this directory in the docBase section of meleteDocs.xml
	
	Eg. If you are on unix/linux, if your meleteDocs directory is /var/meleteDocs, specify this as docBase="/var/meleteDocs" in meleteDocs.xml
	
	If you are on windows, if your meleteDocs directory is c:/meleteDocs, specify this
	as docBase="c:/meleteDocs" in meleteDocs.xml
	
	Note the leading "c:" Without it, Tomcat looks in "c:/tomcat/webapps/var/meleteDocs",	which doesn't exist. 
		
3. Compile Melete

	On the command prompt, go to the melete source directory which you just placed under sakai and run maven commands just like you did for sakai.

	To build, run 'maven sakai:build' and then to deploy 'maven sakai:deploy'
	
	(for more instructions, see section titled 'Sakai Maven Goals' in the 
	"How we build Sakai Using Maven" document provided by Sakai lead developers)

3.1 How to compile and deploy the Melete version with the Sferyx Applet editor
	
	a. Purchase a license and binary source for Sferyx (http://www.sferyx.com)
	b. Download the Melete source for Sferyx.   
	c. Add the purchased applet jar file under /melete-app/src/webapp. 

	Compile melete using maven commands as described above. There is no other difference.

4. Database Configuration

	* Melete works with HSQLDB, Oracle or Mysql4.1 Database. The driver used is 
	the MySql Connector/J 3.1.12 (same as Sakai). It has been tested just on Mysql. 
	* Melete shares the same database as Sakai's and adds few tables to the database. 
	
	To setup the Melete tables: 
	
	a. You can either run sql scripts manually provided under
	/components/src/sql/mysql, OR
	
	b. When tomcat starts, hibernate will generate the melete tables 
	on its own by reading xml files.

5. Update Sakai Roles (under realms) to include Melete permissions

	(If you are simply upgrading Melete in your Sakai instance, no roles changes are needed)

	5.1 Log on as Sakai admin. Check appropriate Melete permissions under the roles in !site.template.course. 
	
	* Check melete.author for teacher, instructor, faculty types of roles (maintain).
	* Check melete.student for student types of custom roles that you have (access).
		
	5.2. If you have project sites and related roles in !site.template.project, appropriate permissions (melete.student or melete.author) need to be checked as defined above.
		
   CAUTION: 
	a. IF YOU FAIL TO CHECK THE MELETE.STUDENT AND MELETE.AUTHOR PERMISSIONS 
		FOR YOUR ROLES, MELETE WILL NOT WORK PROPERLY. 
	b. IF YOU ADD MELETE TO _EXISTING SITES_, USERS WILL NOT HAVE THE MELETE
		PERMISSIONS THAT YOU CHECKED. YOU WILL NEED TO USE !SITE.HELPER OR OTHER 
		SCRIPT TO PROPAGATE THE MELETE PERMISSION TO EXISTING SITES. 

6. MAX UPLOAD SIZE FOR IMS IMPORT FILE
By setting this sakai property, system administrators can set a different file upload limit for Melete IMS CP import than the upload max limit for content files. If this property is not set then melete assumes the max value as 50Mb.

content.upload.ceiling=50
		
**** NOTE: The following steps are relevant ONLY if you have more than 1 editors installed. ****
		
7. Add configurable properties in Sakai.properties

7.1 DEFAULT MELETE EDITOR 
This is done by specifying the following property. For example, if the default Melete editor is Sferyx,
	melete.wysiwyg.editor=Sferyx Editor
If this property is not set, the code uses the editor specified by the wysiwyg.editor property.

7.2 LIST OF AVAILABLE MELETE EDITORS 
The preference feature allows users to select the editor for Melete content authoring. List the editor choices for users in sakai.properties as specified below. For example, if the user has two choices, Sferyx and FCK Editor, the settings will be as follows:

melete.wysiwyg.editor.count=2
melete.wysiwyg.editor1=Sferyx Editor
melete.wysiwyg.editor2=FCK Editor

NOTE : Please make sure that the names have proper spaces as this is used to display the labels of the available editors on the Preferences page.

