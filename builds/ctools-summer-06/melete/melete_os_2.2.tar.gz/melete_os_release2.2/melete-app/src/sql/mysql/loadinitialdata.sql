INSERT INTO melete_cc_license VALUES 
(0,0,0,'http://creativecommons.org/licenses/publicdomain/','Public Domain Dedication'),
(1,0,0,'http://creativecommons.org/licenses/by-nc-nd/2.0/','Attribution-NonCommercial-NoDerivs'),
(1,0,1,'http://creativecommons.org/licenses/by-nc-sa/2.0/','Attribution-NonCommercial-ShareAlike'),
(1,0,2,'http://creativecommons.org/licenses/by-nc/2.0/','Attribution-NonCommercial'),
(1,1,0,'http://creativecommons.org/licenses/by-nd/2.0/','Attribution-NoDerivs'),
(1,1,1,'http://creativecommons.org/licenses/by-sa/2.0/','Attribution-ShareAlike'),
(1,1,2,'http://creativecommons.org/licenses/by/2.0/','Attribution');

INSERT INTO melete_module_license VALUES 
(0,'---Select---'),
(1,'Copyright of Author'),
(2,'Public Domain'),
(3,'Creative Commons License'),
(4,'Fair Use Exception');