/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-app/src/java/org/sakaiproject/tool/melete/ModBcPage.java,v 1.1 2006/06/05 19:57:24 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/

package org.sakaiproject.tool.melete;
import javax.faces.application.*;
import javax.faces.component.*;
import javax.faces.component.html.*;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.io.Serializable;
import javax.faces.event.ActionEvent;

import javax.faces.context.FacesContext;
import javax.faces.el.MethodBinding;

//import com.sun.faces.util.Util;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.sakaiproject.api.app.melete.*;
import org.sakaiproject.component.app.melete.*;
//import org.sakaiproject.jsf.ToolBean;

/**
 * @author Faculty
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Mallika - 3/30/05 - added null check in constructor
 * Mallika - 4/21/05 - added in code to put up link
 * Mallika - 4/22/05 - Added the association to display module label
 * Mallika - 5/23/03 - Added if moduledatebeans == null condition
 */
public class ModBcPage implements Serializable/*,ToolBean*/ {

	  /** identifier field */
      private int moduleId;
      private int showModuleId;
      public Module module;
      private List moduleDateBeans = null;
      private List moduleDatePrivBeans = null;
      Object[] lisArray = null;
      public HtmlDataTable table;
      public HtmlPanelGroup pgroup;
      public HtmlPanelGroup pgroupBot;
      private String role;

//    This needs to be set later using Utils.getBinding
	  String courseId;
	  String userId;
	  private ModuleService moduleService;
	  private CoursePrefsService coursePrefsService;
	  /** Dependency:  The logging service. */
	  protected Log logger = LogFactory.getLog(ModBcPage.class);


	  public ModBcPage(){
	  	//Module breadcrumbs are only generated in view mode

	  	FacesContext context = FacesContext.getCurrentInstance();
	  	Map sessionMap = context.getExternalContext().getSessionMap();
	  	userId = (String)sessionMap.get("userId");
	  	courseId = (String)sessionMap.get("courseId");
	  	role = (String)sessionMap.get("role");
	  }

	  /**
		 * @param logger The logger to set.
	  */
	  public void setLogger(Log logger) {
	    this.logger = logger;
	  }

     /**
	   * @return Returns the ModuleService.
	   */
	  public ModuleService getModuleService() {
		return moduleService;
	  }

	 /**
	  * @param moduleService The moduleService to set.
	  */
	  public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	  }
	  /**
		 * @return Returns the CoursePrefsService.
		 */
		public CoursePrefsService getCoursePrefsService() {
			return coursePrefsService;
		}
		/**
		 * @param CoursePrefsService The CoursePrefsService to set.
		 */
		public void setCoursePrefsService(CoursePrefsService coursePrefsService) {
			this.coursePrefsService = coursePrefsService;
		}
	  public int getModuleId() {
        return this.moduleId;
    }

    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }

	  public int getShowModuleId() {
	        return this.showModuleId;
	  }

	  public void setShowModuleId(int moduleId) {
	        this.showModuleId = moduleId;
	  }

    public Module getModule()
    {
    	try {

  	  	  this.module = (Module) getModuleService().getModule(this.moduleId);
  	  	}
  	  	catch (Exception e)
          {
  		  //e.printStackTrace();
  	  		logger.error(e.toString());
          }
  	  	return this.module;
    }

    public void setModule(Module module){
      this.module = module;
    }

    public List getModuleDateBeans() {
    	return moduleDateBeans;
    }
    public void setModuleDateBeans(List moduleDateBeans) {
    	this.moduleDateBeans = moduleDateBeans;
    }
    public List getModuleDatePrivBeans() {
		//logger.info("Get moduledateprivbeans being invoked in modbcpage");
	  	//setCurrentDate(Calendar.getInstance().getTime());
	  	//setCurrentTimestamp(new java.sql.Timestamp(Calendar.getInstance().getTimeInMillis()));
	  	/*try {
	  		moduleDatePrivBeans = listModulesBusiness.getListModulesBusiness().getModuleDatePrivBeans(userId, courseId);
	  	*/
		/*for (ListIterator i = moduleDatePrivBeans.listIterator(); i.hasNext(); ) {
		        ModuleDatePrivBean mdpbean = (ModuleDatePrivBean) i.next();
		        if (mdpbean.getModuleShdate().isHideFlag() == true)
		        {
		        	hideFlagSize = hideFlagSize + 1;
		        }
	  		}*/
	  	/*}catch (Exception e)
		{
	  		e.printStackTrace();
		}*/
	  	/*if ((moduleDatePrivBeans.size() == 0)||(moduleDatePrivBeans.size() == hideFlagSize))
	  	{
	  	  nomodsFlag = true;
	  	  FacesContext ctx = FacesContext.getCurrentInstance();
  		  addNoModulesMessage(ctx);
	  	}*/
	  	return moduleDatePrivBeans;
	  }

	  public void setModuleDatePrivBeans(List moduleDatePrivBeansList) {
	    moduleDatePrivBeans = moduleDatePrivBeansList;
	  }


    public HtmlPanelGroup getPgroup() {

  	  return null;
      }

      public void setPgroup(HtmlPanelGroup pgroup){
  	  try
  	  {

  	    FacesContext context = FacesContext.getCurrentInstance();

  	    List list = pgroup.getChildren();
  	    list.clear();

  	    HtmlOutputText out;
  	    Application app = context.getApplication();

  	    Class[] param;
  	    UIParameter modidParam = new UIParameter();
  	    out = new HtmlOutputText();
  	    HtmlCommandLink clink = new HtmlCommandLink();
  	    MethodBinding mbalistener;
  	    MethodBinding mbaction;
  	    Date currentDate = Calendar.getInstance().getTime();
  	    String mval = getCoursePrefsService().getModuleLabel(courseId);
		if (mval == null)
		{
			mval = "Module";
		}


        logger.info("Role is "+role);
  	    if (role.equals("INSTRUCTOR"))
  	    {
  	      moduleDateBeans = (List)getModuleDateBeans();
  	      if (moduleDateBeans == null)
  	      {
  	        try
			{
  	      	  moduleDateBeans = getModuleService().getModuleDateBeans(courseId);
			}
  	        catch (Exception e)
			{
  	        	logger.error(e.toString());
			}
  	      }
  	      //logger.info("moddatebeans in instructor is "+moduleDateBeans.size());
  	      Module mod = null;
  	      ModuleShdates mDate = null;
  	      CourseModule cmod = null;
  	      ModuleDateBean mdBean = null;
  	      int i = 0;
  	      if (moduleDateBeans.size() > 0)
  	      {
  	        //logger.info("Staring to add up link");

            MethodBinding up_mbaction = app.createMethodBinding("#{navPage.viewAction}", null);
            HtmlCommandLink up_clink = new HtmlCommandLink();
            up_clink.setId("uplink");
            up_clink.setAction(up_mbaction);

            HtmlOutputText up_out = new HtmlOutputText();
            up_out.setId("uptext");
            up_out.setValue("Up");
            up_clink.getChildren().add(up_out);
            list.add(up_clink);
            //logger.info("Added up link and before pipe");
            HtmlOutputText headerText = new HtmlOutputText();
            headerText.setTitle(" | ");
		    headerText.setValue(" | ");
		    list.add(headerText);


  	      }
  	      //logger.info("LIst size beg is "+list.size());
  	      for (ListIterator lisIt = moduleDateBeans.listIterator(); lisIt.hasNext(); )
  	      {

  	        mdBean = (ModuleDateBean) lisIt.next();
  	        mod = (Module) mdBean.getModule();
  	        mDate = (ModuleShdates) mdBean.getModuleShdate();
  	        cmod = (CourseModule) mdBean.getCmod();

  	        //Only display breadcrumbs for modules that can be navigated to
  	        if ((mDate.isHideFlag() == false) && (mDate.getEndDate().compareTo(currentDate) >= 0)  && (mDate.getStartDate().compareTo(currentDate) <= 0) )
  	        {
  	          out.setId("text"+i);
  	  	      out.setValue(mval+" "+cmod.getSeqNo());
  	          if (mod.getModuleId().intValue() == getShowModuleId())
  	  		  {
  	            list.add(out);

  	  		  }
  	          else
  	          {
  	            param = new Class[1];
  	            ActionEvent evt = new ActionEvent(clink);
  	            param[0] = evt.getClass();
  	            clink.setId("mod"+i);
  	            mbalistener = app.createMethodBinding("#{viewModulesPage.viewModule}", param);
	            mbaction = app.createMethodBinding("#{viewModulesPage.redirectToViewModule}", null);

  	            clink.setActionListener(mbalistener);
  	            clink.setAction(mbaction);

  	            modidParam.setName("modid");
  	            modidParam.setValue(mod.getModuleId());
  	            clink.getChildren().add(out);
  	            clink.getChildren().add(modidParam);

  	            list.add(clink);

  	          }

  		      HtmlOutputText headerText = new HtmlOutputText();
  		      headerText.setTitle(" | ");
  		      headerText.setValue(" | ");
  		      list.add(headerText);
  		    //logger.info("LIst size here is "+list.size());

  	        }//if condition for ishideflag ends here

  	        modidParam = new UIParameter();
  		    out = new HtmlOutputText();
  		    clink = new HtmlCommandLink();
  		    mdBean = null;
  		    mod = null;
  	        mDate = null;
  	        cmod = null;
  	      i++;
  		  }//End for loop
  	    }
  	    if (role.equals("STUDENT"))
  	    {
  	      moduleDatePrivBeans = (List)getModuleDatePrivBeans();
  	      ModuleDatePrivBean mdpBean = null;
  	      Module mod = null;
  	      ModuleShdates mDate = null;
  	      CourseModule cmod = null;
  	      ModuleStudentPrivs msPriv = null;


  	      int i = 0;
  	      if (moduleDatePrivBeans.size() > 0)
	      {
	        //logger.info("Staring to add up link");

          MethodBinding up_mbaction = app.createMethodBinding("#{navPage.viewAction}", null);
          HtmlCommandLink up_clink = new HtmlCommandLink();
          up_clink.setId("uplink");
          up_clink.setAction(up_mbaction);

          HtmlOutputText up_out = new HtmlOutputText();
          up_out.setId("uptext");
          up_out.setValue("Up");
          up_clink.getChildren().add(up_out);
          list.add(up_clink);
          //logger.info("Added up link and before pipe");
          HtmlOutputText headerText = new HtmlOutputText();
          headerText.setTitle(" | ");
		    headerText.setValue(" | ");
		    list.add(headerText);


	      }
  	      //Only non-hidden modules come up
  	      for (ListIterator lisIt = moduleDatePrivBeans.listIterator(); lisIt.hasNext(); )
	      {

  	        mdpBean = (ModuleDatePrivBean) lisIt.next();
	        mod = (Module) mdpBean.getModule();
	        mDate = (ModuleShdates) mdpBean.getModuleShdate();
	        cmod = (CourseModule) mdpBean.getCmod();
	        msPriv = (ModuleStudentPrivs) mdpBean.getModuleStudentPriv();

            if ((mDate.getEndDate().compareTo(currentDate) >= 0)  && (mDate.getStartDate().compareTo(currentDate) <= 0) )
            {
            	out.setId("text"+i);
      	        out.setValue(mval+" "+cmod.getSeqNo());
      	        if (mod.getModuleId().intValue() == getShowModuleId())
    		    {
    		  	  list.add(out);
				}
      	        else
      	        {
      	        	if (msPriv != null)
      		      	{
      		          if ((currentDate.compareTo(msPriv.getStartDate()) >= 0)&&(currentDate.compareTo(msPriv.getEndDate()) <= 0))
      		          {
      		            param = new Class[1];
      	  	            ActionEvent evt = new ActionEvent(clink);
      	  	            param[0] = evt.getClass();
      	  	            clink.setId("mod"+i);
      	  	            mbalistener = app.createMethodBinding("#{viewModulesPage.viewModule}", param);
      		            mbaction = app.createMethodBinding("#{viewModulesPage.redirectToViewModule}", null);

      	  	            clink.setActionListener(mbalistener);
      	  	            clink.setAction(mbaction);

      	  	            modidParam.setName("modid");
      	  	            modidParam.setValue(mod.getModuleId());
      	  	            clink.getChildren().add(out);
      	  	            clink.getChildren().add(modidParam);
      		      	    list.add(clink);
      		          }
      		          else
      		          {
      		      	    list.add(out);
      		          }
      		      	 }
      		      	 else
      		      	 {
      		      	   param = new Class[1];
  	  	               ActionEvent evt = new ActionEvent(clink);
  	  	               param[0] = evt.getClass();
  	  	               clink.setId("mod"+i);
  	  	               mbalistener = app.createMethodBinding("#{viewModulesPage.viewModule}", param);
  		               mbaction = app.createMethodBinding("#{viewModulesPage.redirectToViewModule}", null);

  	  	               clink.setActionListener(mbalistener);
  	  	               clink.setAction(mbaction);

  	  	               modidParam.setName("modid");
  	  	               modidParam.setValue(mod.getModuleId());
  	  	               clink.getChildren().add(out);
  	  	               clink.getChildren().add(modidParam);
      		      	 	list.add(clink);
      		      	 }
      	        }
      	      HtmlOutputText headerText = new HtmlOutputText();
  		      headerText.setTitle(" | ");
  		      headerText.setValue(" | ");
  		      list.add(headerText);
            }

  		    modidParam = new UIParameter();
  		    out = new HtmlOutputText();
  		    clink = new HtmlCommandLink();
  		    mdpBean = null;
  		    mod = null;
  	        mDate = null;
  	        cmod = null;
  	        msPriv = null;
  	      i++;

  		  }//For loop ends here
  	    }//If condition ends here
//  	  Check to see if last item added is symbol
  	      int listSize = list.size();
  	      //logger.info("LIst size end is "+listSize);
  	      Object obj = list.get(listSize - 1);
  	      if (obj instanceof javax.faces.component.html.HtmlOutputText)
  	      {
  	        if (((HtmlOutputText)obj).getValue().equals(" | "))
  	        {
  	      	list.remove(listSize - 1);
  	        }
  	      }
  	    pgroup.setStyleClass("center");
  	    lisArray = list.toArray();
  	 	this.pgroup = pgroup;
  	    //logger.info("List size in pgroup top is "+pgroup.getChildren().size());

  	 	//this.pgroupBot = pgroupBot;
  	}
  	catch(Exception e)
  	{
  		//e.printStackTrace();
  		logger.error(e.toString());
  	}

  }
      public HtmlPanelGroup getPgroupBot() {
  	  return null;
      }

      public void setPgroupBot(HtmlPanelGroup pgroupBot){
      	/*logger.info("Setting bot panel group");
        List listBot = pgroupBot.getChildren();
  	    listBot.clear();
  	    //logger.info("list size here is "+list.size());

 	    logger.info("lisarr size is "+lisArray.length);
 	    for (int i=0; i<lisArray.length; i++)
        {
 	    	Object obj = lisArray[i];
 	    	logger.info(obj.toString());
 	    	try
			{
 	    	  boolean res = listBot.add(obj);
 	    	  //logger.info("Result is "+res);
			}
 	    	catch (Exception e)
			{
 	    		logger.info(e.toString());
			}

        }
 	    logger.info("List bot size is "+listBot.size());
  	    pgroupBot.setStyleClass("center");
  	    this.pgroupBot = pgroupBot;
  	    logger.info("List bot size at end first is "+pgroupBot.getChildren().size());

  	    logger.info("List bot size at end is "+this.pgroupBot.getChildren().size());
  	      */
  	   /* for (ListIterator lisIt = list.listIterator(); lisIt.hasNext(); )
        {
  	    	Object obj = lisIt.next();
  	    	logger.info(obj.toString());
  	    	try
			{
  	    	  boolean res = listBot.add(obj);
  	    	  logger.info("Result is "+res);
			}
  	    	catch (Exception e)
			{
  	    		logger.info(e.toString());
			}
  	    	logger.info("Index val "+lisIt.nextIndex());
  	    	//listBot.addAll(list);
        }*/

      	String mval = getCoursePrefsService().getModuleLabel(courseId);
		if (mval == null)
		{
			mval = "Module";
		}
        try
	  	  {

             FacesContext context = FacesContext.getCurrentInstance();


	  	    List list = pgroupBot.getChildren();
	  	    list.clear();


	  	    HtmlOutputText out;
	  	    Application app = context.getApplication();

	  	    Class[] param;
	  	    UIParameter modidParam = new UIParameter();
	  	    out = new HtmlOutputText();
	  	    HtmlCommandLink clink = new HtmlCommandLink();
	  	    MethodBinding mbalistener;
	  	    MethodBinding mbaction;
	  	    Date currentDate = Calendar.getInstance().getTime();



	  	    if (role.equals("INSTRUCTOR"))
	  	    {
	  	      moduleDateBeans = (List)getModuleDateBeans();
	  	      //logger.info("moddatebeans in instructor is "+moduleDateBeans.size());
	  	      Module mod = null;
	  	      ModuleShdates mDate = null;
	  	      CourseModule cmod = null;
	  	      ModuleDateBean mdBean = null;
	  	      int i = 0;
	  	      if (moduleDateBeans.size() > 0)
	  	      {
	  	        //logger.info("Staring to add up link");

	            MethodBinding up_mbaction = app.createMethodBinding("#{navPage.viewAction}", null);
	            HtmlCommandLink up_clink = new HtmlCommandLink();
	            up_clink.setId("uplink");
	            up_clink.setAction(up_mbaction);

	            HtmlOutputText up_out = new HtmlOutputText();
	            up_out.setId("uptext");
	            up_out.setValue("Up");
	            up_clink.getChildren().add(up_out);
	            list.add(up_clink);
	            //logger.info("Added up link and before pipe");
	            HtmlOutputText headerText = new HtmlOutputText();
	            headerText.setTitle(" | ");
			    headerText.setValue(" | ");
			    list.add(headerText);


	  	      }
	  	      for (ListIterator lisIt = moduleDateBeans.listIterator(); lisIt.hasNext(); )
	  	      {

	  	        mdBean = (ModuleDateBean) lisIt.next();
	  	        mod = (Module) mdBean.getModule();
	  	        mDate = (ModuleShdates) mdBean.getModuleShdate();
	  	        cmod = (CourseModule) mdBean.getCmod();

	  	        //Only display breadcrumbs for modules that can be navigated to
	  	        if ((mDate.isHideFlag() == false) && (mDate.getEndDate().compareTo(currentDate) >= 0)  && (mDate.getStartDate().compareTo(currentDate) <= 0) )
	  	        {
	  	          out.setId("text"+i);
	  	  	      out.setValue(mval+" "+cmod.getSeqNo());
	  	          if (mod.getModuleId().intValue() == getShowModuleId())
	  	  		  {
	  	            list.add(out);
	  	  		  }
	  	          else
	  	          {
	  	            param = new Class[1];
	  	            ActionEvent evt = new ActionEvent(clink);
	  	            param[0] = evt.getClass();
	  	            clink.setId("mod"+i);
	  	            mbalistener = app.createMethodBinding("#{viewModulesPage.viewModule}", param);
		            mbaction = app.createMethodBinding("#{viewModulesPage.redirectToViewModule}", null);

	  	            clink.setActionListener(mbalistener);
	  	            clink.setAction(mbaction);

	  	            modidParam.setName("modid");
	  	            modidParam.setValue(mod.getModuleId());
	  	            clink.getChildren().add(out);
	  	            clink.getChildren().add(modidParam);
	  	            list.add(clink);
	  	          }

	  		      HtmlOutputText headerText = new HtmlOutputText();
	  		      headerText.setTitle(" | ");
	  		      headerText.setValue(" | ");
	  		      list.add(headerText);


	  	        }//if condition for ishideflag ends here

	  	        modidParam = new UIParameter();
	  		    out = new HtmlOutputText();
	  		    clink = new HtmlCommandLink();
	  		    mdBean = null;
	  		    mod = null;
	  	        mDate = null;
	  	        cmod = null;
	  	      i++;
	  		  }//End for loop
	  	    }
	  	    if (role.equals("STUDENT"))
	  	    {
	  	      moduleDatePrivBeans = (List)getModuleDatePrivBeans();
	  	      ModuleDatePrivBean mdpBean = null;
	  	      Module mod = null;
	  	      ModuleShdates mDate = null;
	  	      CourseModule cmod = null;
	  	      ModuleStudentPrivs msPriv = null;


	  	      int i = 0;
	  	      if (moduleDatePrivBeans.size() > 0)
	  	      {
	  	        //logger.info("Staring to add up link");

	            MethodBinding up_mbaction = app.createMethodBinding("#{navPage.viewAction}", null);
	            HtmlCommandLink up_clink = new HtmlCommandLink();
	            up_clink.setId("uplink");
	            up_clink.setAction(up_mbaction);

	            HtmlOutputText up_out = new HtmlOutputText();
	            up_out.setId("uptext");
	            up_out.setValue("Up");
	            up_clink.getChildren().add(up_out);
	            list.add(up_clink);
	            //logger.info("Added up link and before pipe");
	            HtmlOutputText headerText = new HtmlOutputText();
	            headerText.setTitle(" | ");
			    headerText.setValue(" | ");
			    list.add(headerText);


	  	      }
	  	      //Only non-hidden modules come up
	  	      for (ListIterator lisIt = moduleDatePrivBeans.listIterator(); lisIt.hasNext(); )
		      {

	  	        mdpBean = (ModuleDatePrivBean) lisIt.next();
		        mod = (Module) mdpBean.getModule();
		        mDate = (ModuleShdates) mdpBean.getModuleShdate();
		        cmod = (CourseModule) mdpBean.getCmod();
		        msPriv = (ModuleStudentPrivs) mdpBean.getModuleStudentPriv();

	            if ((mDate.getEndDate().compareTo(currentDate) >= 0)  && (mDate.getStartDate().compareTo(currentDate) <= 0) )
	            {
	            	out.setId("text"+i);
	      	        out.setValue(mval+" "+cmod.getSeqNo());
	      	        if (mod.getModuleId().intValue() == getShowModuleId())
	    		    {
	    		  	  list.add(out);
	    		    }
	      	        else
	      	        {
	      	        	if (msPriv != null)
	      		      	{
	      		          if ((currentDate.compareTo(msPriv.getStartDate()) >= 0)&&(currentDate.compareTo(msPriv.getEndDate()) <= 0))
	      		          {
	      		            param = new Class[1];
	      	  	            ActionEvent evt = new ActionEvent(clink);
	      	  	            param[0] = evt.getClass();
	      	  	            clink.setId("mod"+i);
	      	  	            mbalistener = app.createMethodBinding("#{viewModulesPage.viewModule}", param);
	      		            mbaction = app.createMethodBinding("#{viewModulesPage.redirectToViewModule}", null);

	      	  	            clink.setActionListener(mbalistener);
	      	  	            clink.setAction(mbaction);

	      	  	            modidParam.setName("modid");
	      	  	            modidParam.setValue(mod.getModuleId());
	      	  	            clink.getChildren().add(out);
	      	  	            clink.getChildren().add(modidParam);
	      		      	    list.add(clink);
	      		          }
	      		          else
	      		          {
	      		      	    list.add(out);
	      		          }
	      		      	 }
	      		      	 else
	      		      	 {
	      		      	   param = new Class[1];
	  	  	               ActionEvent evt = new ActionEvent(clink);
	  	  	               param[0] = evt.getClass();
	  	  	               clink.setId("mod"+i);
	  	  	               mbalistener = app.createMethodBinding("#{viewModulesPage.viewModule}", param);
	  		               mbaction = app.createMethodBinding("#{viewModulesPage.redirectToViewModule}", null);

	  	  	               clink.setActionListener(mbalistener);
	  	  	               clink.setAction(mbaction);

	  	  	               modidParam.setName("modid");
	  	  	               modidParam.setValue(mod.getModuleId());
	  	  	               clink.getChildren().add(out);
	  	  	               clink.getChildren().add(modidParam);
	      		      	 	list.add(clink);
	      		      	 }
	      	        }
	      	      HtmlOutputText headerText = new HtmlOutputText();
	  		      headerText.setTitle(" | ");
	  		      headerText.setValue(" | ");
	  		      list.add(headerText);
	            }

	  		    modidParam = new UIParameter();
	  		    out = new HtmlOutputText();
	  		    clink = new HtmlCommandLink();
	  		    mdpBean = null;
	  		    mod = null;
	  	        mDate = null;
	  	        cmod = null;
	  	        msPriv = null;
	  	      i++;

	  		  }//For loop ends here
	  	    }//If condition ends here
//	  	  Check to see if last item added is symbol
	  	      int listSize = list.size();
	  	      //logger.info("LIst size is "+listSize);
	  	      Object obj = list.get(listSize - 1);
	  	      if (obj instanceof javax.faces.component.html.HtmlOutputText)
	  	      {
	  	        if (((HtmlOutputText)obj).getValue().equals(" | "))
	  	        {
	  	      	list.remove(listSize - 1);
	  	        }
	  	      }
	  	    pgroupBot.setStyleClass("center");
	  	 	this.pgroupBot = pgroupBot;
	  	}
	  	catch(Exception e)
	  	{
	  		//e.printStackTrace();
	  		logger.error(e.toString());
	  	}
      }


}
