/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-app/src/java/org/sakaiproject/tool/melete/ViewSectionsPage.java,v 1.1 2006/06/05 19:57:24 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.tool.melete;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.sakaiproject.api.app.melete.*;
import javax.faces.component.html.*;
import javax.faces.component.*;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;

import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.event.ActionEvent;

//import com.sun.faces.util.Util;
import org.sakaiproject.component.app.melete.*;
import org.sakaiproject.api.app.melete.CoursePrefsService;
import org.sakaiproject.api.app.melete.ModuleService;
import org.sakaiproject.api.app.melete.SectionService;
//import org.sakaiproject.jsf.ToolBean;
/**
 * @author Faculty
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
/*
 * 2 methods added by rashmi to fix bug#282 - 3/10/05
 * show link and uploaded file in the same window and same frame.
 * rashmi - 3/11/05 seperate redirect method for link and upload sections
 * mallika - 3/22/05 added emptystring field for view section instructions
 * mallika - 3/23/05 fixed performance issue bug being caused by license info
 * by checking to see if module is null before pulling from the database
 * mallika - 3/23/05 added if condition check for upload
 * mallika - 3/29/05 - removed the 10K limit on section content
 * mallika - 3/30/05 - added null check in constructor
 * Mallika - 4/22/05 - Added the association to display module label
 * Mallika - 5/23/05 - For better performance, changed the getCourseModule code
 * Mallika - 5/24/05 - Added setLicenseCode to viewsections
 * Mallika - 4/6/06 - Adding meleteDocsDir reference
 * Mallika - 4/25/06 - Changing meletedocs reference in getUploadFile code since not all paths have meleteDocs anymore
 */
public class ViewSectionsPage implements Serializable/*,ToolBean */{


	  /** identifier field */
      private int moduleId;
      private int moduleSeqNo;
      private int seqNo;
      private int licenseCode;

      public SectionObjService section;
      //private int secOffset;
      public ModuleObjService module;
      private List moduleDateBeans = null;
      private List sections = null;
      public String moduleTitle;
      private boolean instRole;
      public HtmlOutputText secContent;
      public HtmlCommandLink nextCmdLink;
      //private boolean nextLinkStatus;
      private String role;
      private String typeEditor;
      private String typeLink;
      private String typeUpload;
      public String httpUploadPath;
      private ModuleService moduleService;
      private SectionService sectionService;
      private CoursePrefsService coursePrefsService;
      /** Dependency:  The logging service. */
      protected Log logger = LogFactory.getLog(ViewSectionsPage.class);
      
      private String  nullString = null;
      private String emptyString = "";
      private String mval;

      public String getTypeEditor(){
	  	return "typeEditor";
	  }
	  public void setTypeEditor(String typeEditor){
	  	this.typeEditor = typeEditor;
	  }

	  public String getTypeLink(){
	  	return "typeLink";
	  }
	  public void setTypeLink(String typeLink){
	  	this.typeLink = typeLink;
	  }

	  public String getTypeUpload(){
	  	return "typeUpload";
	  }
	  public void setTypeUpload(String typeUpload){
	  	this.typeUpload = typeUpload;
	  }

	  public String getHttpUploadPath(){
	  	return httpUploadPath;
	  }

	  public void setHttpUploadPath(String uploadPath){
        if (uploadPath != null)
        {
	  	  this.httpUploadPath = uploadPath.substring(2,uploadPath.length());
        }
	  }
	  public String  getNullString() {
	  	return nullString;
	  }

	  public void setNullString(String  nullString) {
	  	this.nullString = nullString;
	  }
	  public String  getEmptyString() {
	  	return emptyString;
	  }

	  public void setEmptyString(String  emptyString) {
	  	this.emptyString = emptyString;
	  }

//    This needs to be set later using Utils.getBinding
	  String courseId;


	  public ViewSectionsPage(){

	  	FacesContext context = FacesContext.getCurrentInstance();
	  	Map sessionMap = context.getExternalContext().getSessionMap();
	  	courseId = (String)sessionMap.get("courseId");

		role = (String)sessionMap.get("role");

		if (role.equals("INSTRUCTOR"))
		{

			setInstRole(true);
		}
		else
		{

			setInstRole(false);
		}
	  }

	  /**
	   *  added by rashmi
		 * @return uploadfile name
		 *  get file name in reference to tomcat root
		 */
		public String getUploadFile()
		{
			String uploadFile ="";
			if(section!=null && section.getUploadPath()!=null)
			{
				String str=section.getUploadPath();
				//logger.info("in add section getupload file name" + str + str.indexOf("\\"));
				String uploadFile1 = null;
//                if(str.indexOf("\\") != -1)
//                {
//                        uploadFile1 = str.substring(str.indexOf("\\"));
//                }
//                else
//                {
//                        // for linux paths are /var/meleteDocs
//                        str= str.substring(str.indexOf("/")+1);
//                        uploadFile1 = str.substring(str.indexOf("/"));
//                }
                 //Mallika - 4/6/06 - commenting redundant lines below
                if(str.indexOf("\\") != -1)
                {
                        //uploadFile1 = str.substring(str.indexOf("\\"));
                	    //Mallika - commenting line below and changing it to course_
                        //uploadFile1 = str.substring(str.indexOf("\\meleteDocs"));
                        uploadFile1 = str.substring(str.indexOf("\\course_"));
                }
                else
                {
                        // for linux paths are /var/meleteDocs
                        str= str.substring(str.indexOf("/")+1);
                        //uploadFile1 = str.substring(str.indexOf("/"));
//                      Mallika - commenting line below and changing it to course_
                        //uploadFile1 = str.substring(str.indexOf("/meleteDocs"));
                        uploadFile1 = str.substring(str.indexOf("/course_"));
                }

                String uploadFileMel = "/meleteDocs";
                uploadFile1 = uploadFileMel.concat(uploadFile1);

                String patternStr = "\\\\";
		         String replacementStr = "/";

			  // Compile regular expression
		            Pattern pattern = Pattern.compile(patternStr);

		            // Replace all occurrences of pattern in input
		            Matcher matcher = pattern.matcher(uploadFile1);
		            uploadFile = matcher.replaceAll(replacementStr);

				//logger.info("in view section final upload file name" + uploadFile);
			}
			return uploadFile;
		}

	  /*
	   * Added by rashmi to fix bug#282 - 3/10/05
	   * show link and uploaded file in the same window and same frame.	   *
	   */
	  public String getContentLink()
	  {
	  	if(this.section.getContentType().equals("typeLink"))
		{
			return this.section.getLink();
		}
		else if(this.section.getContentType().equals("typeUpload"))
		{
			return getUploadFile();
		}
		else return "#";
	  }
  /**
	   * @return Returns the ModuleService.
	   */
	  public ModuleService getModuleService() {
		return moduleService;
	  }

	 /**
	  * @param moduleService The moduleService to set.
	  */
	  public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	  }

  /**
	   * @return Returns the SectionService.
	   */
	  public SectionService getSectionService() {
		return sectionService;
	  }

	 /**
	  * @param sectionService The sectionService to set.
	  */
	  public void setSectionService(SectionService sectionService) {
		this.sectionService = sectionService;
	  }
	  /**
		 * @return Returns the CoursePrefsService.
		 */
		public CoursePrefsService getCoursePrefsService() {
			return coursePrefsService;
		}
		/**
		 * @param CoursePrefsService The CoursePrefsService to set.
		 */
		public void setCoursePrefsService(CoursePrefsService coursePrefsService) {
			this.coursePrefsService = coursePrefsService;
		}
	  /**
		 * @param logger The logger to set.
	  */
	  public void setLogger(Log logger) {
			this.logger = logger;
	  }

	  public String getModuleTitle() {
        return this.moduleTitle;
    }

    public void setModuleTitle(String moduleTitle) {
        this.moduleTitle = moduleTitle;
    }
	  public int getModuleId() {
        return this.moduleId;
    }

    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }
    public int getSeqNo() {
        return this.seqNo;
    }

    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }
    public int getLicenseCode() {
        return this.licenseCode;
    }

    public void setLicenseCode(int licenseCode) {
        this.licenseCode = licenseCode;
    }

   /* public int getSecOffset() {
  	    //logger.info("GETTING show module id "+this.showModuleId);
        return this.secOffset;
    }

    public void setSecOffset(int secOffset) {
        this.secOffset = secOffset;
    }*/
    public int getModuleSeqNo() {
        return this.moduleSeqNo;
    }

    public void setModuleSeqNo(int moduleSeqNo) {
        this.moduleSeqNo = moduleSeqNo;
    }
    /*public void setNextLinkStatus(boolean status) {
    	this.nextLinkStatus = status;
    }
    public boolean getNextLinkStatus() {
    	return this.nextLinkStatus;
    }*/

    public boolean getInstRole()
    {
    	return instRole;
    }

    public void setInstRole(boolean instRole)
    {
    	this.instRole = instRole;
    }
    public void setMval(String mval)
	  {
			this.mval = mval;
	  }

	  public String getMval()
	  {
		  //logger.info("coming to getmval");
		  mval = getCoursePrefsService().getModuleLabel(courseId);
			if (mval == null)
			{
				mval = "Module ";
			}
			setMval(mval);
		  return mval;
	   }

    public ModuleObjService getModule()
    {
    	//logger.info("Coming to getModule in viewSectionsPage");

    	if (this.module == null)
    	{
    	try {
  	  	  //logger.info("Executing getmodule");
  	  	  this.module = (ModuleObjService) getModuleService().getModule(this.moduleId);

  	  	}
  	  	catch (Exception e)
          {
  		  //e.printStackTrace();
  	  		logger.error(e.toString());
          }
    	}
    	//logger.info("Module ID is "+this.module.getModuleId());
  	  	return this.module;
    }

    public void setModule(ModuleObjService module){
      this.module = module;
    }

    public SectionObjService getSection()
    {
    	if (this.section == null)
    	{
    	  try {
  	  	  //logger.info("Executing getsection in ViewSectionsPage "+this.moduleId+" seq "+this.seqNo);
  	  	  this.section = (SectionObjService) getSectionService().getSection(this.moduleId, this.seqNo);
  	  	 // rashmi - commented by rashmi
  	  	  //mallika - 3/23/05 added this if check
  	  	  if (this.section.getContentType().equals("typeUpload"))
  	  	  {
  	  	    setHttpUploadPath(this.section.getUploadPath());
  	  	   // getUploadFile();
  	  	    //logger.info("Uploadpath in ViewSectionsPage "+this.section.getUploadPath());
  	  	  }
  	  	  if (this.section.getInstr() != null)
  	  	  {
  	  	    //logger.info("Instruction for this section are "+this.section.getInstr()+" end");
  	  	  }
  	  	  }
  	  	  catch (Exception e)
          {
  		  //e.printStackTrace();
  	  	  	logger.error(e.toString());
          }
    	}
    	return this.section;
    }

    public void setSection(SectionObjService section){
      this.section = section;
    }
    public List getModuleDateBeans() {
    	//logger.info("getModuleDateBeans being invoked in ViewSectionsPage");
    	try {
	  		moduleDateBeans = getModuleService().getModuleDateBeans(courseId);
	  	}catch (Exception e)
		{
	  		//e.printStackTrace();
	  		logger.error(e.toString());
		}

	  	return moduleDateBeans;
    }
    public void setModuleDateBeans(List moduleDateBeans) {
    	this.moduleDateBeans = moduleDateBeans;
    }

    public HtmlOutputText getSecContent()
    {
    	//logger.info("Get secContent being invoked in ViewSectionsPage");

    	return null;
    }
    public void setSecContent(HtmlOutputText secContent)
    {
    	//logger.info("setSecContent being invoked in ViewSectionsPage");
    	SectionObjService curSec = getSection();

    	String contentPath = curSec.getContentPath();

    	StringBuffer sb = new StringBuffer();
    	//Till Vivie decides length of section
    	char[] conArray = new char[10000];

    	String record = null;
    	/*int offset = 0;
    	offset = getSecOffset();*/
    	if (contentPath != null)
    	{
    	/*try {
    		//logger.info("Before reading files "+offset);
    		logger.info("conarray size is "+conArray.length);
    		FileReader fr     = new FileReader(contentPath);
    	    BufferedReader br = new BufferedReader(fr);
    	    //if (offset > 0) br.skip(offset);
    	    int readstatus = br.read(conArray,0,9999);
    	    //if (readstatus == 499) setNextLinkStatus(true);
			//else setNextLinkStatus(false);
    	    logger.info("Read status is "+readstatus);
    	    record = new String(conArray);
    	    logger.info("record is "+record);
    	    br.close();
    	    fr.close();
    	  } catch (IOException e) {
    	     // catch possible io errors from readLine()
    	     logger.info("Uh oh, got an IOException error!");
    	     e.printStackTrace();
    	 }*/
    	  try {

            RandomAccessFile raFile = new RandomAccessFile(contentPath, "r");
            byte[] byteArray = new byte[(int)raFile.length()];
            raFile.read(byteArray);
            raFile.close();
            record = new String(byteArray);
    	  } catch (IOException e) {
    	     // catch possible io errors from readLine()
    	     logger.error(e.toString());
    	     //e.printStackTrace();
    	 }
    	secContent.setValue(record);
    	}

    	this.secContent = secContent;

    }

    public void viewModule(ActionEvent evt)
    {
    	//logger.info("View module being invoked in viewsectionspage");
    	FacesContext ctx = FacesContext.getCurrentInstance();
  	    UICommand cmdLink = (UICommand)evt.getComponent();
  	    List cList = cmdLink.getChildren();
  	    UIParameter param = new UIParameter();
  	    for (int i=0; i< cList.size(); i++)
  	    {
  		  Object obj = cList.get(i);
  		  if (obj instanceof UIParameter)
  		  {
  		    param = (UIParameter) cList.get(i);
  		  }
  	     }
  	    ValueBinding binding =
          Util.getBinding("#{viewModulesPage}");
       ViewModulesPage vmPage = (ViewModulesPage) binding.getValue(ctx);
       vmPage.setModuleId(((Integer)param.getValue()).intValue());
       vmPage.setModule(null);
       try {
  		ModuleService modServ = getModuleService();

  		CourseModule cMod = (CourseModule)modServ.getCourseModule(((Integer)param.getValue()).intValue(),courseId);
  		vmPage.setModuleSeqNo(cMod.getSeqNo());
	   }
	   catch (Exception e)
	   {
  		//e.printStackTrace();
  		logger.error(e.toString());
	   }

       binding =
        Util.getBinding("#{modBcPage}");
       ModBcPage mbcPage = (ModBcPage) binding.getValue(ctx);
       mbcPage.setShowModuleId(((Integer)param.getValue()).intValue());
  }

  public String redirectToViewModule(){
  	//logger.info("Redirecting to view module in viewsectionspage");
  	String retVal = "view_module_student";
    if (getInstRole() == true)
    {
    	retVal = "view_module";
    }
    if (getInstRole() == false)
    {
    	retVal = "view_module_student";
    }
  	return retVal;
  }
  public void viewSection(ActionEvent evt)
  {
  	int paramModid = 0;
  	int paramSeqno = 0;
  	//int paramSecoffset = 0;
  	//logger.info("View section being invoked in viewsectionspage");
  	FacesContext ctx = FacesContext.getCurrentInstance();
	    UICommand cmdLink = (UICommand)evt.getComponent();
	    List cList = cmdLink.getChildren();
	    UIParameter param = new UIParameter();
	    for (int i=0; i< cList.size(); i++)
	    {
		  Object obj = cList.get(i);
		  if (obj instanceof UIParameter)
		  {
		    param = (UIParameter) cList.get(i);

		    if (param.getName().equals("modid"))
		    {
		    	paramModid = ((Integer)param.getValue()).intValue();
		    }
		    if (param.getName().equals("seqno"))
		    {
		    	paramSeqno = ((Integer)param.getValue()).intValue();
		    }
		    /*if (param.getName().equals("secoffset"))
		    {
		    	paramSecoffset = ((Integer)param.getValue()).intValue();
		    }*/
		  }
	     }
	    ValueBinding binding =
        Util.getBinding("#{viewSectionsPage}");
     ViewSectionsPage vsPage = (ViewSectionsPage) binding.getValue(ctx);
     vsPage.setSection(null);
     vsPage.setModuleId(paramModid);
     vsPage.setSeqNo(paramSeqno);
     //vsPage.setSecOffset(paramSecoffset);
     ModuleObjService mod = (ModuleObjService) getModuleService().getModule(paramModid);
     vsPage.setModuleTitle(mod.getTitle());
     vsPage.setLicenseCode(mod.getLicenseCode());
     try {
  		ModuleService modServ = getModuleService();
  		CourseModule cMod = (CourseModule)modServ.getCourseModule(paramModid,courseId);
  		vsPage.setModuleSeqNo(cMod.getSeqNo());
	  }
	  catch (Exception e)
	  {
  		//e.printStackTrace();
  		logger.error(e.toString());
	  }

     binding =
        Util.getBinding("#{modBcPage}");
     ModBcPage mbcPage = (ModBcPage) binding.getValue(ctx);
     mbcPage.setShowModuleId(paramModid);
     binding =
        Util.getBinding("#{secBcPage}");
        SecBcPage sbcPage = (SecBcPage)
        binding.getValue(ctx);
        sbcPage.setModuleId(paramModid);
        sbcPage.setShowModuleId(paramModid);
        sbcPage.setShowSeqNo(paramSeqno);
        sbcPage.setEditMode(false);
        sbcPage.setShowTextOnly(false);
}

  /*
   * revised by rashmi 03/10 for links inframe thing
   * revised by rashmi 03/11 - back to original form
   */
public String redirectToViewSection(){
	//logger.info("Redirecting to view section in viewsectionspage"+getInstRole());
	String retVal = "view_section_student";
    if (getInstRole() == true)
    {
    	retVal = "view_section";
    }

    if (getInstRole() == false)
    {
    	retVal = "view_section_student";
    }

  	return retVal;
}
/*
 * rashmi - 3/11/05 seperate method for link and upload sections
 */
public String redirectToViewLinkSection(){
	//logger.info("RASHMI ___Redirecting to view section link in viewsectionspage"+getInstRole());
	String retVal = "view_section_student_link";
    if (getInstRole() == true)
    {
    	retVal = "view_section_link";
    }

    if (getInstRole() == false)
    {
    	retVal = "view_section_student_link";
    }

  	return retVal;
}

/*public HtmlCommandLink getNextCmdLink()
{
	logger.info("GetnextCmdLink being invoked in ViewSectionsPage");
	return null;
}
public void setNextCmdLink(HtmlCommandLink nextCmdLink)
{
	logger.info("setnextcmdlink being invoked in viewsectionspage");
	  Class[] param;
	      HtmlOutputText out = null;
	      MethodBinding mbalistener = null;
	      MethodBinding mbaction = null;
	      ActionEvent evt;
	      param = new Class[1];
      evt = new ActionEvent(nextCmdLink);
      param[0] = evt.getClass();
      logger.info("Before getting facescontext");
      FacesContext context = FacesContext.getCurrentInstance();
      Application app = context.getApplication();
      mbalistener = app.createMethodBinding("#{viewSectionsPage.viewSection}", param);
      mbaction = app.createMethodBinding("#{viewSectionsPage.redirectToViewSection}", null);
      nextCmdLink.setActionListener(mbalistener);
      nextCmdLink.setAction(mbaction);
      logger.info("Before setting params");
  	  UIParameter modidParam = new UIParameter();
      modidParam.setName("modid");
      modidParam.setValue(new Integer(this.moduleId));
      nextCmdLink.getChildren().add(modidParam);
      logger.info("Before setting seqparams");
      UIParameter seqnoParam = new UIParameter();
      seqnoParam.setName("seqno");
      seqnoParam.setValue(new Integer(this.seqNo));
      nextCmdLink.getChildren().add(seqnoParam);
      //logger.info("Before setting seCparams");
      //UIParameter secOffsetParam = new UIParameter();
      //secOffsetParam.setName("secoffset");
      //secOffsetParam.setValue(new Integer(this.secOffset + 499));
      //nextCmdLink.getChildren().add(secOffsetParam);
      logger.info("After adding params");
}*/
}
