/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-app/src/java/org/sakaiproject/tool/melete/ModulePage.java,v 1.1 2006/06/05 19:57:24 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.tool.melete;

import java.util.*;
import java.io.Serializable;

import javax.faces.context.FacesContext;
import javax.faces.application.FacesMessage;
import javax.faces.el.ValueBinding;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;

import javax.faces.component.*;
import javax.faces.event.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.sakaiproject.component.app.melete.Module;
import org.sakaiproject.component.app.melete.ModuleShdates;
import org.sakaiproject.component.app.melete.CourseModule;
import org.sakaiproject.component.app.melete.ModuleDateBean;
import org.sakaiproject.api.app.melete.*;

/**
 * @author Rashmi
 *
 * Add Module Page is the backing bean for the page add_module.jsp.
 * It also connects to other jsp pages like cclicenseform.jsp and
 * publicdomainform.jsp and license_results.jsp
 *
 * rashmi - 3/21 to make season and yr readable
 * revised by rashmi to get author name from sessionMap
 * revised by murthy to get currYear if its 0
 * revised by rashmi to remove dupl error messages for select a license
 * revised by rashmi on 6/15/05 to make FairUserender boolean as protected
 * revised by rashmi on 6/20/05 to add I agree and add messages
 *  */

public abstract class ModulePage implements Serializable{

    protected ModuleObjService module;
    private ModuleShdatesService moduleShdates;
    protected ModuleDateBean mdBean;

    /** Dependency:  The logging service. */
    protected Log logger = LogFactory.getLog(ModulePage.class);
	protected ModuleService moduleService;

    // license form rendering
    private boolean saveFlag;
    private boolean licenseAgree;
    private boolean shouldRenderCC;
    private boolean shouldRenderPD;
    private boolean shouldRenderCopyright;
    protected boolean shouldRenderFairUse;
    private boolean success;
    //added by rashmi -- 11/24
    private boolean copyright;
    private boolean editPageFlag;
    // added by rashmi 4th license option
    private boolean fairuse;

    private ArrayList licenseTypes;
    private ArrayList showDates;

    private StringBuffer author;
    private int year;
    private int currYear;
    private String allowCmrcl;
    private String allowMod;
    private String reqAttr;
    private String season;
    private String agreeResult;
    private String agreeResultUrl;


    protected String licenseCodes;

    public final static String CC_License="Creative Commons License";
    public final static String PD="Public Domain";
    private String formName;
    protected int moduleNumber;

    public ModulePage(){}

    /*
     * Processing of license Forms. If user selects cc license from the select box
     * then show CC License Form. If user clicks on I agree button then set the
     * coresponding agreeresulturl and agreeresult values.
     *
     * revised - Rashmi - 11/22 to include copyright page
     * revised - Mallika - 3/3 to include code to remove save message
     * on Edit Module page
     * */

	public void hideLicense(ValueChangeEvent event)throws AbortProcessingException
	{

		//Added to remove the save message on top of the screen if user changes his
		//mind about license
		setSuccess(false);
		UIInput licenseSelect = (UIInput)event.getComponent();

		shouldRenderCC = licenseSelect.getValue().equals("3");
		shouldRenderPD = licenseSelect.getValue().equals("2");
		shouldRenderCopyright = licenseSelect.getValue().equals("1");
		shouldRenderFairUse = licenseSelect.getValue().equals("4");
		licenseAgree = false;



		if(licenseSelect.findComponent(getFormName()).findComponent("CCLicenseForm") != null)
                  licenseSelect.findComponent(getFormName()).findComponent("CCLicenseForm").setRendered(shouldRenderCC);

		if(licenseSelect.findComponent(getFormName()).findComponent("PublicDomainForm") != null)
			licenseSelect.findComponent(getFormName()).findComponent("PublicDomainForm").setRendered(shouldRenderPD);

		if(licenseSelect.findComponent(getFormName()).findComponent("CopyrightForm") != null)
			licenseSelect.findComponent(getFormName()).findComponent("CopyrightForm").setRendered(shouldRenderCopyright);

		if(licenseSelect.findComponent(getFormName()).findComponent("FairUseForm") != null)
			licenseSelect.findComponent(getFormName()).findComponent("FairUseForm").setRendered(shouldRenderFairUse);

		FacesContext ctx = FacesContext.getCurrentInstance();
		ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
				ctx.getViewRoot().getLocale());
		String successMsg = bundle.getString("Click_IAgree");
	   	FacesMessage msg =
	  		new FacesMessage("Info message",successMsg);
	  	msg.setSeverity(FacesMessage.SEVERITY_INFO);
	  	ctx.addMessage(null,msg);

	}

	/**
	 * @return License URL .
	 * when user selects CC License and agrees to the form, a corresponding
	 * license url is found for the user and will be displayed in license_results.jsp.
	 * for public domain values are 0 0 0 for req Attr, allow Cmrcl  and allow Mod
	 *
	 * revised - Rashmi - 11/22 to include copyright page
	 * Rashmi -- 11/24 to show results properly in edit module page
	 * Removed space after author name in copyright selection. bug 110 -- Rashmi 12/8
	 * revised -- Rashmi 3/24 to get curryear and to show institute in copyright option
	 * revised -- Rashmi -- 3/25 removed institute
	 */
	public String IAgree()
	{

	 String[] result = new String[2];
	 try{
	 if(moduleService == null)
	 	moduleService = getModuleService();

	 /* if(licenseCodes.equals("Creative Commons License"))*/
	 if(licenseCodes.equals("3"))
	 	{

	 		result = getModuleService().getCCLicenseURL(new Boolean("true").booleanValue(), new Boolean(allowCmrcl).booleanValue(), new Integer(allowMod).intValue());
	 		agreeResultUrl = result[0];
	 		agreeResult = "Creative Commons " + result[1];
//	 	 set module values
	 		if(module != null)
			{
	 			module.setCcLicenseUrl(agreeResultUrl);
			}
	 		copyright=false;
	 		fairuse = false;
	 	}
	 else if(licenseCodes.equals("2"))
		 {

	 	  	result = getModuleService().getCCLicenseURL(new Boolean("false").booleanValue(), new Boolean("false").booleanValue(), new Integer("0").intValue());
		 	agreeResultUrl = result[0];
	 		agreeResult = result[1];
	 		copyright=false;
	 		fairuse = false;
	// 	 set module values
	 		if(module != null)
	 		{
	 	        module.setAllowCmrcl(false);
	 			module.setAllowMod(0);
	 			module.setReqAttr(false);
	 			module.setCcLicenseUrl(agreeResultUrl);
	 		}
		 } else if(licenseCodes.equals("1"))
		 {
		 	if(currYear == 0)
		 	{
		 		getCurrYear();
		 	}
		 	agreeResultUrl="Copyright (c) " + author+", " + currYear;
		 	module.setCcLicenseUrl(agreeResultUrl);

		 	copyright=true;
		 	fairuse = false;
		 }else if(licenseCodes.equals("4"))
		 {
		 	agreeResultUrl="Copyrighted Material - subject to fair use exception";
		 	module.setCcLicenseUrl(agreeResultUrl);
		 	fairuse = true;
		 	copyright=true;
		 }
	 } catch(Exception ex) {logger.error(ex.toString());}

	 this.licenseAgree = true;
	 this.shouldRenderCC = false;
	 this.shouldRenderPD = false;
	 this.shouldRenderCopyright = false;
	 this.shouldRenderFairUse = false;

	 FacesContext ctx = FacesContext.getCurrentInstance();
		ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
				ctx.getViewRoot().getLocale());
		String successMsg = bundle.getString("Click_AddMsg");
	   	FacesMessage msg =
	  		new FacesMessage("Info message",successMsg);
	  	msg.setSeverity(FacesMessage.SEVERITY_INFO);
	  	ctx.addMessage(null,msg);

	 return "success";
	}

	  public String getAllowCmrcl(){
        allowCmrcl = String.valueOf(module.isAllowCmrcl());
		return allowCmrcl;
		}

	  /**
	 * @param allowCmrcl
	 */
	public void setAllowCmrcl(String allowCmrcl){
		module.setAllowCmrcl(new Boolean(allowCmrcl).booleanValue());
	  	this.allowCmrcl = allowCmrcl;
	   }

	 public String getAllowMod(){
       allowMod = String.valueOf(module.getAllowMod());
	   return allowMod;
		}

	  /**
	 * @param allowMod
	 */
	public void setAllowMod(String allowMod){
	  module.setAllowMod(new Integer(allowMod).intValue());
	  this.allowMod = allowMod;
	   }
    public String getReqAttr(){
	  	reqAttr = String.valueOf(module.isReqAttr());
		return reqAttr;
		}

	  /**
	 * @param reqAttr
	 */
	public void setReqAttr(String reqAttr){
		module.setReqAttr(new Boolean(reqAttr).booleanValue());
	  	this.reqAttr = reqAttr;
	   }


	/**
	 * @return
	 */
	public String getAgreeResultUrl()
	{
		return agreeResultUrl;
	}

	/**
	 * @param agreeResultUrl
	 */
	public void setAgreeResultUrl(String agreeResultUrl)
	{
		this.agreeResultUrl = agreeResultUrl;
	}

	/**
	 * @return
	 */
	public String getAgreeResult()
	{
		return agreeResult;
	}

	/**
	 * @param agreeResult
	 */
	public void setAgreeResult(String agreeResult)
	{
		this.agreeResult = agreeResult;
	}

	/**
	 * @return
	 */
	public boolean getLicenseAgree()
	{
		return licenseAgree;
	}

	/**
	 * @param agreeResult
	 */
	public void setLicenseAgree(boolean licenseAgree)
	{
		this.licenseAgree = licenseAgree;
	}

	public boolean getShouldRenderCC()
	{
		return this.shouldRenderCC;
	}

	public boolean getShouldRenderPD()
	{
		return this.shouldRenderPD;
	}

	public boolean getShouldRenderCopyright()
	{
		return this.shouldRenderCopyright;
	}

	public boolean getShouldRenderFairUse()
	{
		return this.shouldRenderFairUse;
	}

	/**
	 * @return
	 */
	public boolean getSuccess()
	{
		return success;
	}
	/*
	 * Rashmi --11/24 for showing copyright on edit module page
	 */
	public boolean getCopyright()
	{
		return copyright;
	}

	/*
	 * Rashmi --4/28 for showing fairuse results
	 */
	public boolean getFairuse()
	{
		return fairuse;
	}

	/**
	 * @param
	 */
	public void setSuccess(boolean success)
	{
		this.success = success;
	}



	public void setLicenseCodes(String licenseCodes)
	{
	this.licenseCodes = licenseCodes;
	module.setLicenseCode(new Integer(licenseCodes).intValue());
	}

    /**
     * @return arraylist of available license types for a module.
     * It calls business layer method to connect to db and get the
     * available values.
     *
     * It also sets the select box options for licenseCodes.
     */
    public ArrayList getLicenseTypes()
	{
	  if(moduleService == null)
	  	moduleService = getModuleService();

	  if(licenseTypes == null || licenseTypes.size() == 0)
		{
	      licenseTypes = new ArrayList();
	      ArrayList allLicenseTypes = new ArrayList();

	      allLicenseTypes = moduleService.getModuleLicenses();

	      // Adding available list to select box
	      if(allLicenseTypes == null || allLicenseTypes.size()==0)
	      {
	      	licenseTypes.add(new SelectItem("No license", "No license"));
	      	 return licenseTypes;
	      }

	      Iterator itr = allLicenseTypes.iterator();
    	  while (itr.hasNext()) {
    	  		ModuleLicenseService  license = (ModuleLicenseService ) itr.next();
    	  		String value = license.getCode().toString();
    	  		String label = license.getDescription();

    	  		licenseTypes.add(new SelectItem(value, label));
    		}

	    }
	   return licenseTypes;
	}

    /**
     * @return list of next 5 years.
     * This method calculates the next 5 yrs and populate the combo box of
     * year in add_module.jsp page.
     */
    public ArrayList getShowDates()
{
	if(showDates == null)
	{
		showDates = new ArrayList();
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("PST"));
        int yr = c.get(Calendar.YEAR);
        currYear = yr;

        for (int i=0; i < 5; i++) showDates.add(new SelectItem((new Integer(yr+i)).toString()));
	}
	return showDates;
}

    /**
     *
     * This is the most critical function. It actually submits the form and sends
     * module and moduleShdates instances to the db level for adding a new module.
     *
     * Config file will conatin the outcome values from this function to navigate to next page.
     *
     *  validations
	 * 1.if learning obj or desc is present
	 * 2. if license type is cc license or public domain then ensure that
	 *  user has agreed to the license, hence we need to check licenseAgree flag is true
	 *
     **/

    public abstract String save();


    /**
     * Gets the module. if module instance is not created , create here and set
     * the default values. set author name and institution from session.
     *
     * add_module.jsp elements bind to the attributes of this
     * instance.
     *
     * Revision - added learning objectives default value -- Rashmi 11/17
     * get first name , institute etc from session -- Rashmi 11/22
     *  set sucess, licenseCoders and agree to fix bug#19, #20 -- Rashmi 12/15
     */

    public ModuleObjService getModule() {
        if (null == module) {
    	//logger.info("!!!get module from controller is null so creating!!!");
	      module = new Module();

	      module.setReqAttr(true);

		// get user information from session
	      FacesContext context = FacesContext.getCurrentInstance();
	      Map sessionMap = context.getExternalContext().getSessionMap();
	      module.setCreatedByFname((String)sessionMap.get("firstName"));
	      module.setCreatedByLname((String)sessionMap.get("lastName"));
	      module.setInstitute((String)sessionMap.get("institute"));

	      success=false;
	      licenseAgree=false;
	      licenseCodes=null;
	 }
    return module;
  }

    /**
     *
     * consolidate author name by concatenating first name and last name.
     * revised by rashmi to get name from sessionMap
     */
  public String getAuthor()
  {
	if(author == null)
	{
		author = new StringBuffer();
	    FacesContext context = FacesContext.getCurrentInstance();
	    Map sessionMap = context.getExternalContext().getSessionMap();
		author.append((String)sessionMap.get("firstName") + " ");
		author.append((String)sessionMap.get("lastName"));
	}
	return author.toString();
  }
  /**
   *
   * not required as the fields are disabled.
   *
   */
  public void setAuthor(String author){ }

  /**
   *
   * return yr selected.
   * revised by rashmi - 3/21 to make season and yr readable
   */
  public String getYear(){
	String yr="";
	if(year != 0) {
	 yr=new Integer(year).toString();
	}
	else
	{
		try{
			FacesContext context = FacesContext.getCurrentInstance();
			ValueBinding binding = Util.getBinding("#{meleteSiteAndUserInfo}");
			MeleteSiteAndUserInfo ms = (MeleteSiteAndUserInfo)
            binding.getValue(context);

		/*String[] termInfo = ms.getTermSeasonYear();
		season = termInfo[0];
		year = new Integer(termInfo[1]).intValue();
		*/
		} catch(Exception e)
		{
			yr=" ";
			logger.error("error in getting yr ..prob becos of melete site and user");
		}
	}
	return yr;
	}

  public String getCurrYear(){
	String yr="";
	if(currYear != 0) {
	 yr=new Integer(currYear).toString();
	}else{
		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("PST"));
		currYear = c.get(Calendar.YEAR);
		 yr=new Integer(currYear).toString();
	}
	return yr;
	}
  /**
   *
   * set the year selected by user.
   *
   */
  public void setYear(String year)
	{
	this.year = (new Integer(year)).intValue();
      }

   /**
   *
   * default season is "select season"
   *
   */

  public String getSeason()
  {
	if(season == null)
	{
		try{

			FacesContext context = FacesContext.getCurrentInstance();
			ValueBinding binding = Util.getBinding("#{meleteSiteAndUserInfo}");
			MeleteSiteAndUserInfo ms = (MeleteSiteAndUserInfo)binding.getValue(context);
			season = ms.getCourseTerm();
			if(season == null )
				season = " ";

		}catch(Exception e)
		{
			season=" ";
			logger.error("sesaon is null prob some error in meleteSiteand user");
		}
	}
	return season;
  }

  /**
   *
   * set user's selection
   *
   */
  public void setSeason(String season){
	this.season = season;
 }
  /**
   *
   * set module
   * Revised by rashmi to show results in edit page 11/24
   */
  public void setModule(ModuleObjService module) {

    this.module = module;
    agreeResultUrl=module.getCcLicenseUrl();

    agreeResult="License";
    //Null condn added by Mallika because it was crashing
    if (agreeResultUrl != null)
    {
    	if(agreeResultUrl.startsWith("Copyright"))
    	{
    		copyright=true;
    	}
    	else {
    	 copyright=false;
    		}
    }
   setLicenseAgree(true);
  }

  /**
   *
   * create an instance of moduleshdates.
   * Revised to open a course for one year by default --Rashmi 12/6
    * Revised on 12/20 Rashmi to set start default time as 8:00 am and
   * end date time as 11:59 pm
   */

  public ModuleShdatesService getModuleShdates() {
    if (null == moduleShdates) {
     moduleShdates = new ModuleShdates();
	       GregorianCalendar cal = new GregorianCalendar();
	       cal.set(Calendar.HOUR,8);
	       cal.set(Calendar.MINUTE,0);
	       cal.set(Calendar.SECOND,0);
	       cal.set(Calendar.AM_PM,Calendar.AM);
	       moduleShdates.setStartDate(cal.getTime());
	       cal.add(Calendar.YEAR, 1);
	       cal.set(Calendar.HOUR,11);
	       cal.set(Calendar.MINUTE,59);
	       cal.set(Calendar.SECOND,0);
	       cal.set(Calendar.AM_PM,Calendar.PM);
	       moduleShdates.setEndDate(cal.getTime());
	         }
	    return moduleShdates;
	  }

  /**
   *
   * @return
   *
   */
  public void setModuleShdates(ModuleShdatesService moduleShdates) {
    this.moduleShdates = moduleShdates;
  }



public ModuleDateBean getModuleDateBean() {
  	return mdBean;
  }

  public void setModuleDateBean(ModuleDateBean mdBean){
  	this.mdBean = mdBean;
  }

  public String getFormName(){
	return formName;
	}

  /**
  * @param formName
  */
  public void setFormName(String formName){
  	this.formName = formName;
   }
 /*
   * to remove retained values
   * Rashmi -- 12/21
   */
  public void resetModuleValues()
  {
                saveFlag = false;
                licenseAgree = false;
                shouldRenderCC= false;
                shouldRenderPD= false;
                shouldRenderCopyright= false;
                success= false;
                copyright= false;
                 season=null;
                  agreeResult=null;
                  agreeResultUrl=null;
                  moduleNumber = 0;
                  editPageFlag = false;
  }

  public void resetModuleNumber()
	{
  	moduleNumber = 0;
  	editPageFlag = true;
  	}

  /*
	 * get tentative seq# assigned to module. bug fix #211
	 * Rashmi - 1/21
	 */
	public String getModuleNumber()
	{
		if(moduleNumber != 0 )
			return new Integer(moduleNumber).toString();


		CourseModule cm = (CourseModule) module.getCoursemodule();
		if(cm == null)
		{
			//logger.info("getcourseModules is null");
			return "0";
		}


			moduleNumber = cm.getSeqNo();

		return new Integer(moduleNumber).toString();
	}

	public void validateLicense(FacesContext context, UIComponent component, Object value)
	throws ValidatorException
	{
		String val_license = (String) value;
		val_license = val_license.trim();

		if (val_license.equals("0"))
		{
			ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
            		context.getViewRoot().getLocale());
			String errMsg = "";
	     	errMsg = bundle.getString("license_required");

	     //	context.addMessage ("licensecodes", new FacesMessage(errMsg));
	      throw new ValidatorException(new FacesMessage(errMsg));
		}
	}

	public String backToModules()
	{
		return "list_auth_modules";
	}

	/**
	 * @return naviagtion rule on click of cancel button
	 */
	public String cancel()
	{
		return "list_auth_modules";
	}
	/**
	 * @return Returns the ModuleService.
	 */
	public ModuleService getModuleService() {
		return moduleService;
	}
	/**
	 * @param ModuleService The ModuleService to set.
	 */
	public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	}

	public void setLogger(Log logger) {
		this.logger = logger;
	}	
 }
