/*
 * Created on Jan 25, 2005
 * compartaor class to sort date deactivated of restore modules
 * 
 */
package org.sakaiproject.tool.melete;
import java.util.Date;
import org.sakaiproject.component.app.melete.CourseModule;
/**
 * @author Rashmi
 * 
 */
public class MeleteDateComparator implements java.util.Comparator {

	public int compare(Object o1, Object o2) {
	    Date d1 = ((CourseModule)o1).getDateArchived();
	    Date d2 = ((CourseModule)o2).getDateArchived();
	    return d1.compareTo(d2);
	  }

}
