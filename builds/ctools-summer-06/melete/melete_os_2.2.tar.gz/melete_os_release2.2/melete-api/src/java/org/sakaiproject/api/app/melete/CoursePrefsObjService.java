/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-api/src/java/org/sakaiproject/api/app/melete/CoursePrefsObjService.java,v 1.1 2006/06/05 19:57:23 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.api.app.melete;

/**
 * Filename:
 * Description:
 * Author:
 * Date:
 * Copyright 2004, Foothill College
 */
public interface CoursePrefsObjService {
	public abstract String getCourseId();

	public abstract void setCourseId(String courseId);

//	public abstract CourseService getCourse();
//
//	public abstract void setCourse(CourseService course);



	public abstract String getModuleLabel();

	public abstract void setModuleLabel(String moduleLabel);



	public abstract String toString();
}