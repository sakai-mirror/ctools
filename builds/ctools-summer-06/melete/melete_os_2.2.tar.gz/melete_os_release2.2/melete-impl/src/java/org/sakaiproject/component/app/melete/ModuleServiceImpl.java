/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-impl/src/java/org/sakaiproject/component/app/melete/ModuleServiceImpl.java,v 1.1 2006/06/05 19:57:24 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/

package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;

import org.sakaiproject.api.app.melete.CourseModuleService;
import org.sakaiproject.api.app.melete.ModuleDateBeanService;
import org.sakaiproject.api.app.melete.ModuleObjService;
import org.sakaiproject.api.app.melete.ModuleService;
import org.sakaiproject.api.app.melete.ModuleShdatesService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.sakaiproject.api.app.melete.exception.MeleteException;
/**
 * @author Rashmi
 *
 * This is the class implementing ModuleService interface.
 */
/* Mallika - 3/22/05 - Added methods for moduledatebeanservice
 * Mallika - 3/28/05 - Catching MeleteException for multiple users in update\
 * Mallika - 4/18/05 - Added method to delete module
 * Rashmi 4/21-22 add methods for sort modules
 * Mallika - 5/23/05 - For better performance, added the getCourseModule code
 * Rashmi - 07/07/07 - removed season and yr from method signature of insert properties
 * Rashmi - 05/22/06 - migrate to hibernate 3 - change import package
 */
public class ModuleServiceImpl implements ModuleService,Serializable {
	/** Dependency:  The logging service. */
	private Log logger = LogFactory.getLog(ModuleServiceImpl.class);

	private ModuleDB moduledb;
	private List moduleDateBeans = null;
	private List moduleDatePrivBeans = null;
	private List modules = null;
	private Module module = null;
	private ModuleLicenseDB moduleLicenseDB;
	private ModuleDateBean mdBean = null;

	/*******************************************************************************
	* Init and Destroy
	*******************************************************************************/

	/**
	 * Final initialization, once all dependencies are set.
	 */
	public void init()
	{
		logger.debug(this +".init()");

		List ccLicenseList = moduleLicenseDB.getCcLicense();
		if (ccLicenseList != null && ccLicenseList.size() == 0){
			CcLicense ccLicense = new CcLicense(false, false, 0, "http://creativecommons.org/licenses/publicdomain/","Public Domain Dedication");
			moduleLicenseDB.createCcLicense(ccLicense);
			ccLicense = new CcLicense(true, false, 0, "http://creativecommons.org/licenses/by-nc-nd/2.0/","Attribution-NonCommercial-NoDerivs");
			moduleLicenseDB.createCcLicense(ccLicense);
			ccLicense = new CcLicense(true, false, 1, "http://creativecommons.org/licenses/by-nc-sa/2.0/","Attribution-NonCommercial-ShareAlike");
			moduleLicenseDB.createCcLicense(ccLicense);
			ccLicense = new CcLicense(true, false, 2, "http://creativecommons.org/licenses/by-nc/2.0/","Attribution-NonCommercial");
			moduleLicenseDB.createCcLicense(ccLicense);
			ccLicense = new CcLicense(true, true, 0, "http://creativecommons.org/licenses/by-nd/2.0/","Attribution-NoDerivs");
			moduleLicenseDB.createCcLicense(ccLicense);
			ccLicense = new CcLicense(true, true, 1, "http://creativecommons.org/licenses/by-sa/2.0/","Attribution-ShareAlike");
			moduleLicenseDB.createCcLicense(ccLicense);
			ccLicense = new CcLicense(true, true, 2, "http://creativecommons.org/licenses/by/2.0/","Attribution");
			moduleLicenseDB.createCcLicense(ccLicense);
		}

		List moduleLicenseList = moduleLicenseDB.getLicenseTypes();
		if (moduleLicenseList != null && moduleLicenseList.size() == 0){
			ModuleLicense moduleLicense= null;
			moduleLicense =  new ModuleLicense(new Integer(0), "---Select---");
			moduleLicenseDB.createModuleLicense(moduleLicense);
			moduleLicense =  new ModuleLicense(new Integer(1), "Copyright of Author");
			moduleLicenseDB.createModuleLicense(moduleLicense);
			moduleLicense =  new ModuleLicense(new Integer(2), "Public Domain");
			moduleLicenseDB.createModuleLicense(moduleLicense);
			moduleLicense =  new ModuleLicense(new Integer(3), "Creative Commons License");
			moduleLicenseDB.createModuleLicense(moduleLicense);
			moduleLicense =  new ModuleLicense(new Integer(4), "Fair Use Exception");
			moduleLicenseDB.createModuleLicense(moduleLicense);
		}



		logger.debug(this +".init() completed successfully");
	}

	/**
	 * Final cleanup.
	 */
	public void destroy()
	{
		logger.debug(this +".destroy()");
	}

	public ModuleServiceImpl(){

		if (moduledb== null) moduledb = getModuledb();

		}

	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Log logger) {
		this.logger = logger;
	}

	/*
	 * @see org.foothillglobalaccess.melete.ModuleService#insertProperties(org.foothillglobalaccess.melete.Module, org.foothillglobalaccess.melete.ModuleShdates, int, int)
	 * creates the course object and calls methods to actually insert a module.
	 */
	public void insertProperties(ModuleObjService module, ModuleShdatesService moduleshdates,String userId, String courseId)
	{
	  try{
	  // module object and moduleshdates are provided by ui pages

    // create course
//		Course course = new Course();
//		course.setCourseId(courseId);
//		logger.info("ModuleImpl: Insert Properties course Id" + courseId + course);

		Module module1 = (Module)module;
		ModuleShdates moduleshdates1 = (ModuleShdates)moduleshdates;

	// insert new module
		moduledb.addModule(module1, moduleshdates1, userId, courseId);
	   }catch(Exception ex)
		{
		   //
		}
	}

/*
 * @see org.foothillglobalaccess.melete.ModuleService#getModuleLicenses()
 * implements the abstract method and gets the available module licenses from db
 * like copyright, cc license, public domain etc
 */
public ArrayList getModuleLicenses()
	{
	 try{
	 	ArrayList licenses = new ArrayList();
	 	licenses = getModuleLicenseDB().getLicenseTypes();
	
		return licenses;
	}catch(Exception ex)
	{
	// need to work on it
	return null;
	}

	}

/**
 * @param allowCmrcl
 * @param allowMod
 * fetches the cc license url from database based on user selected values.
 * ReqAttr value is always true.
 * @return
 */
public String[] getCCLicenseURL(boolean reqAttr, boolean allowCmrcl, int allowMod)
{
	 try{
		 	 return moduledb.fetchCcLicenseURL(new Boolean(reqAttr),new Boolean(allowCmrcl), new Integer(allowMod));
	 }catch(Exception ex)
		{
		// need to work on it
		return null;
		}
}

// mallika page stuff
public List getModuleDateBeans(String courseId) {
  	logger.info("Coming to moduleServiceImpl: getModuleDateBeans");
  	if (moduledb == null) moduledb = ModuleDB.getModuleDB();

  	try {
  		moduleDateBeans = moduledb.getShownModulesAndDatesForInstructor(courseId);
  	}catch (HibernateException e)
	{
  		//e.printStackTrace();
  		logger.error(e.toString());
	}
  	return moduleDateBeans;
  }

  public void setModuleDateBeans(List moduleDateBeansList) {
    moduleDateBeans = moduleDateBeansList;
  }

 public ModuleDateBeanService getModuleDateBean(String courseId,  int moduleId) {
  	//logger.info("Coming to ModuleServiceImpl: getModuleDateBean");
  	if (moduledb == null) moduledb = ModuleDB.getModuleDB();

  	try {
  		mdBean = moduledb.getModuleDateBean(courseId,  moduleId);
  	}catch (HibernateException e)
	{
  		//e.printStackTrace();
  		logger.error(e.toString());
	}
  	return mdBean;
  }
  public void setModuleDateBean(ModuleDateBeanService mdBean) {
  	this.mdBean = (ModuleDateBean) mdBean;
  }

  public List getModules(String courseId) {
  	logger.info("Coming to ModuleServiceImpl: getModules");
  	try {
  		modules = moduledb.getModules(courseId);
  	}catch (HibernateException e)
	{
  		//e.printStackTrace();
  		logger.error(e.toString());
	}
  	return modules;
  }

  public void setModules(List modules) {
    this.modules = modules;
  }


  public List getModuleDatePrivBeans(String userId,String courseId) {
  //	logger.info("Coming to moduleServiceImpl: getModuleDatePrivBeans");
  	try {
  		moduleDatePrivBeans = moduledb.getModulesDatesPrivsForStudents(userId, courseId);
  	}catch (HibernateException e)
	{
  		//e.printStackTrace();
  		logger.error(e.toString());
	}
  	return moduleDatePrivBeans;
  }

  public void setModuleDatePrivBeans(List moduleDatePrivBeansList) {
    moduleDatePrivBeans = moduleDatePrivBeansList;
  }

  public void updateModuleDateBeans(List moduleDateBeans) throws Exception {
  	try {
  		moduledb.updateModuleDateBeans(moduleDateBeans);
  	}
  	catch (Exception e)
	{
  		//e.printStackTrace();
  		logger.error(e.toString());
  		throw e;
	}

 }

 public void archiveModule(Object mdBean) throws Exception {
  	try {
  		moduledb.archiveModule((ModuleDateBean)mdBean);
  	}
  	catch (Exception e)
	{
  		//e.printStackTrace();
  		logger.error(e.toString());
  		throw e;
	}

 }

  /*
   * @see org.foothillglobalaccess.melete.ModuleService#updateProperties(org.foothillglobalaccess.melete.ModuleDateBean)
   * updates the moduleDateBean object
   */
 public void updateProperties(Object mdbean)  throws MeleteException
  {
    try{
    	ModuleDateBean mdbean1 = (ModuleDateBean) mdbean;
      // update module
       moduledb.updateModuleDateBean(mdbean1);
     }
    catch(Exception ex)
	{
		logger.error("multiple user exception in module business");
	   throw new MeleteException("edit_module_multiple_users");
	}
  }

  public void deleteModule(Object mdbean, String dataPath)
  {
  	try
	{
  		moduledb.deleteModule((ModuleDateBean)mdbean, dataPath);
	}
  	catch (Exception ex)
	{

	}

  }

// end - mallika
/*
 * @see org.foothillglobalaccess.melete.ManageModuleService#getArchiveModules(int, int)
 */
public List getArchiveModules(String course_id)
{
	List archModules=null;
	try{
		 archModules = moduledb.getArchivedModules(course_id);
		}catch(Exception ex)
		{
			logger.error("ManageModulesBusiness --get Archive Modules failed");
		}
		return archModules;
}


public ModuleObjService getModule(int moduleId) {
  	//logger.info("Coming to viewModulesBusiness");
  	try {
  		module = moduledb.getModule(moduleId);
  	}catch (HibernateException e)
	{
  		//e.printStackTrace();
  		logger.error(e.toString());
	}
  	return module;
  }

public void setModule(ModuleObjService mod) {
  	module = (Module)mod;
  }


/*
 * @see org.foothillglobalaccess.melete.ManageModuleService#restoreModules(java.util.List, int, int)
 */
public void restoreModules(List modules) throws Exception
{

	try{
		 moduledb.restoreModules(modules);
		}catch(Exception ex)
		{
			logger.error("ManageModulesBusiness --restore Modules failed");
			ex.printStackTrace();
			throw new MeleteException(ex.toString());
		}
}


	public CourseModuleService getCourseModule(int moduleId,  String courseId)
	throws Exception{
      CourseModule cMod =null;
      try{
        cMod = moduledb.getCourseModule(moduleId,  courseId);
      }catch(Exception ex){
        logger.error("ManageModulesBusiness --get Archive Modules failed");
       }
     return cMod;
    }

	/*
	 *  @see org.sakaiproject.api.app.melete.ModuleService#getSortModules(java.lang.String, int)
	 */
	public List getSortModules(String course_id)
	{
		List sortModules=null;
		try{
			sortModules = moduledb.getSortModules(course_id);
			}catch(Exception ex)
			{
				logger.error("ManageModulesBusiness --get Sort Modules failed");
			}
			return sortModules;
	}

	/* (non-Javadoc)
	 * @see org.sakaiproject.api.app.melete.ModuleService#updateModuleSequence(java.util.List)
	 */
	public void updateModuleSequence(List newSeqList) throws MeleteException
	{
		try{
		moduledb.updateModuleSequence(newSeqList);
		}catch(Exception ex)
		{
			logger.error("ManageModulesBusiness --update Module seq failed");
			throw new MeleteException(ex.toString());
		}
	}
	/**
	 * @return Returns the moduleLicenseDB.
	 */
	public ModuleLicenseDB getModuleLicenseDB() {
		return moduleLicenseDB;
	}
	/**
	 * @param moduleLicenseDB The moduleLicenseDB to set.
	 */
	public void setModuleLicenseDB(ModuleLicenseDB moduleLicenseDB) {
		this.moduleLicenseDB = moduleLicenseDB;
	}
	/**
	 * @return Returns the moduledb.
	 */
	public ModuleDB getModuledb() {
		return moduledb;
	}
	/**
	 * @param moduledb The moduledb to set.
	 */
	public void setModuledb(ModuleDB moduledb) {
		this.moduledb = moduledb;
	}
}