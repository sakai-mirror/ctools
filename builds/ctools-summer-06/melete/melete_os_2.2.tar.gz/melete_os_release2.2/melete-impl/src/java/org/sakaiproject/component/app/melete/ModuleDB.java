/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-impl/src/java/org/sakaiproject/component/app/melete/ModuleDB.java,v 1.2 2006/06/06 21:54:36 mallikat Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/

package org.sakaiproject.component.app.melete;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.StaleObjectStateException;
import org.hibernate.Transaction;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.sakaiproject.api.app.melete.exception.MeleteException;
import org.hibernate.criterion.Restrictions;
/*
 * modified by rashmi - 3/8 to get archived modules sort by date.
 * Murthy 03/08/05 --  set modification date commented in addModule method
 * Mallika - 3/22/05 - Added methods for moduledatebeanservice
 * Mallika - 3/28/05 - Catching MeleteException in updateModuleDateBean
 * module listing for sort modules added by rashmi - 4/20
 * Rashmi 4/22 methods to get coursemodules list and save the new seq - sort modules
 * Mallika - 5/2/05 - added functionality to delete module directory
 * Mallika - 5/18/05 - added truncTitle to sectionBean
 * Rashmi - 6/9/05 - remove term from archive module
 * Rashmi - 6/14/05 - revised if condition in assign seq number
 * Rashmi - 07/07/07 - removed season and yr from method signature
 * Rashmi - 05/11/06 - add method to get creative commons license name
 * Rashmi - 05/12/06 - add method to get creative commons license url
 * Rashmi - 05/22/06 - change queries to hibernate 3
 * Mallika - 6/5/06 - Renaming directory upon deleting module instead of deleting it
 */

public class ModuleDB implements Serializable {
	private String ccLicenseURL;
	private String ccLicenseName;
	private int seqNumber;
	private HibernateUtil hibernateUtil;
	/** Dependency:  The logging service. */
	private Log logger = LogFactory.getLog(ModuleDB.class);

	/**
	 *
	 */
	public ModuleDB()
	{
		if(hibernateUtil == null)getHibernateUtil();
	}

	/**
	 *
	 * Description:
	 */
	public static ModuleDB getModuleDB()
	{
		return new ModuleDB();
	}
	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Log logger) {
		this.logger = logger;
	}
    // rashmi stuff
	/**
	 * called from backing bean addModulePage to get the license url and license name
	 * @param reqAttr
	 * @param allowCmrcl
	 * @param allowMod
	 * @return
	 */
	public String[] fetchCcLicenseURL(Boolean reqAttr, Boolean allowCmrcl, Integer allowMod)
	{
		String[] licenseInfo = new String[2];
		try{

		     Session session = getHibernateUtil().currentSession();
			 fetchCcLicenseURL(session ,reqAttr, allowCmrcl, allowMod);
	         licenseInfo[0]=ccLicenseURL;
		     licenseInfo[1]=ccLicenseName;
		     getHibernateUtil().closeSession();
		} catch(Exception ex)
		{
			//ex.printStackTrace();
			logger.error(ex.toString());
			}
		return licenseInfo;
	}

	/**
	 * intennal call to this function.
	 * @param session
	 * @param reqAttr
	 * @param allowCmrcl
	 * @param allowMod
	 */
	public void fetchCcLicenseURL(Session session , Boolean reqAttr, Boolean allowCmrcl, Integer allowMod)
	{
	  try
		{
	  	logger.info("values: "+ reqAttr.booleanValue() + allowCmrcl.booleanValue()+ allowMod.intValue());

		  CcLicense Cc = (CcLicense) session.createCriteria(CcLicense.class)
		  .add(Restrictions.sqlRestriction("req_attr=?", reqAttr, Hibernate.BOOLEAN) )
		  .add(Restrictions.sqlRestriction("allow_Cmrcl=?", allowCmrcl, Hibernate.BOOLEAN) )
		  .add(Restrictions.sqlRestriction("allow_Mod=?", allowMod, Hibernate.INTEGER) )
  	     .list().get(0);
		  ccLicenseURL =Cc.getUrl();
		  ccLicenseName = Cc.getName();

		  return;
	     }
	     catch (HibernateException he)
	     {
			 logger.error(he.toString());
	     }
	}

	// add by rashmi to fetch license name for export
	public String fetchCcLicenseName(String licenseUrl)
	{
		String licenseInfo=null;
		try{
			logger.info("Moduledb:fetchCcLicenseName");
		     Session session = getHibernateUtil().currentSession();
		     Query q=session.createQuery("select ccl.name from CcLicense ccl where ccl.url =:url");
			  q.setParameter("url",licenseUrl);
			  licenseInfo = (String)q.uniqueResult();
		     getHibernateUtil().closeSession();
		} catch(Exception ex)
		{
			//ex.printStackTrace();
			logger.error(ex.toString());
			}
		return licenseInfo;
	}
	
	// add by rashmi
	public String fetchCcLicenseUrl(String name)
	{
		String licenseInfo=null;
		try{
			logger.info("Moduledb:fetchCcLicenseUrl " + name);
		     Session session = getHibernateUtil().currentSession();
		     Query q=session.createQuery("select ccl1.url from CcLicense ccl1 where ccl1.name =:name");
			  q.setParameter("name",name);
			  licenseInfo = (String)q.uniqueResult();
		     getHibernateUtil().closeSession();
		} catch(Exception ex)
		{
			//ex.printStackTrace();
			logger.error(ex.toString());
			}
		return licenseInfo;
	}
	    /**
	   * assign sequence number to the new module.
	 * if no sequence number is found in course module table for given courseId
	 * assume that its a first module.
	 * @param session
	 * @param course
	 * @return
	 */
	private int assignSequenceNumber(Session session, String courseId)
	{
	 int maxSeq= 1;
	 try
		{
		   Query q=session.createQuery("select max(cm.seqNo) from CourseModule cm where cm.courseId =:courseId");
		   q.setParameter("courseId",courseId);
		   Integer maxsequence = (Integer)q.uniqueResult();


		   // if no sequence is found then its first module.
		  if(maxsequence == null || maxsequence.intValue() <= 0)
		  {
		    return maxSeq ;
 		  }
		 logger.info("assignSequence ni=umber:"+ maxsequence);
		 maxSeq = maxsequence.intValue()+1;

	     }
	     catch (HibernateException he)
	     {
			 logger.error(he.toString());
			 //he.printStackTrace();
	     }
	    return maxSeq ;

	}

	   /**
	 * Actually inserts a row with module information.
	 * adds a row in module , moduleshdates , course module.
	 * if a transaction fails , rollback the whole transaction.
	 *
	 * @param module
	 * @param moduleshowdates
	 * @param course
	 *
	 * Revised by rashmi on 1/21/05 -- to associate coursemodule with module
	 * Murthy 03/08/05 --  set modification date commented
	 * Rashmi - 07/07/07 - removed season and yr from method signature
	 */
	public void addModule(Module module, ModuleShdates moduleshowdates, String userId, String courseId)
	{
	logger.info("db level add module called");

	try{
	     Session session = hibernateUtil.currentSession();
           Transaction tx = null;

		try
		{
		  module.setCreationDate(new java.util.Date());
		  module.setUserId(userId);
		  //module.setModificationDate(new java.util.Date());

    		// assign sequence number
		  int seq = assignSequenceNumber(session, courseId);

		  moduleshowdates.setModule(module);

		  tx = session.beginTransaction();
             // save module

		 session.save(module);

		// save module show dates
		 session.save(moduleshowdates);

		//create instance of coursemodules
		 CourseModule coursemodule = new CourseModule();
		 coursemodule.setCourseId(courseId);


		 coursemodule.setModule(module);
  		 coursemodule.setSeqNo(seq);

		// save course module
 		 session.save(coursemodule);

		 CourseModule cms = (CourseModule)module.getCoursemodule();
		 if (cms == null)
		 {
		 	cms = coursemodule;
		 }
		 module.setCoursemodule(cms);

		 session.saveOrUpdate(module);

		  tx.commit();
		//logger.info("new added module id:" + module.getModuleId() + ","+module.getTitle());
		  return ;

	     }
	     catch (HibernateException he)
	     {
			if(tx !=null) tx.rollback();
			logger.error(he.toString());
			//he.printStackTrace();
			throw he;
	     }
		finally{
		hibernateUtil.closeSession();
		 }
	}catch(Exception ex){
   // Throw application specific error
		logger.error("error at module db level");
		//ex.printStackTrace();
	}
  }

   // end rashmi stuff
	public List getModulesDatesPrivsForStudents(String userId, String courseId) throws HibernateException {
		List moduleDatePrivBeansList = new ArrayList();
	 	List modList = null;
	 	ModuleDatePrivBean mdpBean = null;
	 	Module mod = null;
	 	CourseModule cmod = null;
	 	ModuleStudentPrivs msPriv = null;
	 	ModuleShdates mDate = null;
	 	List sectionList = null;
	 	List sectionBeanList = null;
	 	Date currentDate = Calendar.getInstance().getTime();
	 	try
		{
	      //logger.info("coming to moduledb:getModulesDatesPrivsForStudents ");
	      Session session = hibernateUtil.currentSession();
	      modList = getStudentModules(userId,courseId);
	      Iterator i = modList.iterator();
	      while (i.hasNext()) {
	      	mdpBean = new ModuleDatePrivBean();

	      	Object[] pair = (Object[]) i.next();
	        mod = (Module) pair[0];
	        mdpBean.setModuleId(mod.getModuleId().intValue());
	      	mdpBean.setModule((Module)mod);
	        mDate = (ModuleShdates) pair[1];
	        mdpBean.setModuleShdate(mDate);
	        cmod = (CourseModule) pair[2];
	        mdpBean.setCmod(cmod);
	        mdpBean.setTruncTitle(createTruncstr(mod.getTitle()));
		   	if (mod.getModulestudentprivs() != null)
	        {
	          if (mod.getModulestudentprivs().size() == 1)
		      {
		        for (Iterator l = mod.getModulestudentprivs().iterator(); l.hasNext(); )
		        {
		    	  mdpBean.setModuleStudentPriv((ModuleStudentPrivs) l.next());
		        }
		      }
	        }

		   	sectionList = mod.getSections();

		   	if (sectionList != null)
		   	{
		   		if (sectionList.size() > 0)
		   		{
		      	sectionBeanList = new ArrayList();
		      	for (ListIterator k = sectionList.listIterator(); k.hasNext(); ){
		      		Section sec = (Section)k.next();


		      		//if (mod.getModuleId().intValue() == 32769)
		      		//Null section in list being eliminated
					if (sec != null)
		      		{
		      			SectionBean secBean = new SectionBean(sec);
						secBean.setTruncTitle(createTruncstr(sec.getTitle()));
		      			sectionBeanList.add(secBean);
		      		}


		      	}
		      	mdpBean.setSectionBeans(sectionBeanList);
		   		}
		   	}
	       moduleDatePrivBeansList.add(mdpBean);

	      	mod = null;
	      	cmod = null;
	      	msPriv = null;
	      	mDate = null;

	      }

	    }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
	    }
	    finally
		{
	      try
		  {
	      	hibernateUtil.closeSession();
		  }
	      catch (HibernateException he)
		  {
			  logger.error(he.toString());
		  }
		}
	    return moduleDatePrivBeansList;
	}

	 public List getShownModulesAndDatesForInstructor(String courseId) throws HibernateException {
	 	List moduleDateBeansList = new ArrayList();
	 	List modList = null;
	 	ModuleDateBean mdBean = null;
	 	Module mod = null;
	 	ModuleShdates mDate = null;
	 	CourseModule cmod = null;
	    List sectionList = null;
	 	List sectionBeanList = null;
	 	try
		{
//	      logger.info("coming to moduledb:getShownModulesAndDatesForInstructor ");
	 	  Session session = hibernateUtil.currentSession();
	      modList = getModules(courseId);
	      Iterator i = modList.iterator();
	      while (i.hasNext()) {
	      	mdBean = new ModuleDateBean();
	      	Object[] pair = (Object[]) i.next();
	        mod = (Module) pair[0];
	        mdBean.setModuleId(mod.getModuleId().intValue());
		    mdBean.setModule((Module)mod);
	        mDate = (ModuleShdates) pair[1];
	        mdBean.setModuleShdate(mDate);
	        cmod = (CourseModule) pair[2];
	        mdBean.setCmod(cmod);
	        mdBean.setTruncTitle(createTruncstr(mod.getTitle()));
	        
		   	sectionList = mod.getSections();

		   	if (sectionList != null)
		   	{
		   		if (sectionList.size() > 0)
		   		{
		   		sectionBeanList = new ArrayList();
		      	for (ListIterator k = sectionList.listIterator(); k.hasNext(); ){
		      		Section sec = (Section)k.next();


		      		//if (mod.getModuleId().intValue() == 32769)
		      		//Null section in list being eliminated
					if (sec != null)
		      		{
						SectionBean secBean = new SectionBean(sec);
						secBean.setTruncTitle(createTruncstr(sec.getTitle()));
		      			sectionBeanList.add(secBean);
		      		}

		      	}
		      	
		      	mdBean.setSectionBeans(sectionBeanList);
		   		}
		   	}
		   
		    moduleDateBeansList.add(mdBean);

	      	mod = null;
	      	cmod = null;
	      	mDate = null;
  	        sectionList = null;
	      	sectionBeanList = null;

	      }
	      
	    }
	    catch (Exception he)
	    {
		  logger.error(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
			  }
		}
	    
	    return moduleDateBeansList;

	  }

	 public List getModules(String courseId) throws HibernateException {
	 	List modList = new ArrayList();
	 	List sectionsList = null;
	 	Module mod = null;
	 	Query sectionQuery = null;
	 	try
		{
	      Session session = hibernateUtil.currentSession();
	      
	      String queryString = "from Module module join module.moduleshdate mshdates join module.coursemodule cmods where cmods.courseId = :courseId  and cmods.archvFlag = 0 order by cmods.seqNo";
	      Query query = session.createQuery(queryString);
	      query.setParameter("courseId", courseId);

	      modList = query.list();
	      //logger.info("moduleList = " + modList);

	    }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
			  }
		}
	    return modList;
	  }
//
	 public ModuleDateBean getModuleDateBean(String courseId,  int moduleId) throws HibernateException {
	 	List modList = new ArrayList();
	 	List sectionList = null;
	 	List sectionBeanList = null;
	 	Module mod = null;
	 	ModuleShdates mDate = null;
	 	CourseModule cmod = null;
	 	Query sectionQuery = null;
	 	ModuleDateBean mdBean = null;
	 	try
		{
	      //logger.info("coming to moduledb: getModuledatebean");
	      Session session = hibernateUtil.currentSession();
	     
	      String queryString = "from Module module join module.moduleshdate mshdates join module.coursemodule cmods where module.moduleId = :moduleId and cmods.courseId = :courseId  and cmods.archvFlag = 0 order by cmods.seqNo";
	      Query query = session.createQuery(queryString);
	      query.setParameter("moduleId", new Integer(moduleId));
	      query.setParameter("courseId", courseId);
	      
	      modList = query.list();
	      Iterator i = modList.iterator();
	      while (i.hasNext()) {
	        mdBean = new ModuleDateBean();
	      	Object[] pair = (Object[]) i.next();
	        mod = (Module) pair[0];
	        mdBean.setModuleId(mod.getModuleId().intValue());
		    mdBean.setModule((Module)mod);
	        mDate = (ModuleShdates) pair[1];
	        mdBean.setModuleShdate(mDate);
	        cmod = (CourseModule) pair[2];
	        mdBean.setCmod(cmod);
	        mdBean.setTruncTitle(createTruncstr(mod.getTitle()));
		   	sectionList = mod.getSections();
		   	//logger.info("Section list size is "+sectionList.size());
		   	if (sectionList != null)
		   	{
		   		if (sectionList.size() > 0)
		   		{
		   		sectionBeanList = new ArrayList();
		      	for (ListIterator k = sectionList.listIterator(); k.hasNext(); ){
		      		Section sec = (Section)k.next();
		  
		      		//Null section in list being eliminated
					if (sec != null)
		      		{
		      		
						SectionBean secBean = new SectionBean(sec);
						secBean.setTruncTitle(createTruncstr(sec.getTitle()));
		      			sectionBeanList.add(secBean);
		      		}

		      	}
		      
		      	mdBean.setSectionBeans(sectionBeanList);
		   		}
	    
		   	}
	      }
		}
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
			  }
		}
	    return mdBean;
	  }

	 public List getStudentModules(String userId,String courseId) throws HibernateException {
	 	List modList = new ArrayList();
	 	List sectionsList = null;
	 	Module mod = null;
	 	Query sectionQuery = null;
	 	try
		{
	      logger.info("coming to moduledb: getStudentModules  courseId:"+courseId);
	      Session session = hibernateUtil.currentSession();

	      String queryString = "from Module module join module.moduleshdate mshdates join module.coursemodule cmods where mshdates.hideFlag = :hfval and cmods.courseId = :courseId and cmods.archvFlag = 0 order by cmods.seqNo";

	      Query query = session.createQuery(queryString);
	      query.setParameter("courseId",courseId);
	      query.setParameter("hfval", new Boolean(false));

	      modList = query.list();


	    }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
			  }
		}
	    return modList;
	  }

	 public ModuleStudentPrivs getModulePrivs(String userId, String courseId, int moduleId)
	 {
	 	ModuleStudentPrivs msPriv = null;
	 	try
		{
	      //logger.info("coming to moduledb: getModulePrivs moduleId:"+moduleId);
	      Session session = hibernateUtil.currentSession();

	        String queryString =  "select modulestudentpriv from ModuleStudentPrivs as modulestudentpriv where " +
    		"modulestudentpriv.student.studentId = :studentId and modulestudentpriv.courseId = :courseId and " +
    		"modulestudentpriv.module.moduleId = :moduleId and " +
			"(modulestudentpriv.deny = 'N' or modulestudentpriv.deny = '')";
          Query query =
	      session.createQuery(queryString);
          query.setParameter("studentId", userId);
          query.setParameter("courseId", courseId);
          query.setParameter("moduleId", new Integer(moduleId));
	      msPriv = (ModuleStudentPrivs) query.uniqueResult();

	    }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
			  }
		}
	    return msPriv;
	 }
	 public ModuleShdates getShownModuleDates(int moduleId) throws HibernateException
	 {
	  	ModuleShdates mDate = null;
	 	try
		{
	      //logger.info("coming to moduledb: getShownModuleDates moduleId:"+moduleId);
	      Session session = hibernateUtil.currentSession();

	       String queryString =  "select moduleshdate from ModuleShdates as moduleshdate where moduleshdate.module.moduleId = :moduleId";
	       mDate = (ModuleShdates)
		  session.createQuery(queryString).setParameter("moduleId", new Integer(moduleId)).uniqueResult();  

	    }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
			  }
		}
	    return mDate;
	 }
	 public CourseModule getCourseModule(int moduleId, String courseId) throws HibernateException
	 {
	  	CourseModule cmod = null;
	 	try
		{
	      //logger.info("coming to moduledb: getCourseModule moduleId:"+moduleId+" course id:"+courseId);
	      Session session = hibernateUtil.currentSession();
	      String queryString =  "select cmod from CourseModule as cmod where cmod.module.moduleId = :moduleId  and cmod.courseId = :courseId";
	      Query query =
		  session.createQuery(queryString);
	      query.setParameter("moduleId", new Integer(moduleId));
	      query.setParameter("courseId", courseId);
	      cmod = (CourseModule)query.uniqueResult();	      
	    }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
			  }
		}
	    return cmod;
	 }
	 public void updateModuleDateBeans(List moduleDateBeans) throws Exception {
	 	for (ListIterator i = moduleDateBeans.listIterator(); i.hasNext(); ) {
	        ModuleDateBean mdbean = (ModuleDateBean) i.next();
	        try
			{
	          if (mdbean.isDateFlag() == false)
	          {
	            updateModuleDateBean(mdbean);
	          }
			}
	        catch (Exception e)
			{
	        	//e.printStackTrace();
	        	logger.error(e.toString());
	        	throw e;
			}
	        //logger.info("secs is "+mdbean.getModule().getSections());
  		}
	 }
	 public void updateModuleDateBean(ModuleDateBean mdbean)throws Exception
	 {
	 	Transaction tx = null;
	 	try
		{
	      logger.info("coming to moduledb: updateModuleDateBean");

	      Session session = hibernateUtil.currentSession();

	      tx = session.beginTransaction();

	      //Update module properties
	      session.saveOrUpdate(mdbean.getModule());

//	    Getting the set of show hides dates associated with this module
	      ModuleShdates mshdates = (ModuleShdates) mdbean.getModule().getModuleshdate();
   
        	mshdates.setStartDate(mdbean.getModuleShdate().getStartDate());
        	mshdates.setEndDate(mdbean.getModuleShdate().getEndDate());
        	session.saveOrUpdate(mshdates);
        	tx.commit();

	      //session.flush();

	    }
	 	catch(StaleObjectStateException sose)
	     {
			if(tx !=null) tx.rollback();
			logger.error("stale object exception" + sose.toString());
			throw new MeleteException("edit_module_multiple_users");
	     }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
		  throw he;
	    }
	    catch (Exception e) {
	      if (tx!=null) tx.rollback();
	      logger.error(e.toString());
	      throw e;
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
				  throw he;
			  }
		}
	 }
	 public static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            if (children.length == 0)
            {
            	dir.delete();
            	return true;
            }
            else
            {
              for (int i=0; i<children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
              }
            }
        }

        // The directory is now empty so delete it
        return dir.delete();
    }
    public static boolean renameDir(File dir) {
		String del_fname = dir.getAbsolutePath().concat("_del");
		boolean success = dir.renameTo(new File(del_fname));
		return success;
    }

	 public void deleteModule(ModuleDateBean mdbean, String dataPath) throws Exception
	 {
	 	Transaction tx = null;
	 	try
		{
	      logger.info("coming to moduledb: deleteModule");
	      Session session = hibernateUtil.currentSession();

	      tx = session.beginTransaction();

	      //Delete module properties
	      //logger.info("Deleting module "+mdbean.getModule().getTitle());
	      //boolean delSuccess = deleteDir(new File(dataPath));
	      boolean delSuccess = renameDir(new File(dataPath));
	      logger.info("Dir delete success is "+delSuccess);

	      //Adding these lines to also delete corresponding coursemodule and moduleshdate entry
	      session.delete(mdbean.getModule().getCoursemodule());
	      session.delete(mdbean.getModule().getModuleshdate());

          session.delete(mdbean.getModule());

	      logger.info("successfully deleted module");
	      String queryString = "from CourseModule cmod where cmod.courseId = :courseId and cmod.seqNo > :seqno";
	      Query query = session.createQuery(queryString);
	      query.setParameter("courseId",mdbean.getCmod().getCourseId());
	      query.setParameter("seqno",new Integer(mdbean.getCmod().getSeqNo()));

	      Iterator itr = query.iterate();

	      CourseModule cmod = null;
	      while (itr.hasNext()) {
	      	cmod = (CourseModule) itr.next();
	      	cmod.setSeqNo(cmod.getSeqNo() - 1);
	      	session.saveOrUpdate(cmod);
	      }
	      tx.commit();
	      //logger.info("Completed updating sequence");
	    }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
		  throw he;
	    }
	    catch (Exception e) {
	      if (tx!=null) tx.rollback();
	      logger.error(e.toString());
	      throw e;
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
		      	logger.info("Closing session after delete");
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
				  throw he;
			  }
		}
	 }

	 public Module getModule(int moduleId) throws HibernateException {
	 	Module mod = null;
	 	try
		{
	 		//logger.info("Coming to moduledb: getModule");
	 		Session session = hibernateUtil.currentSession();
	 		String queryString = "select module from Module as module where module.moduleId = :moduleId";
	 		mod = (Module) session.createQuery(queryString).setParameter("moduleId", new Integer(moduleId)).uniqueResult();	
	    }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
			  }
		}
	    return mod;
	 }

	 public List getSections(int moduleId) throws HibernateException {
	 	List sectionsList = new ArrayList();
	 	Module mod = null;
	 	Query sectionQuery = null;
	 	try
		{
	      //logger.info("coming to moduledb: getSections");
	      Session session = hibernateUtil.currentSession();

	      String queryString = "select section from Section as section where section.moduleId = :moduleId order by section.seqNo";
	      sectionsList = session.createQuery(queryString).setParameter("moduleId", new Integer(moduleId)).list();      
	    // logger.info("coming to moduledb: getSections and section list size" + sectionsList.size());
	    }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
			  }
		}
	    return sectionsList;
	  }

	 public Section getSection(int moduleId, int seqNo) throws HibernateException {
	 	Section sec = null;
	 	try
		{
	 		
	 		Session session = hibernateUtil.currentSession();
	 		
	 		String queryString = "select section from Section as section where section.moduleId = :moduleId and section.seqNo = :seqNo";
	 		Query query=  session.createQuery(queryString);
	 		query.setParameter("moduleId", new Integer(moduleId));
	 		query.setParameter("seqNo", new Integer(seqNo));	 		
	 		sec = (Section)query.uniqueResult();
	 	//	logger.info("Coming to moduledb: getSection" + sec.getTitle());
	    }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
			  }
		}
	    return sec;
	 }

     public void archiveModule(ModuleDateBean mdbean) throws Exception {
     	Transaction tx = null;
	 	try
		{
	      logger.info("coming to moduledb: archiveModule");

	      Session session = hibernateUtil.currentSession();

	      tx = session.beginTransaction();
	      CourseModule cmod = (CourseModule) mdbean.getModule().getCoursemodule();
	      //logger.info("Module date set is "+mdset);
	      int modSeqNo = -1;

	      //logger.info("Found a match module is "+cmod.getModule().getModuleId());
	      cmod.setArchvFlag(true);
	      Date currentDate = Calendar.getInstance().getTime();
	      cmod.setDateArchived(currentDate);
	      session.saveOrUpdate(cmod);
	      modSeqNo = cmod.getSeqNo();
	      cmod.setSeqNo(-1);

	  //    logger.info("coming to moduledb: getcourseModules");
	       String queryString = "from CourseModule cmod where cmod.courseId = :courseId  and cmod.seqNo > :seqno";
	      Query query = session.createQuery(queryString);
	      query.setParameter("courseId",mdbean.getCmod().getCourseId());
	      query.setParameter("seqno",new Integer(modSeqNo));

	      Iterator itr = query.iterate();

	      cmod = null;
	      while (itr.hasNext()) {
	      	cmod = (CourseModule) itr.next();
	      	cmod.setSeqNo(cmod.getSeqNo() - 1);
	      	session.saveOrUpdate(cmod);
	      }

	      tx.commit();

	      //session.flush();

	    }
	    catch (HibernateException he)
	    {
		  logger.error(he.toString());
		  throw he;
	    }
	    catch (Exception e) {
	      if (tx!=null) tx.rollback();
	      logger.error(e.toString());
	      throw e;
	    }
	    finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
			  }
		      catch (HibernateException he)
			  {
				  logger.error(he.toString());
				  throw he;
			  }
		}

     }
/* MANAGE TAB FUNCTIONALITY RELATED TRANSCATIONS*/

	 /**
	  * author : rashmi
	  * created on: 11 Jan 2005
	 * @param courseId
	 * @return list of archived modules of the course
	 */
	public List getArchivedModules(String course_id)
	 {
		List archModules = new ArrayList();
		 try
			{
		 	   Session session = hibernateUtil.currentSession();
			   Query q=session.createQuery("select cm from CourseModule cm where cm.courseId =:course_id and cm.archvFlag=1 order by cm.dateArchived");
			   q.setParameter("course_id", course_id);

			   archModules = q.list();
			   //logger.info("archive modules list size" + archModules.size() );
		     }
		     catch (HibernateException he)
		     {
				 logger.error(he.toString());
		     }
		     finally
				{
			    	try
					  {
				      	hibernateUtil.closeSession();
					  }
				      catch (HibernateException he)
					  {
						  logger.error(he.toString());
					  }
				}
		    return archModules ;
	 }

	/**
	 * author : rashmi
     * created on: 11 Jan 2005
	 * @param restoreModules
	 * @throws MeleteException
	 *
	 * to restore a module, update course_module, assign it a seq and
	 * set module_shdates start date as restored date and end date as 1 yr from there
	 * revised on 3/24/05 by rashmi to fix bug#460
	 */
	public void restoreModules(List restoreModules) throws MeleteException
	{
		try{
		     Session session = hibernateUtil.currentSession();
		      Transaction tx = null;

		   try{
	   		//	1.for each element of list
		   		for(int i=0; i < restoreModules.size(); i++ )
		   		{
		   	//	2.set course module object archv_flag to false, archived_date to null,
		   			CourseModule coursemodule = (CourseModule)restoreModules.get(i);
		   			Query q=session.createQuery("select cm1 from CourseModule cm1 where cm1.module.moduleId =:moduleId");
					q.setParameter("moduleId", coursemodule.getModule().getModuleId());

					CourseModule coursemodule1 = (CourseModule)(q.uniqueResult());
		   			coursemodule1.setArchvFlag(false);
		   			coursemodule1.setDateArchived(null);

  			//  seq no as max+1
		   		   q=session.createQuery("select max(cm.seqNo) from CourseModule cm where cm.courseId =:courseId");
		 		   q.setParameter("courseId",coursemodule.getCourseId());

		    	  Integer maxsequence = (Integer)q.uniqueResult();
		    	  if(maxsequence.intValue() < 0)
		    	  {
		    	  	coursemodule1.setSeqNo(1);
		    	  }
		    	  else coursemodule1.setSeqNo(maxsequence.intValue()+1);

			// 3. fetch module_shdate object
	   			q=session.createQuery("select msh from ModuleShdates msh where msh.module.moduleId =:moduleId");
					q.setParameter("moduleId", coursemodule.getModule().getModuleId());

					ModuleShdates moduleShdate = (ModuleShdates)(q.uniqueResult());

				//	3a.set start date as restored_date and end_date as 1 yr more
					GregorianCalendar cal = new GregorianCalendar();
				       cal.set(Calendar.HOUR,8);
				       cal.set(Calendar.MINUTE,0);
				       cal.set(Calendar.SECOND,0);
				       cal.set(Calendar.AM_PM,Calendar.AM);
					moduleShdate.setStartDate(cal.getTime());
					   cal.add(Calendar.YEAR, 1);
				       cal.set(Calendar.HOUR,11);
				       cal.set(Calendar.MINUTE,59);
				       cal.set(Calendar.SECOND,0);
				       cal.set(Calendar.AM_PM,Calendar.PM);
					moduleShdate.setEndDate(cal.getTime());

   			//4a. begin transaction
		   			tx = session.beginTransaction();
		   	//4b		save all objects
		   	        //logger.info("Before save or update coursemodule");
		   			session.saveOrUpdate(coursemodule1);
		   		//logger.info("course module updated");
		   			session.saveOrUpdate(moduleShdate);
		   			//logger.info("module shdates updated");
			//4c.commit transaction
					tx.commit();
		   		}
		   		logger.info("restored success");
	   			return ;
		     }
		     catch (HibernateException he)
		     {
				if(tx !=null) tx.rollback();
				logger.error(he.toString());
				//he.printStackTrace();
				throw new MeleteException(he.toString());
		     }

		} catch (Exception e)
	     {
			 logger.error(e.toString());
			 throw new MeleteException(e.toString());
	     }
	     finally
			{
		    	try
				  {
			      	hibernateUtil.closeSession();
				  }
			      catch (HibernateException he)
				  {
					  logger.error(he.toString());
				  }
			}

	}



	/**
	 * @return Returns the hibernateUtil.
	 */
	public HibernateUtil getHibernateUtil() {
		return hibernateUtil;
	}
	/**
	 * @param hibernateUtil The hibernateUtil to set.
	 */
	public void setHibernateUtil(HibernateUtil hibernateUtil) {
		this.hibernateUtil = hibernateUtil;
	}

	public String createTruncstr(String modTitle)
	 {
	      String truncTitle = null;
	      if (modTitle.length() <= 30) return modTitle.trim();
	      if (modTitle.length() > 30)
	      {
	      	truncTitle = modTitle.substring(0,27);
	      	truncTitle = truncTitle.concat("...");
	      }
	      //logger.info("Newbcstr is "+truncTitle);
	      return truncTitle;
	    }

	/*
	 * module listing for sort modules
	 * added by rashmi - 4/20
	 */
	public List getSortModules(String course_id)
		 {
			List sortModules = new ArrayList();
			 try
				{
			 	   Session session = hibernateUtil.currentSession();
				   Query q=session.createQuery("select cm from CourseModule cm where cm.courseId =:course_id and cm.archvFlag=0 order by cm.seqNo");
				   q.setParameter("course_id", course_id);

				   sortModules = q.list();
				   //logger.info("sortModules  list size" + sortModules.size() );
			     }
			     catch (HibernateException he)
			     {
					 logger.error(he.toString());
			     }
			     finally
					{
				    	try
						  {
					      	hibernateUtil.closeSession();
						  }
					      catch (HibernateException he)
						  {
							  logger.error(he.toString());
						  }
					}
			    return sortModules ;
		 }
	/*
	 * added by rashmi
	 * to save the new sequence of modules
	 */
	public void updateModuleSequence(List newSeqList) throws MeleteException
	{
		try{
		     Session session = hibernateUtil.currentSession();
		      Transaction tx = null;

		   try{
	   		//	1.for each element of list
		   		for(int i=0; i < newSeqList.size(); i++ )
		   		{
		   	//	2.get coursemodule element and assign new seq
		   			CourseModule coursemodule = (CourseModule)newSeqList.get(i);
		   			coursemodule.setSeqNo(i+1);
   			//4a. begin transaction
		   			tx = session.beginTransaction();
		   	//4b		save all objects
		   			session.saveOrUpdate(coursemodule);
		   			//logger.info("course module updated");

			//4c.commit transaction
					tx.commit();
		   		}
		   		logger.info("newSeqList success");
	   			return ;
		     }
		     catch (HibernateException he)
		     {
				if(tx !=null) tx.rollback();
				logger.error(he.toString());
				//he.printStackTrace();
				throw new MeleteException(he.toString());
		     }

		} catch (Exception e)
	     {
			 logger.error(e.toString());
			 throw new MeleteException(e.toString());
	     }
	     finally
			{
		    	try
				  {
			      	hibernateUtil.closeSession();
				  }
			      catch (HibernateException he)
				  {
					  logger.error(he.toString());
				  }
			}

	}
}
