/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-impl/src/java/org/sakaiproject/component/app/melete/CourseDB.java,v 1.1 2006/06/05 19:57:24 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.util.*;
// import java.sql.*;

import org.hibernate.*;
import java.io.Serializable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
/**
 * @author Rashmi
 *
 * implements actual operations to the section table
 * and related tables
 *
 * Mallika - 4/22/05 - Added the association to display module label
 * Mallika - 5/12/05 - Commented all upload sizes code
 * Mallika - 5/19/05 - Changed code for module label so it is refreshed each time
 * Rashmi - 5/22/05 - changing queries to migrate to hibernate 3
 */

public class CourseDB implements Serializable{
	CoursePrefs coursePrefs;
	private HibernateUtil hibernateUtil;
	private Log logger = LogFactory.getLog(CourseDB.class);
	/**
	 * constructor
	 */
	public CourseDB(){}

	/**
	 * @param course_id
	 * if course is null then create an instance of course.
	 */
	private void getCourse(String course_id)
	{

		if(coursePrefs == null || !coursePrefs.getCourseId().equals(course_id))
		{
		try{
		     Session session = hibernateUtil.currentSession();
	      	try
			{

		  	String q=new String("Select c from CoursePrefs c where c.courseId='"+course_id+"'");
		  	List courses = session.createQuery(q).list();
            
		    coursePrefs = (CoursePrefs)courses.get(0);

		    logger.info("CourseDB: found Course "+ coursePrefs);

			}catch (HibernateException he)
		     {
				logger.error(he.toString());
		//		he.printStackTrace();
				throw he;
		     }
		   	finally{
				hibernateUtil.closeSession();
				 }
		}catch(Exception ex){
				// Throw application specific error
			}
		}
		return;
	}

	public String getModuleLabel(String course_id)
	{
	
		
		String moduleLabel = null;
		try{
		     Session session = hibernateUtil.currentSession();
	      	try
			{

		  	String q=new String("Select c from CoursePrefs c where c.courseId='"+course_id+"'");
		    coursePrefs = (CoursePrefs)session.createQuery(q).uniqueResult();
          
		    moduleLabel = coursePrefs.getModuleLabel();

			}catch (HibernateException he)
		     {
				logger.error(he.toString());
		//		he.printStackTrace();
				throw he;
		     }
		   	finally{
				hibernateUtil.closeSession();
				 }
		}catch(Exception ex){
				// Throw application specific error
			}		
	
		return moduleLabel;
	}
	public void setModuleLabel(String course_id, String modLabel)
	{
		boolean entryExists = false;
	
		getCourse(course_id);
		
		if (coursePrefs != null)
		{
		  coursePrefs.setModuleLabel(modLabel);
		}
		else
		{
			coursePrefs = new CoursePrefs();
			coursePrefs.setCourseId(course_id);
			//Defaulting upload size to 2 MB
			//coursePrefs.setUploadSize(2048);
			coursePrefs.setModuleLabel(modLabel);
			entryExists = true;
		}
	
		try{
		     Session session = hibernateUtil.currentSession();
		     Transaction tx = null;
	      	try
			{
	      	  tx = session.beginTransaction();
	      	  if (entryExists == true)
	      	  {
	      	    session.save(coursePrefs);
	      	  }
	      	  else
	      	  {
	      	  	session.update(coursePrefs);
	      	  }
	      	  
	      	  tx.commit();
			}catch (HibernateException he)
		     {
				if(tx !=null) tx.rollback();
				logger.error(he.toString());
			//	he.printStackTrace();
				throw he;
		     }
		   	finally{
				hibernateUtil.closeSession();
				 }
		}catch(Exception ex){
				// Throw application specific error
			}
	
	}

	/**
	 * @return Returns the hibernateUtil.
	 */
	public HibernateUtil getHibernateUtil() {
		return hibernateUtil;
	}
	/**
	 * @param hibernateUtil The hibernateUtil to set.
	 */
	public void setHibernateUtil(HibernateUtil hibernateUtil) {
		this.hibernateUtil = hibernateUtil;
	}
	
	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Log logger) {
		this.logger = logger;
	}
}