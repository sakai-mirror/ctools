/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-impl/src/java/org/sakaiproject/component/app/melete/CoursePrefsServiceImpl.java,v 1.1 2006/06/05 19:57:24 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/

package org.sakaiproject.component.app.melete;

import java.io.Serializable;

import org.sakaiproject.api.app.melete.CoursePrefsService;
/**
 * @author Rashmi
 *  Created on Feb 1, 2005
 */
public class CoursePrefsServiceImpl implements Serializable, CoursePrefsService{

	private CourseDB coursedb;
	public CoursePrefsServiceImpl()
	{
	}
	
	public void setModuleLabel(String course_id, String modLabel)
	{
		coursedb.setModuleLabel(course_id,modLabel);
	}
	public String getModuleLabel(String course_id)
	{

		String modLabel = coursedb.getModuleLabel(course_id);
		return modLabel;
	}
	/**
	 * @return Returns the coursedb.
	 */
	public CourseDB getCoursedb() {
		return coursedb;
	}
	/**
	 * @param coursedb The coursedb to set.
	 */
	public void setCoursedb(CourseDB coursedb) {
		this.coursedb = coursedb;
	}
}
