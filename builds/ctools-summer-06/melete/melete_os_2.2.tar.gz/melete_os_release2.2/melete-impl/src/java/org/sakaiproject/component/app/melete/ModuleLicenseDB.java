/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-impl/src/java/org/sakaiproject/component/app/melete/ModuleLicenseDB.java,v 1.1 2006/06/05 19:57:24 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
/*
 *  @author Rashmi
 * 05/22/06 - Rashmi - migrate to hibernate 3 
 */

public class ModuleLicenseDB implements Serializable{
	ArrayList licenseTypes;
	private HibernateUtil hibernateUtil;
	private Log logger = LogFactory.getLog(ModuleLicenseDB.class);
	
	public ModuleLicenseDB(){}
	public ArrayList getLicenseTypes()
	{
		List licenseTypes = new ArrayList(); 
	  	try
		{
		    Session session = getHibernateUtil().currentSession();
		    StringBuffer query = new StringBuffer();
		    query.append("from ModuleLicense");
		    licenseTypes = session.createQuery(query.toString()).list();
	        getHibernateUtil().closeSession();
	     }
	     catch (HibernateException he)
	     {
			 logger.error(he.toString());			
	     }
		
	     return (ArrayList)licenseTypes;
	}
	
	/**
	 * fetches ccLicense
	 * @return
	 */
	public List getCcLicense() {
		
		List ccLicenceList = new ArrayList();
		try {
			Session session = getHibernateUtil().currentSession();

			StringBuffer query = new StringBuffer();
			query.append("from CcLicense");
			ccLicenceList= session.createQuery(query.toString()).list();
			getHibernateUtil().closeSession();
		} catch (HibernateException he) {
			logger.error(this + he.toString());
		}

		return ccLicenceList;
	}
	

	
	/**
	 * creates CcLicense
	 * 
	 * @param ccLicense -
	 *            CcLicence
	 */
	public void createCcLicense(CcLicense ccLicense)
	{
		saveData(ccLicense);
	}
	
	
	/**
	 * creates ModuleLicense
	 * 
	 * @param moduleLicense -
	 *            ModuleLicense
	 */
	public void createModuleLicense(ModuleLicense moduleLicense)
	{
		saveData(moduleLicense);

	}
	
	
	/**
	 * @param obj
	 */
	private void saveData(Object obj) {
		Transaction tx = null;
		try
		{
		     Session session = hibernateUtil.currentSession();
	         
	         tx = session.beginTransaction();
	         session.save(obj);
	         tx.commit();
		}catch(HibernateException he)
		{
			try {
				if(tx !=null) 
					tx.rollback();
			} catch (HibernateException e) {
				logger.error(e.toString());
			}
			logger.error(he.toString());
		}finally
		{
			try {
				hibernateUtil.closeSession();
			} catch (HibernateException e) {
				logger.error(e.toString());
			}
		 }
	}
	/**
	 * @return Returns the hibernateUtil.
	 */
	public HibernateUtil getHibernateUtil() {
		return hibernateUtil;
	}
	/**
	 * @param hibernateUtil The hibernateUtil to set.
	 */
	public void setHibernateUtil(HibernateUtil hibernateUtil) {
		this.hibernateUtil = hibernateUtil;
	}
	
	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Log logger) {
		this.logger = logger;
	}
}