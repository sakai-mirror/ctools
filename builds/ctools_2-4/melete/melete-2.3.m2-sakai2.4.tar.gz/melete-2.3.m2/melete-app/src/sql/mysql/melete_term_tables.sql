-- MySQL dump 10.9
--
-- Host: localhost    Database: sakai2a5
-- ------------------------------------------------------
-- Server version	4.1.9

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE="NO_AUTO_VALUE_ON_ZERO" */;

--
-- Table structure for table `melete_module`
--

DROP TABLE IF EXISTS `melete_module`;
CREATE TABLE `melete_module` (
  `MODULE_ID` int(11) NOT NULL default '0',
  `VERSION` int(11) NOT NULL default '0',
  `TITLE` varchar(50) NOT NULL default '',
  `LEARN_OBJ` text,
  `DESCRIPTION` text,
  `KEYWORDS` varchar(250) NOT NULL default '',
  `CREATED_BY_FNAME` varchar(20) NOT NULL default '',
  `CREATED_BY_LNAME` varchar(30) NOT NULL default '',
  `USER_ID` varchar(99) NOT NULL default '',
  `MODIFIED_BY_FNAME` varchar(20) default NULL,
  `MODIFIED_BY_LNAME` varchar(30) default NULL,
  `INSTITUTE` varchar(50) default NULL,
  `LICENSE_CODE` int(11) default NULL,
  `CC_LICENSE_URL` varchar(55) default NULL,
  `REQ_ATTR` tinyint(1) default NULL,
  `ALLOW_CMRCL` tinyint(1) default NULL,
  `ALLOW_MOD` int(11) default NULL,
  `WHATS_NEXT` text,
  `CREATION_DATE` datetime NOT NULL default '0000-00-00 00:00:00',
  `MODIFICATION_DATE` datetime default NULL,
  PRIMARY KEY  (`MODULE_ID`),
  KEY `FK54E9B209EBF83B4B` (`LICENSE_CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `melete_module`
--


/*!40000 ALTER TABLE `melete_module` DISABLE KEYS */;

/*!40000 ALTER TABLE `melete_module` ENABLE KEYS */;

--
-- Table structure for table `melete_module_license`
--

DROP TABLE IF EXISTS `melete_module_license`;
CREATE TABLE `melete_module_license` (
  `CODE` int(11) NOT NULL default '0',
  `DESCRIPTION` varchar(25) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `melete_module_license`
--


/*!40000 ALTER TABLE `melete_module_license` DISABLE KEYS */;

/*!40000 ALTER TABLE `melete_module_license` ENABLE KEYS */;

--
-- Table structure for table `melete_module_shdates`
--

DROP TABLE IF EXISTS `melete_module_shdates`;
CREATE TABLE `melete_module_shdates` (
  `MODULE_ID` int(11) NOT NULL default '0',
  `VERSION` int(11) NOT NULL default '0',
  `HIDE_FLAG` tinyint(1) default NULL,
  `START_DATE` datetime default NULL,
  `END_DATE` datetime default NULL,
  PRIMARY KEY  (`MODULE_ID`),
  KEY `FK2EA2E51A4995ABCE` (`MODULE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `melete_module_shdates`
--


/*!40000 ALTER TABLE `melete_module_shdates` DISABLE KEYS */;

/*!40000 ALTER TABLE `melete_module_shdates` ENABLE KEYS */;

--
-- Table structure for table `melete_module_student_privs`
--

DROP TABLE IF EXISTS `melete_module_student_privs`;
CREATE TABLE `melete_module_student_privs` (
  `COURSE_ID` varchar(20) NOT NULL default '',
  `MODULE_ID` int(11) NOT NULL default '0',
  `STUDENT_ID` varchar(11) NOT NULL default '',
  `ALLOW_UNLIMITED` tinyint(1) default NULL,
  `DENY` tinyint(1) default NULL,
  `START_DATE` datetime default NULL,
  `END_DATE` datetime default NULL,
  PRIMARY KEY  (`COURSE_ID`,`MODULE_ID`,`STUDENT_ID`),
  KEY `FK702F80EA4995ABCE` (`MODULE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `melete_module_student_privs`
--


/*!40000 ALTER TABLE `melete_module_student_privs` DISABLE KEYS */;
LOCK TABLES `melete_module_student_privs` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `melete_module_student_privs` ENABLE KEYS */;

--
-- Table structure for table `melete_course_module`
--

DROP TABLE IF EXISTS `melete_course_module`;
CREATE TABLE `melete_course_module` (
  `MODULE_ID` int(11) NOT NULL default '0',
  `COURSE_ID` varchar(99) default NULL,
  `SEQ_NO` int(11) NOT NULL default '0',
  `ARCHV_FLAG` tinyint(1) default NULL,
  `DATE_ARCHIVED` datetime default NULL,
  PRIMARY KEY  (`MODULE_ID`),
  KEY `FK5FE498D34995ABCE` (`MODULE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `melete_course_module`
--


/*!40000 ALTER TABLE `melete_course_module` DISABLE KEYS */;

/*!40000 ALTER TABLE `melete_course_module` ENABLE KEYS */;

--
-- Table structure for table `melete_course_prefs`
--

DROP TABLE IF EXISTS `melete_course_prefs`;
CREATE TABLE `melete_course_prefs` (
  `COURSE_ID` varchar(99) NOT NULL default '',
  `MODULE_LABEL` varchar(15) default NULL,
  PRIMARY KEY  (`COURSE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `melete_course_prefs`
--


/*!40000 ALTER TABLE `melete_course_prefs` DISABLE KEYS */;

/*!40000 ALTER TABLE `melete_course_prefs` ENABLE KEYS */;

--
-- Table structure for table `melete_cc_license`
--

DROP TABLE IF EXISTS `melete_cc_license`;
CREATE TABLE `melete_cc_license` (
  `REQ_ATTR` tinyint(1) NOT NULL default '0',
  `ALLOW_CMRCL` tinyint(1) NOT NULL default '0',
  `ALLOW_MOD` int(11) NOT NULL default '0',
  `URL` varchar(100) NOT NULL default '',
  `NAME` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`REQ_ATTR`,`ALLOW_CMRCL`,`ALLOW_MOD`,`URL`,`NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `melete_cc_license`
--


/*!40000 ALTER TABLE `melete_cc_license` DISABLE KEYS */;

/*!40000 ALTER TABLE `melete_cc_license` ENABLE KEYS */;

--
-- Table structure for table `melete_section`
--

DROP TABLE IF EXISTS `melete_section`;
CREATE TABLE `melete_section` (
  `SECTION_ID` int(11) NOT NULL default '0',
  `VERSION` int(11) NOT NULL default '0',
  `MODULE_ID` int(11) default NULL,
  `SEQ_NO` int(11) default NULL,
  `TITLE` varchar(50) NOT NULL default '',
  `CREATED_BY_FNAME` varchar(20) NOT NULL default '',
  `CREATED_BY_LNAME` varchar(30) NOT NULL default '',
  `MODIFIED_BY_FNAME` varchar(20) default NULL,
  `MODIFIED_BY_LNAME` varchar(30) default NULL,
  `INSTR` varchar(250) default NULL,
  `CONTENT_TYPE` varchar(10) NOT NULL default '',
  `CONTENT_PATH` varchar(200) default NULL,
  `UPLOAD_PATH` varchar(200) default NULL,
  `LINK` varchar(200) default NULL,
  `AUDIO_CONTENT` tinyint(1) default NULL,
  `VIDEO_CONTENT` tinyint(1) default NULL,
  `TEXTUAL_CONTENT` tinyint(1) default NULL,
  `CREATION_DATE` datetime NOT NULL default '0000-00-00 00:00:00',
  `MODIFICATION_DATE` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`SECTION_ID`),
  KEY `FK7492E6E84995ABCE` (`MODULE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `melete_section`
--


/*!40000 ALTER TABLE `melete_section` DISABLE KEYS */;

/*!40000 ALTER TABLE `melete_section` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

