/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-app/src/java/org/sakaiproject/tool/melete/AddModulePage.java,v 1.4 2006/10/25 20:06:10 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.tool.melete;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
/**
 * @author Rashmi
 *
 * Add Module Page is the backing bean for the page add_module.jsp.
 * It also connects to other jsp pages like cclicenseform.jsp and
 * publicdomainform.jsp and license_results.jsp\
 * revised on 5/18 by rashmi to include license no 4 to be validated
 * revised by rashmi to make keywords as not reqd and default with title
 * revised by rashmi on 6/15/05 to make FairUse license as default
 * Rashmi - 07/07/07 - removed season and yr from method signature of insert properties
 * Mallika - 8/1/06 - Adding code to remove IAgree
 * Mallika - 10/18/06 - adding reference to checkUploadExists
 * Rashmi - 10/24/06 - clean up comments and change logger.info to debug
 *  */

public class AddModulePage extends ModulePage implements Serializable{


    public AddModulePage(){
       	this.module = null;
    	setModuleShdates(null);
    	setModuleDateBean(null);
    	setFormName("AddModuleForm");      	
    }


    /**
     * set default license code to --Select--.
     * and other default values of CC license as
     * allowCmrcl as false
     * allowMod as "Yes as long as others Share alike"
     */
	public String getLicenseCodes()
	{
       	if(licenseCodes == null)
			{
	  		licenseCodes = "4";
	  		shouldRenderFairUse=true;
	  		setAllowCmrcl("false");
	        setAllowMod("1");
			}
		return licenseCodes;
	}

	/*
	 * set module to null to fix #19 and #20
	 * Rashmi -12/15
	 * revised Rashmi -12/20 to remove start and end dates
	 */
	public void setModuleNull()
	{
		this.module = null;
		setModuleShdates(null);
		licenseCodes = null;
		resetModuleValues();
	}
    
	/*
	 * Caling I agree of base class
	 * 
	 */
	public String IAgreeAdd()
	{
		IAgree();
		return "add_module";
	}
    /*
     * saves the module into database.
     * Valiation 1- validates user inputs for learning objectives and description.
     * Validation 2- user has agreed to the license.
     *
     * Revision on 11/15: - add code to initiate breadcrumps in add section page
     * 11/22 Rashmi -- get course id from session
     * 12/1  Rashmi -- license agre error message for copyright
     * validation 3 -- start date check Rashmi --12/6
     * validation 1 removed as now there is juxt one field description  Rashmi --12/8
     * revised to add license 4 to check if it has ben agreed upon or not Rashmi - 5/18
     */

    public String save()
	{
    	IAgree();
        Date  d = new Date();
     	Date st = getModuleShdates().getStartDate();
    
        setSuccess(false);
        if(moduleService == null)
        	moduleService = getModuleService();

	     FacesContext context = FacesContext.getCurrentInstance();
     	 ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
                		context.getViewRoot().getLocale());

     	//validation
     	module.setTitle(module.getTitle().trim());
     	ModuleValidator mv = new ModuleValidator();
     	mv.isValidTitle(module.getTitle());

     	// validation no 3
       	Date end = getModuleShdates().getEndDate();
     
 //  validation to limit year to 4 digits
     	Calendar calstart = new GregorianCalendar();
     	calstart.setTime(st);
     	Calendar calend = new GregorianCalendar();
     	calend.setTime(end);

     	if(calstart.get(Calendar.YEAR) > 9999 || calstart.get(Calendar.YEAR) < new Integer(getCurrYear()).intValue() )
 	     {
 			String errMsg = "";
 			errMsg = bundle.getString("start_date_invalid");
 			context.addMessage ("startDate", new FacesMessage(errMsg));
 			return "add_module";
 	     }

    	if(calend.get(Calendar.YEAR) > 9999 || calend.get(Calendar.YEAR) < new Integer(getCurrYear()).intValue() )
    	{
 			String errMsg = "";
 			errMsg = bundle.getString("end_date_invalid");
 			context.addMessage ("endDate", new FacesMessage(errMsg));
 			return "add_module";
 	    }

//      validation no 4 b
     	if(end.compareTo(st) < 0)
     	{
     		String errMsg = "";
	     	errMsg = bundle.getString("end_date_before_start");
	     	context.addMessage (null, new FacesMessage(errMsg));
	     	return "add_module";
     	}

	  

	     if(getLicenseCodes().equals("0"))
	     	{
		     	String errMsg = "";
		     	errMsg = bundle.getString("license_required");
		     	context.addMessage (null, new FacesMessage(errMsg));
		     	return "add_module";
	     	}
	     	// get course info from sessionmap
	      Map sessionMap = context.getExternalContext().getSessionMap(); 
	      String courseId = (String)sessionMap.get("courseId");
	      String userId = (String)sessionMap.get("userId");

	     // actual insert
		try{
			if(module.getKeywords() != null)
			{
				module.setKeywords(module.getKeywords().trim());
			}
			if(module.getKeywords() == null || (module.getKeywords().length() == 0) )
				 	{
						module.setKeywords(module.getTitle());
					}
			
			moduleService.insertProperties(getModule(),getModuleShdates(),userId,courseId);
			// add module to session
			sessionMap.put("currModule",module);

	
		}catch(Exception ex)
		{
			//logger.error("mbusiness insert module failed:" + ex.toString());
			String errMsg = bundle.getString("add_module_fail");
	     	context.addMessage (null, new FacesMessage(errMsg));
			return "add_module";
		}
		setSuccess(true);
		return "confirm_addmodule";
	 }

    /*
     * Called by the jsp page to redirect to add module sections page.
     * Revision -- Rashmi 12/21 resetting section value and setting SecBcPage values
     */
    public String addContentSections()
    {
        //logger.info("addContentSections called");
        FacesContext context = FacesContext.getCurrentInstance();
        ValueBinding binding =Util.getBinding("#{addSectionPage}");
        AddSectionPage addPage = (AddSectionPage) binding.getValue(context);
        addPage.resetSectionValues();
        // need to uncomment 6/09
        binding =Util.getBinding("#{secBcPage}");
        SecBcPage sbcPage = (SecBcPage) binding.getValue(context);
        // revision here
        sbcPage.setModuleId(module.getModuleId().intValue());
        sbcPage.setShowModuleId(module.getModuleId().intValue());
        sbcPage.setShowTextOnly(true);

        //Mallika - 10/18/06 - adding reference to checkUploadExists
        checkUploadExists();
       return "addmodulesections";
    }
 }
