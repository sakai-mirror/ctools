
/*
 * Created on Oct 10, 2006  @author Rashmi
 *
 * Captures author preferences
 * 
 * modified by rashmi - 10/16/06 - pref editor cancel functionality
 * Rashmi - 10/16/06 - nav rules from pref_editor are now pref_editor. 
 * Needs to changed later back to author_preferences
 * Rashmi - 10/16/06 - read available editors from sakai.properties
 * Rashmi - 10/18/06 - default wysiwyg property - add more conditions to make it foolproof
 * Rashmi - 10/24/06 - pref_editor page is now author_pref page so later fro 3.0 change return stmts to pref_editor
 * Rashmi - 12/6/06 - add length check in defaultEditorChoice() to make sure melete default editor is not specified 
 */
package org.sakaiproject.tool.melete;

import java.util.ArrayList;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.sakaiproject.api.app.melete.MeleteAuthorPrefService;
import org.sakaiproject.component.cover.ServerConfigurationService;

public class AuthorPreferencePage {
  final static String SFERYX = "Sferyx Editor";
  final static String FCKEDITOR = "FCK Editor";
  private String editorChoice;
  private String userEditor;
  private ArrayList availableEditors;
  
  //rendering flags
  private boolean shouldRenderSferyx=false;
  private boolean shouldRenderFCK=false;
  private MeleteAuthorPrefService authorPref;
  /** Dependency:  The logging service. */
	protected Log logger = LogFactory.getLog(AuthorPreferencePage.class);
	
  public AuthorPreferencePage()
  {	  	
  }
  
  private void getEditorChoice()
  {
  		FacesContext context = FacesContext.getCurrentInstance();
  		Map sessionMap = context.getExternalContext().getSessionMap();
  		
  		editorChoice = getAuthorPref().getEditorChoice((String)sessionMap.get("userId"));
  		// if no choice is set then read default from sakai.properties
  		if(editorChoice == null)
  		{
  			editorChoice = getMeleteDefaultEditor();
  		}
  		if(editorChoice.equals(SFERYX))
  		{
  			shouldRenderSferyx = true;
  		  	shouldRenderFCK = false;
  		}
  		else if(editorChoice.equals(FCKEDITOR))  	
  		{
  			shouldRenderSferyx = false;
  		  	shouldRenderFCK = true;
  		 }
  	
  	return;
  	} 
  
  public String getMeleteDefaultEditor()
	{
		String defaultEditor = ServerConfigurationService.getString("melete.wysiwyg.editor", "");
		logger.debug("getMeleteDefaultEditor:"+defaultEditor+"...");
		
		if(defaultEditor == null || defaultEditor.length() == 0)
		{
			defaultEditor = ServerConfigurationService.getString("wysiwyg.editor", "");
			logger.debug("default editor ie from wysiwyg.editor is" + defaultEditor);
			if(defaultEditor.equalsIgnoreCase(FCKEDITOR) || defaultEditor.startsWith("FCK") || defaultEditor.startsWith("fck"))
				defaultEditor = FCKEDITOR;
		}
		
		return defaultEditor;
	}
  
  public ArrayList getAvailableEditors()
  {
  	if( availableEditors == null)
  	{
  		availableEditors = new ArrayList();
  		int count = ServerConfigurationService.getInt("melete.wysiwyg.editor.count", 0);
  		for(int i=1;i <=count; i++)
  			{
  			String label = ServerConfigurationService.getString("melete.wysiwyg.editor"+i, "");
  			if(label.equalsIgnoreCase(FCKEDITOR)) label = FCKEDITOR;
  			if(label.equalsIgnoreCase(SFERYX)) label = SFERYX;
  			availableEditors.add(new SelectItem(label, label));
  			}
  	}
  	return availableEditors;
  }
/**
 * @return Returns the shouldRenderFCK.
 */
public boolean isShouldRenderFCK() {
	getEditorChoice();	
	return shouldRenderFCK;
}
/**
 * @param shouldRenderFCK The shouldRenderFCK to set.
 */
public void setShouldRenderFCK(boolean shouldRenderFCK) {
		this.shouldRenderFCK = shouldRenderFCK;
}
/**
 * @return Returns the shouldRenderSferyx.
 */
public boolean isShouldRenderSferyx() {
	getEditorChoice();	
	return shouldRenderSferyx;
}
/**
 * @param shouldRenderSferyx The shouldRenderSferyx to set.
 */
public void setShouldRenderSferyx(boolean shouldRenderSferyx) {
	this.shouldRenderSferyx = shouldRenderSferyx;
}


// editor settings
public String goToEditorPreference()
{
	return "pref_editor";
}

/**
 * Default editor is Sferyx
 * @return Returns the userEditor.
 */
public String getUserEditor() {
	if(userEditor == null)
	{
		getEditorChoice();
		if (editorChoice == null)
			userEditor = SFERYX;
		else userEditor = editorChoice;
	}	
	return userEditor;
}
/**
 * @param userEditor The userEditor to set.
 */
public void setUserEditor(String userEditor) {
	this.userEditor = userEditor;
}

public String setEditorChoice()
{
	
	if(userEditor != null)
	{	
		FacesContext context = FacesContext.getCurrentInstance();
		Map sessionMap = context.getExternalContext().getSessionMap();
		ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
				context.getViewRoot().getLocale());
		try
		{
		authorPref.insertEditorChoice((String)sessionMap.get("userId"),userEditor);
		}
		catch(Exception e)
		{
			String errMsg = bundle.getString("Set_editor_fail");
			context.addMessage (null, new FacesMessage(FacesMessage.SEVERITY_ERROR,"Set_editor_fail",errMsg));
			return "author_preference";
		//	return "pref_editor";
		}
	
	String successMsg = bundle.getString("Set_editor_success");
	context.addMessage (null, new FacesMessage(FacesMessage.SEVERITY_INFO,"Set_editor_success",successMsg));
	}

	return "author_preference";
	//return "pref_editor";
}

public String backToPrefsPage()
{
	userEditor = editorChoice;
/*	FacesContext context = FacesContext.getCurrentInstance();
	ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
				context.getViewRoot().getLocale());
	String successMsg = bundle.getString("Set_editor_cancel");
	context.addMessage (null, new FacesMessage(FacesMessage.SEVERITY_INFO,"Set_editor_cancel",successMsg));
*/
	return "author_preference";
//	return "pref_editor";
}

/**
 * @return Returns the authorPref.
 */
public MeleteAuthorPrefService getAuthorPref() {
	return authorPref;
}
/**
 * @param authorPref The authorPref to set.
 */
public void setAuthorPref(MeleteAuthorPrefService authorPref) {
	this.authorPref = authorPref;
}

/**
 * @param logger The logger to set.
 */
public void setLogger(Log logger) {
	this.logger = logger;
}

}
