/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-app/src/java/org/sakaiproject/tool/melete/EditSectionPage.java,v 1.7 2007/01/09 18:12:22 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 *
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.opensource.org/licenses/ecl1.php
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*
**********************************************************************************/

package org.sakaiproject.tool.melete;
import org.sakaiproject.api.app.melete.*;
import java.util.*;
import java.io.*;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

import javax.faces.context.FacesContext;
import javax.faces.application.FacesMessage;
import javax.faces.el.ValueBinding;

import javax.faces.component.*;
import javax.faces.event.*;
//import javax.servlet.http.HttpServletRequest;

import org.sakaiproject.component.app.melete.Section;
import org.sakaiproject.component.app.melete.ModuleDateBean;
import org.sakaiproject.api.app.melete.exception.MeleteException;
//import org.sakaiproject.jsf.ToolBean;
/**
 * @author Rashmi
 *
 * This class is the backing bean for AddModuleSections.jsp.
 * revised by rashmi 03/15/05 -- to make FS compatabile for linux and windows
 * revised by rashmi 03/17/05 -- add upload code
 * revised by rashmi on 3/21 to enforce automatic save before Finish
 * Mallika - 3/22/05 - Added methods for moduledatebeanservice to fix bug #369
 * revised by rashmi - 3/24/05 - to remove code from constructor and put it at the reqd part
 * revised by rashmi - 3/25 condition for upload file
 * revised to add validation for filename by rashmi on 3/30/05
 * revised to get the textarea value from mac through request parameter by rashmi - 04/07/05
 * Rashmi - Revised on 5/31/05 - to get addsectionpage instance and call resetvalues there
 * Rashmi - 06/14/05 to remove retain values problem in finish page
 * Rashmi - 06/20/05 remove finish screen and navigate to list auth page
 * Mallika - 3/29/06 - Adding meleteDocsDir reference
 * Mallika - 4/6/06 - Adding references for homeDir  to editSection
 * Mallika - 4/26/06 - Adding meleteDocsdir line in getPreviewPage
 * Mallika - 5/8/06 - Adding fix for https by Universidad Polit�cnica de Valencia
 * Mallika - 10/11/06 - Adding code to storeAtTempUpload to fix uploads problem
 * Mallika - 10/13/06 - Adding reference to checkUploadExists from saveHere
 * Mallika - 10/17/06 - Adding logUploadsEmpty method
 * Mallika - 10/18/06 - Moving reference to checkUploadExists
 * Mallika - 10/23/06 - Adding exists check to the uploads file
 * Mallika - 10/24/06 - Removed comments and changed logger.info to debug
 * Rashmi - 1/9/07 - link to internal resources
 */

public class EditSectionPage extends SectionPage implements Serializable/*,ToolBean*/{
	private boolean sizeWarning=false;
	private String previewPage;
    private ModuleService moduleService;

	public EditSectionPage(){
		 setFormName("EditSectionForm");
		}

	/*
	 * Set information of section. this function is called from edit module page ,
	 * list modules page.
	 *
	 * Revision on 11/15: - add code to initiate breadcrumps in add section page
	 * Revision on 12/14 - set success to false to fix bug of edit one section from list modules
	 * and then save and then call another section from list modules, success message still shows.
	 *
	 *Revision on 1/29/05 - reset values as its being retained.
	 */
	 public String setEditInfo(SectionObjService section)
	{
	 	resetSectionValues();
	 	checkUploadExists();
		setSection(section);
		setSuccess(false);
		 FacesContext context = FacesContext.getCurrentInstance();
			ValueBinding binding =
	            Util.getBinding("#{secBcPage}");
	        SecBcPage sbcPage = (SecBcPage)binding.getValue(context);
	        sbcPage.setModuleId(module.getModuleId().intValue());
	        sbcPage.setShowModuleId(module.getModuleId().intValue());
	        sbcPage.setShowSeqNo(section.getSeqNo());
	      //  logger.debug("@@@@@@ seq number "  + section.getSeqNo());
	        sbcPage.setEditMode(true);

		return "success";
	}


	/* mallika 's code for section breadcrumps as hyperlinks
	 * Revision -- Rashmi -- 12/14
	 * add prompt for save when moving out of the page.
	 * */
	  public void editSection(ActionEvent evt)
      {
            int paramModid = 0;
            int paramSeqno = 0;
           // logger.debug("Edit section being invoked in editsectionspage");
            FacesContext ctx = FacesContext.getCurrentInstance();

            UICommand cmdLink = (UICommand)evt.getComponent();
            List cList = cmdLink.getChildren();
            UIParameter param = new UIParameter();

            //logger.debug("check clist size" + cList.size());
            for (int i=0; i< cList.size(); i++)
            {
                    Object obj = cList.get(i);
                    if (obj instanceof UIParameter)
                    {
                      param = (UIParameter) cList.get(i);
                      if (param.getName().equals("modid"))
                      {
                            paramModid = ((Integer)param.getValue()).intValue();
                      }
                      if (param.getName().equals("seqno"))
                      {
                            paramSeqno = ((Integer)param.getValue()).intValue();
                      }
                     }
              }
           // logger.debug("Module id is "+paramModid+" seq no is "+paramSeqno);

              ValueBinding binding =
            Util.getBinding("#{editSectionPage}");
         EditSectionPage esPage = (EditSectionPage) binding.getValue(ctx);

         Section nextSection = (Section)getSectionService().getSection(paramModid, paramSeqno) ;
         setEditInfo(nextSection);

    }


    public String redirectToEditSection(){
    //        logger.debug("Redirecting to edit section in editsectionspage");
    	    return "editmodulesections";
}
/* end mallika code */

	/**
	 * @return sizeWarning
	 * render sizeWarning message if this flag is true
	 */
	public boolean getSizeWarning()
	{
		return this.sizeWarning;
	}

	/**
	 * @param sizeWarning
	 * to set sizeWarning to true if section save is successful.
	 */
	public void setSizeWarning(boolean sizeWarning)
	{
		this.sizeWarning = sizeWarning;
	}

	/*
	 * moved from sectionpage to give right nav rules
	 * revised by rashmi to remove code from constructor and put it at the reqd part
	 */
	public String editModulefromSection()
	{
		if(base_editModulefromSection().equals("success"))
		{
			FacesContext context = FacesContext.getCurrentInstance();
	  		Map sessionMap = context.getExternalContext().getSessionMap();
	  		String courseId = (String)sessionMap.get("courseId");
			ModuleDateBean mdbean = (ModuleDateBean) getModuleService().getModuleDateBean(courseId,module.getModuleId().intValue());
			ValueBinding binding = Util.getBinding("#{editModulePage}");
		  	EditModulePage emPage = (EditModulePage) binding.getValue(context);
		//  	logger.debug("BEfore setting mdbean "+mdbean+" empage "+emPage);
		  	emPage.setEditInfo(mdbean);
			return "edit_module";
		} else {
			return "editmodulesections";
		}

	}

	/*
	 * Revision - Rashmi - 11/22/04
	 * add code to get modified user info from session
	 * revised - Rashmi - 03/17/05 to upload contents
	 * Mallika - 4/6/06 - Adding code to send dirs
	 */
	public String saveHere()
	{

        checkUploadExists();
		String dataPath=new String();
		 FacesContext context = FacesContext.getCurrentInstance();
	     ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
	                		context.getViewRoot().getLocale());

	     // upload code
	     uploadContent("file1");
//	  	 String tempData;
//		   if((tempData = (String)context.getExternalContext().getRequestParameterMap().get("contentTextArea_mac")) !=null)
//		   		contentEditor = tempData;

//		  logger.debug("contenteditor as request param in edit section page" + contentEditor+"#");

	     if (!validateModality() && section.getContentType().equals("notype"))
	     {
	     	String errMsg = bundle.getString("add_section_modality_reqd");
			context.addMessage (null, new FacesMessage(errMsg));
			errMsg = bundle.getString("section_content_required");
			context.addMessage ("contentType", new FacesMessage(errMsg));
			return "failure";
	     }

	     // modality is required.
	     if (!validateModality())
	     {
	     	String errMsg = bundle.getString("add_section_modality_reqd");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
	     }
	     if(section.getContentType().equals("notype"))
	     {
	     	String errMsg = bundle.getString("section_content_required");
			context.addMessage ("contentType", new FacesMessage(errMsg));
			return "failure";
	     }
	     // validate first if content is there for the right content type choice
	      if (!validateContent())
	     {
	     	String errMsg = bundle.getString("add_section_content_validate_fail");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
	     }

	      if (this.section.getContentType().equals("typeLink") && this.section.getLink() != null && !(this.section.getLink().startsWith("http://") || this.section.getLink().startsWith("https://")))
		 	{
	     	String errMsg = bundle.getString("add_section_bad_url_format");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
		 	}

	  	//set a datapath for all type of content -- upload or content
	     dataPath= createDataPath();
         logger.debug("Section content type is "+section.getContentType());
         logger.debug("checkuploadchange "+checkUploadChange+" hiddenUpload: "+hiddenUpload);
	     if(section.getContentType().equals("typeUpload") && hiddenUpload != null && !hiddenUpload.equals(checkUploadChange))
	     {
	        // revised to add validation for filename by rashmi on 3/30/05
		       	if(!validateUploadFileName(hiddenUpload))
		     		{
		     		String errMsg = bundle.getString("bad_uploadfile_name");
					context.addMessage (null, new FacesMessage(errMsg));
					return "failure";
		     		}

	     	String uploadFile;
		       // revised by rashmi 03/25
	     	logger.debug("Value of hiddenUpload is "+hiddenUpload);
		    	if(hiddenUpload.indexOf("\\") != -1)
				{
		    		uploadFile = hiddenUpload.substring(hiddenUpload.lastIndexOf("\\")+1);
				} else
				{
					uploadFile = hiddenUpload.substring(hiddenUpload.lastIndexOf("/")+1);
				}

	       	File uFile = new File(homeDir+File.separator+"uploads"+File.separator +uploadFile);

	    	// check filesize
	       	//revised by rashmi for preview upload
	       	if(!uFile.exists())
	       	{
	       		logger.debug("ufile is under preview "+uploadFile+" and meleteDocsDir "+meleteDocsDir);
				//Mallika - changing line below to get meleteDocsDir
	       		//uFile = new File(homeDir+File.separator+"meleteDocs"+File.separator +"tempUpload"+File.separator +uploadFile);
	       		uFile = new File(meleteDocsDir+File.separator +"tempUpload"+File.separator +uploadFile);

	       	}
	       	double size = uFile.length()/1024;
	       	logger.debug("file size" + size);
	       	// revised by rashmi to correct the size check
	       	if(uFile.length() <= 0)
	       	 {
	        	// if size is greater than allow size set warning message
	       		logger.error("uploaded file is empty");
	       		String errMsg = bundle.getString("add_section_file_empty");
				context.addMessage (null, new FacesMessage(errMsg));
				return "failure";
	       	 }

	       	// get course size allowed

	        if(getMaxUploadSize() < size)
	       	 {
	        	// if size is greater than allow size set warning message

	       		sizeWarning=true;
	       	 }
	       	 section.setUploadPath(uploadFile);
	      }


		try
		{
//			 if content is new, create temp file to store the contents

		     if(section.getContentType().equals("typeEditor") && getContentEditor() != null && getContentEditor().trim()!=null)
		     {
		       	createContentTempFile();
		     }

		     // if content is a link
		     if(section.getContentType().equals("typeLink"))
		     {
		     	//logger.info("checking link");
		     	String check = validateLink(section.getLink());
		     	if(!check.equals("OK"))
		     	{
		     		String errMsg = bundle.getString("add_section_bad_url");
					context.addMessage (null, new FacesMessage(errMsg));
					return "failure";	
		     	}
		     }

		//rashmi ---  modified by information --- take user logged in info
		     Map sessionMap = context.getExternalContext().getSessionMap();
		    section.setModifiedByFname( (String)sessionMap.get("firstName"));
		    section.setModifiedByLname((String)sessionMap.get("lastName"));

	   //   save section
           //Mallika - new code to send the dirs
		    String homeDir = context.getExternalContext().getInitParameter("homeDir");
			String meleteDocsDir = context.getExternalContext().getInitParameter("meleteDocsDir");

		    getSectionService().editSection(module,section,dataPath, homeDir, meleteDocsDir);
		}
		catch(MalformedURLException me)
		{
			String errMsg = bundle.getString("add_section_bad_url");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
		}
		catch(UnknownHostException me)
		{
			String errMsg = bundle.getString("add_section_bad_url");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
		}
		catch(MeleteException me)
		{
		//	logger.error("show error message for"+me.toString()+me.getMessage()+",");
			String errMsg = bundle.getString(me.getMessage());
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
		}
		catch(Exception ex)
			{
			logger.error("edit section page-- insert section failed:" + ex.toString());
			String errMsg = bundle.getString("add_section_fail");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
			}
		return "success";
	}

	/**
	 * instantiates saving of a section.
	 * if file needs to be uploaded, upload file.
	 * Validate content.
	 * save section.
	 * If sucess set success flag and show the success message.
	 * if any error, display error message to the user.
	 *
	 **/
	public String save()
	{
	//	logger.debug("save sections called");
		setSuccess(false);
		if(!saveHere().equals("failure"))
		{
		setSuccess(true);
		return "editmodulesections";
		}
		return "editmodulesections";
	}


	/**
	 * save the section, if not saved yet and then refresh the page to
	 * add more sections.
	 *
	 * Revision on 11/15: - add code to initiate breadcrumps in add section page
	 * Revised on 3/22 - to set section as null
	 * Revised on 5/31/05 - to get addsectionpage instance and call resetvalues there
	 **/
	public String saveAndAddAnotherSection()
	{
		if(getSuccess()==false)
		{
			if(!saveHere().equals("failure"))
			{
			setSuccess(true);
			} else return "editmodulesections";
		}

	      // create new instance of section model
		 setSection(null);
		 resetSectionValues();
	     setSizeWarning(false);

	    FacesContext context = FacesContext.getCurrentInstance();
	 	Map sessionMap = context.getExternalContext().getSessionMap();
		sessionMap.put("currModule",module);

		ValueBinding binding =
            Util.getBinding("#{addSectionPage}");
		AddSectionPage aPage = (AddSectionPage)
        binding.getValue(context);
        aPage.setSection(null);
        aPage.resetSectionValues();

		// breadcrump thing added for malika's code to execute
//		 add moduleId in session for breadcrumps
		binding =
            Util.getBinding("#{secBcPage}");
        SecBcPage sbcPage = (SecBcPage)
        binding.getValue(context);
        sbcPage.setModuleId(module.getModuleId().intValue());
        sbcPage.setShowModuleId(module.getModuleId().intValue());
        sbcPage.setShowTextOnly(true);


		return "addmodulesections";
	}

	/**
	 * returns failure if the section has not been saved first.
	 * returns finish to redirect to addmodulefinish page.
	 * revised by rashmi on 3/21 to enforce automatic save
	 * revised by rashmi 06/14/05 to remove retain values problem in finish page
	 * */
	public String Finish()
	{
		if(getSuccess()==false)
		{
			if(!saveHere().equals("failure"))
			{
			setSuccess(true);
			} else return "editmodulesections";
		}

		 FacesContext context = FacesContext.getCurrentInstance();
	//	Map sessionMap = context.getExternalContext().getSessionMap();
	// commented to see retaintion at finish page 03/30/05
	//	if(!sessionMap.containsKey("currModule"))
//			sessionMap.put("currModule",module);
	//	return "editmodulefinish";
		 ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
        		context.getViewRoot().getLocale());
		 	String successMsg = bundle.getString("edit_section_confirm");
		   	FacesMessage msg =
		  		new FacesMessage("Info message",successMsg);
		  	msg.setSeverity(FacesMessage.SEVERITY_INFO);
		  	context.addMessage(null,msg);
		    return "list_auth_modules";

	}

	/*
	 * Preview - force save on preview
	 */
	public String getPreviewPage()
	{
		logger.debug("previewSection called");
		if (this.section.getContentType().equals("typeEditor"))
		return "editpreviewEditor";
		// bug# 584
		else if (this.section.getContentType().equals("typeUpload"))
		{
			 FacesContext context = FacesContext.getCurrentInstance();
		     ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
            		context.getViewRoot().getLocale());

		      	if(!validateUploadFileName(hiddenUpload))
		     		{
		     		String errMsg = bundle.getString("bad_uploadfile_name");
					context.addMessage(null, new FacesMessage(errMsg));
					return "editmodulesections";
		     		}
	     	      	uploadContent("file1");
	     	      	// transfer to meletedocs/tempUpload
	     	      	homeDir = context.getExternalContext().getInitParameter("homeDir");
	     	      	//Malika - new code beg
	     	      	meleteDocsDir = context.getExternalContext().getInitParameter("meleteDocsDir");
	     	      	//Mallika - new code end
	     	      	storeAtTempUpload();
		    	 return "editpreviewLink";
		}
		else return "editpreviewLink";
	}

	private void storeAtTempUpload()
	{

		FacesContext context = FacesContext.getCurrentInstance();


		try{
		//Mallika - changing line below to include meleteDocsDir
	 	//String tempDataPath = homeDir+File.separator+"meleteDocs"+File.separator+"tempUpload";
	 	String tempDataPath = meleteDocsDir+File.separator+"tempUpload";
        logger.debug("Temp data path is "+tempDataPath);
      	File tempUpload = new File(tempDataPath);
      	// create directory structure
      		if(!tempUpload.exists())
      			{
      			tempUpload.mkdirs();
      			}
      		String tempFileName;
      		if(hiddenUpload.indexOf("\\") != -1)
      		{
			tempFileName=hiddenUpload.substring(hiddenUpload.lastIndexOf("\\")+1);
			}
      		else
      		{
			tempFileName=hiddenUpload.substring(hiddenUpload.lastIndexOf("/")+1);
      		}

      		//Mallika - 10/9/06 - adding new if condition below to fix upload problem
			if (tempFileName != null)
			{
			  if (tempFileName.trim().length() > 0)
			  {
      		    File re = new File(homeDir+File.separator+"uploads"+File.separator+tempFileName);

      		    File f=new File(tempDataPath,tempFileName);
      		    if ((re.exists())&&(re.isFile() == true))
      		    {
      		      re.renameTo(f);

      		      previewTempUpload = serverConfigurationService.getServerUrl()+"/meleteDocs/tempUpload/"+ tempFileName ;
      		    }
		      }
              else
			  {
				logUploadsEmpty("storeAtTempUpload");
			    logger.error("UPLOADS DIRECTORY FILENAME IS LENGTH ZERO");
			    throw new MeleteException("UPLOADS ERROR: storeAtTempUpload failing");
			  }
			}
			else
			{
			  logUploadsEmpty("storeAtTempUpload");
			  logger.error("UPLOADS DIRECTORY FILENAME IS NULL");
			  throw new MeleteException("UPLOADS ERROR: storeAtTempUpload failing");
			}
			//Mallika - end if condition for uploads


		}catch(Exception e)
		{
			logger.error("error in storing preview uploaded file:" + e.toString());
		    ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
		    context.getViewRoot().getLocale());
			String errMsg = "Internal Error while saving section content in storeTempUpload" + e.toString();
		    context.addMessage (null, new FacesMessage(FacesMessage.SEVERITY_ERROR,"embed_image_failed",errMsg));

		}
	}

	public String cancelFromPreview()
	{
		return "editmodulesections";
	}
	 /**
	   * @return Returns the ModuleService.
	   */
	  public ModuleService getModuleService() {
		return moduleService;
	  }

	 /**
	  * @param moduleService The moduleService to set.
	  */
	  public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	  }
}