INSTRUCTIONS TO UPGRADE FROM MELETE 2.3.m1 >> MELETE 2.3.m2

There are no configuration or DB changes.

Compile and redeploy MELETE2.3.m2.
