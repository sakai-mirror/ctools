INSTRUCTIONS TO UPGRADE FROM MELETE 2.2 >> MELETE 2.3m2
1. Database change 
2. Add configurable properties in  Sakai.properties

--------------------------------------------------------

1. Database change 
1.1 Run the upgrade sql script manually provided under
	/components/src/sql/mysql

2.MAX UPLOAD SIZE FOR IMS IMPORT FILE
By setting this sakai property, system administrators can set a different file upload limit for Melete IMS CP import than the upload max limit for content files. If this property is not set then melete assumes the max value as 50Mb.

content.upload.ceiling=50
		
**** NOTE: The following steps are relevant ONLY if you have more than 1 editors installed. ****
		
3. Add configurable properties in Sakai.properties

3.1 DEFAULT MELETE EDITOR 
This is done by specifying the following property. For example, if the default Melete editor is Sferyx,
	melete.wysiwyg.editor=Sferyx Editor
If this property is not set, the code uses the editor specified by the wysiwyg.editor property.

3.2 LIST OF AVAILABLE MELETE EDITORS 
The preference feature allows users to select the editor for Melete content authoring. List the editor choices for users in sakai.properties as specified below. For example, if the user has two choices, Sferyx and FCK Editor, the settings will be as follows:

melete.wysiwyg.editor.count=2
melete.wysiwyg.editor1=Sferyx Editor
melete.wysiwyg.editor2=FCK Editor

NOTE : Please make sure that the names have proper spaces as this is used to display the labels of the available editors on the Preferences page.

