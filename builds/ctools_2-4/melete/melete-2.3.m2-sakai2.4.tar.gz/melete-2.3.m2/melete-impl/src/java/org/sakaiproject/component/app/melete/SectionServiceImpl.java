/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-impl/src/java/org/sakaiproject/component/app/melete/SectionServiceImpl.java,v 1.4 2006/11/28 19:40:20 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.io.Serializable;
import java.util.List;
import java.util.ListIterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.sakaiproject.api.app.melete.SectionService;
import org.sakaiproject.api.app.melete.ModuleObjService;
import org.sakaiproject.api.app.melete.SectionObjService;
import org.sakaiproject.api.app.melete.exception.MeleteException;

/**
 * @author Rashmi
 *
 * This is the class implementing SectionService interface.
 * Mallika - 4/20/05 - Added method to delete section
 * Revised by rashmi 4/26 add method for sort sections
 * Mallika - 4/6/06 - Changing insertSection signature and sending dirs to addSection and editSection
 * Rashmi - 5/23/06 - migrating to sakai 2.2 and hibernate 3
 * Mallika - 8/1/06 - adding method to delete sections
 */
public class SectionServiceImpl implements Serializable, SectionService{
	 private SectionDB sectiondb;
	private ModuleDB moduleDB;
	 private Section section = null;
	 private List sections = null;
	 private Log logger = LogFactory.getLog(SectionServiceImpl.class);

	public SectionServiceImpl(){
	//	System.out.println("section business cons called");
		sectiondb= getSectiondb();
		moduleDB = getModuleDB();
	}

	public void insertSection(ModuleObjService module, SectionObjService section, String contentPath, String homeDir, String meleteDocsDir) throws MeleteException
	{
		try{
				// insert new Section
				Module module1 = (Module)module;
				Section section1 = (Section)section;
				//Mallika - changing line below to send directories

			   sectiondb.addSection(module1, section1, contentPath, homeDir, meleteDocsDir);
			   }catch(Exception ex)
				{
			   		logger.error("section business --add section failed");
				   throw new MeleteException("add_section_fail");
				}
	}

	public void editSection(ModuleObjService module, SectionObjService section,String dataPath,String homeDir, String meleteDocsDir) throws MeleteException
	{
		try{
			// edit Section
			Module module1 = (Module)module;
			Section section1 = (Section)section;
			//Mallika - changing line below to send directories
				sectiondb.editSection(module1, section1, dataPath, homeDir, meleteDocsDir);
		   }
		catch(Exception ex)
			{
				logger.error("multiple user exception in section business");
			   throw new MeleteException("edit_section_multiple_users");
			}
	}

	public void deleteSection(SectionObjService sec)
	{
		try
		{
	  		sectiondb.deleteSection((Section)sec);
		}
	  	catch (Exception ex)
		{

		}

	}
	public void deleteSections(List sectionBeans)
	{
		 List secList = null; 
		 for (ListIterator i = sectionBeans.listIterator(); i.hasNext(); )
	      {	
			SectionBean secbean = (SectionBean)i.next();
			
			    secList = getSections(secbean.getSection().getModuleId());
			    if (secList != null)
			    {
			    	logger.info("secList size is "+secList.size());
			    }
		     
			  for (ListIterator j = secList.listIterator(); j.hasNext(); )
			  {	
			    Section sec = (Section) j.next();
				if (sec.getSectionId().intValue() == secbean.getSection().getSectionId().intValue())
				{	
				  try
			      {
		  		    sectiondb.deleteSection(sec);
			      }
		  	      catch (Exception ex)
			      {

			      }
		  	      break;
	            }	
			  }
	}
	}	 
	
	public SectionObjService getSection(int moduleId, int seqNo) {
		Section section = null;
   //     System.out.println("Coming to SectionBusiness get section method");
        try {
                section = moduleDB.getSection(moduleId, seqNo);
		    }catch (Exception e)
		    {
		           logger.error(e.toString());
		    }
        return section;
  }

// Mallika's methods
	  public void setSection(SectionObjService sec) {
	  	  	section = (Section)sec;
	  }

	  public List getSections(int moduleId) {
	  //	System.out.println("Coming to SectionsBusiness getSections");
	  	try {
	  		sections = moduleDB.getSections(moduleId);
	  	}catch (Exception e)
		{
	          logger.error(e.toString());
		}
	  	return sections;
	  }

	  public void setSections(List sections) {
	    this.sections = sections;
	  }

	  /*
	   * sort section sequences
	   * @see org.sakaiproject.api.app.melete.SectionService#updateSectionsSequence(java.util.List)
	   */
	  public void updateSectionsSequence(List newSeqList) throws Exception
	  {
	  	try{
			sectiondb.updateSectionsSequence(newSeqList);
			}catch(Exception ex)
			{
				logger.error("ManageModulesBusiness --update sections seq failed");
				throw new MeleteException(ex.toString());
			}
	  }
	  
	  public int getMaxModuleSections(ModuleObjService module) throws Exception
	  {
	  	int maxseq=0;
	  	try{
	  	maxseq=sectiondb.maxSequenceNumberModule((Module)module);
	  	}catch(Exception ex)
		{
			logger.error("Section serviceimpl--get max seq failed");
			throw new MeleteException(ex.toString());
		}
	  	return maxseq;
	  }
	/**
	 * @return Returns the sectiondb.
	 */
	public SectionDB getSectiondb() {
		return sectiondb;
	}
	/**
	 * @param sectiondb The sectiondb to set.
	 */
	public void setSectiondb(SectionDB sectiondb) {
		this.sectiondb = sectiondb;
	}
		/**
	 * @param moduleDB The moduleDB to set.
	 */
	public void setModuleDB(ModuleDB moduleDB) {
		this.moduleDB = moduleDB;
	}
	public ModuleDB getModuleDB() {
		return moduleDB;
	}
	
	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Log logger)
	  {
	    this.logger = logger;
	  }
}