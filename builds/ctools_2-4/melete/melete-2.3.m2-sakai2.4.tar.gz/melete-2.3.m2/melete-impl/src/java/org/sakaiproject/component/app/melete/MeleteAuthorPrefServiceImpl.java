/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-impl/src/java/org/sakaiproject/component/app/melete/MeleteAuthorPrefServiceImpl.java,v 1.1 2006/10/13 21:26:37 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.io.Serializable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.sakaiproject.api.app.melete.MeleteAuthorPrefService;
import org.sakaiproject.api.app.melete.exception.MeleteException;

public class MeleteAuthorPrefServiceImpl implements Serializable, MeleteAuthorPrefService{
private Log logger = LogFactory.getLog(MeleteAuthorPrefServiceImpl.class);
private MeleteUserPreferenceDB userPrefdb;


public void insertEditorChoice(String user_id, String choice) throws Exception
	{	
		try{
			userPrefdb.setUserEditorChoice(user_id,choice);
		}catch(Exception e)
			{
			logger.error("melete user pref business --add editor choice failed");
			 throw new MeleteException("add_editorchoice_fail");

			}
		return;
	}

public String getEditorChoice(String user_id) 
	{
	String choice = "";
		try{
			choice = userPrefdb.getUserEditorPreference(user_id);
		}catch(Exception e)
			{
			logger.error("melete user pref business --get editor choice failed");			 
			}
		return choice;
	}

/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Log logger)
	  {
	    this.logger = logger;
	  }
	/**
	 * @return Returns the UserPrefdb
	 */
	public MeleteUserPreferenceDB getUserPrefdb() {
		return userPrefdb;
	}
	/**
	 * @param UserPrefdb The UserPrefdb to set.
	 */
	public void setUserPrefdb(MeleteUserPreferenceDB userPrefdb) {
		this.userPrefdb = userPrefdb;
	}

}
