/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-impl/src/java/org/sakaiproject/component/app/melete/SectionDB.java,v 1.2 2006/06/06 21:54:59 mallikat Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.StaleObjectStateException;
import org.hibernate.Transaction;
import org.sakaiproject.api.app.melete.exception.MeleteException;

/**
 * @author Rashmi
 *
 * implements actual operations to the section table 
 * and related tables  
 *
 *Revised on 3/15/05 by rashmi to make it compatible for linux and windows
 * Mallika - 4/20/05 - Added method to delete section
 * add method to sort sections - rashmi 4/27/05
 * revised by rashmi 06/01/05 to check if file exists in meleteDocs/tempUpload and delete it
 * revised by rashmi 10/03/05 to sort physical files too along with setting new seq number while
 * performing action sort 
 * Mallika - 2/13/06 - pointing sort to new method bkupFileName to perform renaming at file level
 * inside module directory instead of creating another sort directory
 * Mallika - 4/6/06 - Adding code to handle directories in addSection,editSection and storeContentFiles
 * Rashmi - 4/18/06 - Revise sort function for secions containing links and upload content only
 * Mallika - 4/27/06 - Fixing storeContentFiles to handle preview
 * Mallika - 4/27/06 - Adding code in deleteSection to delete file after record is deleted from db
 * Mallika - 4/28/06 - Adding code to not delete file if its associated with another section
 * Mallika - 5/2/06 - Changing storeContentFiles to take filename
 * Mallika - 5/2/06 - Eliminating file renaming in sort
 * Mallika - 5/3/06 - Changing filename from seq to sectionid
 * Mallika - 5/3/06 - Changing deletesection to not delete section, instead rename it
 * * Mallika - 5/15/06 - Fixing bug ME-68
 * Rashmi - 05/22/06 - migrate to hibernate 3
 * Mallika - 5/31/06 - Changing temp file name to not contain section title
 */

public class SectionDB implements Serializable {
	private HibernateUtil hibernateUtil;
	 /** Dependency: a logger component. */
	 private Log logger = LogFactory.getLog(SectionDB.class);
	
	public SectionDB(){
		hibernateUtil = getHibernateUtil();
	}
	/**
	 * it looks for the next sequence number to be assigned to the new section.
	 * @param session
	 * @param module
	 * @return sequence number
	 */
	private int assignSequenceNumber(Session session, Module module)
	{
	 int maxSeq= 1;
	 try
		{
	 	  //logger.info("assign sequence to section query");
		   Query q=session.createQuery("select max(s.seqNo) from Section s where s.module =:module");
		   q.setEntity("module",module);
		   
   	  	  Integer maxsequence = (Integer)q.uniqueResult();
   		
		 // if no sequence is found then its first module.		 
		  if(maxsequence == null)
		  {
		   // logger.info("first section");
		    return maxSeq ;
 		  }
			 maxSeq = maxsequence.intValue()+1;
			 logger.info("section seq no will be" + maxSeq);
	     }
	     catch (HibernateException he)
	     {
			 logger.error(he.toString());
	     }
	    return maxSeq ;  			

	}
	/*
	 * This method moves the file from temp uploaded file to
	 * the right directory.The file is actually moved to the right spot at the time of saving
	 * so that if user uploads a file or creates content and after previewing and all
	 * cancels it. only when section is saved at that point save the file. 
	 * 
	 * revised by rashmi 03/15/05 to remove hard code of drive for FS.
	 * revised by rashmi 06/01/05 to check if file exists in meleteDocs/tempUpload
	 */
	private String storeContentFiles(String dataPath, String fileName, String contentFileName, String modId, String sectionTitle, String homeDir, String meleteDocsDir)
	{
		try{
			File re;
			File parent = new File(dataPath);
			// create directory structure
			if(!parent.exists())
			{
				parent.mkdirs();
			}
            logger.info("Datapath: "+dataPath+" meleteDocsDir: "+meleteDocsDir+" sectionTitle: "+sectionTitle);
            //Mallika - commenting line below since parameter is coming in
			//String homeDir = dataPath.substring(0,dataPath.indexOf("meleteDocs")-1);
			//logger.info("home dir in section DB"+ homeDir);
			// new file name
			if(fileName == null)
			{
				//Mallika - commented line below and moved it one level above(insertSection)
				//fileName = new String("Section_" + seq +".html");
				fileName = contentFileName;

				//String tempFileName = homeDir+File.separator+"uploads"+File.separator+modId+sectionTitle+".html";
				String tempFileName = homeDir+File.separator+"uploads"+File.separator+modId+"section_temp.html";


		//			 file to move
				re = new File(tempFileName);
			}
			else  	// for uploaded file 
			{
				re = new File(homeDir+File.separator+"uploads"+File.separator+fileName);
				File re1 = new File(meleteDocsDir+File.separator+"tempUpload"+File.separator+fileName);
                
				logger.info("Re exists "+re.exists());
				//Mallika - new code beg
				if (re.exists() == false)
				{
					if (re1.exists() == true)
					{
					  logger.info("Moving from tempUpload to uploads");	
					  re1.renameTo(re);
					}
				}
				//Mallika - new code end
				if(re1.exists())
				{
					re1.delete();
				}
				
                //Mallika - new code beg
				File re1_dir = new File(meleteDocsDir+File.separator+"tempUpload");
				if(re1_dir.exists())
				{
					re1_dir.delete();
				}
				
				
			}
		
			File f=new File(parent,fileName);
			
			// to overwrite for editor contents in case of edit
			if(f.exists())
			{
			//	logger.info("file exists and deleting it");
				f.delete();			
			}
			// file actually moved to the right dir
			re.renameTo(f);
			
			return fileName;
			}catch(Exception e){logger.error(e.toString());return null;}
	}
	
	/**
	 * Add section sets the not-null values not been populated yet and then
	 * inserts the section into section table.
	 * update module witht his association to new added section
	 * If error in committing transaction, it rollbacks the transaction.
	 */
	//Mallika - 5/3/06 - This addSection is the new one with section id
	//in section filename. The previous version of this function is in comments
	//below
	public void addSection(Module module, Section section,String dataPath, String homeDir, String meleteDocsDir) throws MeleteException
	{
	//	logger.info("SectionDB:inserting section");
		try{
		     Session session = hibernateUtil.currentSession();
	         Transaction tx = null;
			try
			{
			  // set default values for not-null fields
			  section.setCreationDate(new java.util.Date());
			  section.setModificationDate(new java.util.Date());
			  section.setModuleId(module.getModuleId().intValue());
			  
			  // assign seq number
			  int seq=assignSequenceNumber(session,module);
			  section.setSeqNo(seq);
			  
			  if(section.getContentType().equals("typeUpload"))
			  {
			  	//If this is an uploaded section, we can create the file
			  	//and save the section into the database
			  	String path=section.getUploadPath();
			    //logger.info("upload file " + path);
			  	//Mallika - commenting line below and replacing with new format
			  	//storeContentFiles(dataPath,path, seq, module.getModuleId().toString(), section.getTitle(), homeDir, meleteDocsDir);
			  	storeContentFiles(dataPath,path, null, module.getModuleId().toString(), section.getTitle(), homeDir, meleteDocsDir);
			  	
			  	section.setUploadPath(dataPath+path);
	            //logger.info("setting final upload path is " + section.getUploadPath());
			  	 
			  	// save object
				tx = session.beginTransaction();
				// logger.info("saving section");
				session.save(section);
				logger.info("after saving section");
				  
			    // associating section with module
				List sections =module.getSections();
				if(sections == null)
				{
					sections = new ArrayList();
				}
				  
				// rashmi -- if need be , add seq-1 for index for sequencing list
				sections.add(section);
				module.setSections(sections);
			    //logger.info("setting sections of module");
				session.saveOrUpdate(module);
			    //logger.info("after saving or update module");
				tx.commit();
				logger.info("commiting transaction and new added section id:" + section.getModuleId() + ","+section.getTitle());
				return ;			  	
			  }
			  else if(section.getContentType().equals("typeEditor"))
			  {
			    //If section is of typeEditor, first save the section
			  	//row into the table. Then create the file in the filesystem
			  	//Then update the section with the path info
				// save object
				tx = session.beginTransaction();
				// logger.info("saving section");
				//First save section
				Integer secIdObj = (Integer)session.save(section);
				int sectionId = secIdObj.intValue();
				logger.info("after saving section secId is "+sectionId);
				  
				//Store file in file system
				//Mallika - commenting line below and changing format	
			    //String path = storeContentFiles(dataPath,null, seq, module.getModuleId().toString(), section.getTitle(), homeDir, meleteDocsDir);
				String fileName = new String("Section_" + sectionId +".html");	
				String path = storeContentFiles(dataPath,null, fileName, module.getModuleId().toString(), section.getTitle(), homeDir, meleteDocsDir);
				
				//Update row in db with new content path
				section.setContentPath(dataPath+path);
				logger.info("setting final content path is " + section.getContentPath());				  
			    session.saveOrUpdate(section);
			    logger.info("Updated section");
			    
				// associating section with module
				List sections =module.getSections();
				if(sections == null)
				{
					sections = new ArrayList();
				}
				  
				// rashmi -- if need be , add seq-1 for index for sequencing list
				sections.add(section);
				module.setSections(sections);
			    //logger.info("setting sections of module");
				session.saveOrUpdate(module);
			    //logger.info("after saving or update module");
				tx.commit();
				logger.info("commiting transaction and new added section id:" + section.getModuleId() + ","+section.getTitle());
				return ;				 
			  }
			  else if(section.getContentType().equals("typeLink"))
			  {
			    //For typeLink, just save object	
			    tx = session.beginTransaction();
			    // logger.info("saving section");
			    session.save(section);
			  
			    // associating section with module
			    List sections =module.getSections();
			    if(sections == null)
			  	  sections = new ArrayList();
			  
			     // rashmi -- if need be , add seq-1 for index for sequencing list
			     sections.add(section);
			     module.setSections(sections);
		         //logger.info("setting sections of module");
			     session.saveOrUpdate(module);
		         //logger.info("after saving or update module");
			     tx.commit();
			     logger.info("commiting transaction and new added section id:" + section.getModuleId() + ","+section.getTitle());
			     return ;
			  }
			  else
			  {
			  	return;
			  }
	        }
			catch(StaleObjectStateException sose)
		     {
				logger.error("stale object exception" + sose.toString());
		     }
			catch(HibernateException he)
				     {
						if(tx !=null) tx.rollback();
						logger.error(he.toString());
						throw he;
				     }
	        	finally{
				hibernateUtil.closeSession();
				 }
		}catch(Exception ex){
				// Throw application specific error
			throw new MeleteException("add_section_fail");
			}
	}
		
	/*
	 * edit section....
	 * Revision - Rashmi 11/22/04
	 * correct the upload_path value for already uploaded file
	 * Mallika - 4/6/06 - changing code below to take params
	 */

	public void editSection(Module module, Section section,String dataPath,String homeDir, String meleteDocsDir) throws MeleteException
	{
		try{
		     Session session = hibernateUtil.currentSession();
	         Transaction tx = null;
			try
			{
			  // set default values for not-null fields
			  section.setModificationDate(new java.util.Date());
						  
			 if(section.getContentType().equals("typeUpload"))
			  {
			  	String path=section.getUploadPath();
		//	  	logger.info("upload file " + path);
			  	if(!(new File(path).exists()))
			  	{
		//	  		logger.info("calling store content files in edit at sectiondb " + dataPath +","+path);
			  		//Mallika - changing format for line below
			  		//storeContentFiles(dataPath,path, section.getSeqNo(), module.getModuleId().toString(), section.getTitle(), homeDir, meleteDocsDir);
			  		storeContentFiles(dataPath,path, null, module.getModuleId().toString(), section.getTitle(), homeDir, meleteDocsDir);
			  		
			  		section.setUploadPath(dataPath+path);
			   	} else {
			   		section.setUploadPath(path);
			   	}
			  	section.setContentPath(null);
			  	section.setLink(null);
			  }
			  else
			  if(section.getContentType().equals("typeEditor"))
			  {
			  //set contentpath if content type is new
			   //Mallika - changing format for line below	
			   //String path = storeContentFiles(dataPath,null, section.getSeqNo(), module.getModuleId().toString(), section.getTitle(), homeDir, meleteDocsDir);
			   
			   String contentFileName = section.getContentPath();
			   logger.info("After contentfilename "+contentFileName);
			   String fileName = null;

			   if (contentFileName != null)
			   {
				 fileName = contentFileName.substring(contentFileName.lastIndexOf(File.separator)+1);
		       }
		       else
		       {
				  //This code is executed when the section type is changed from link or upload
				  //to content..to fix bug ME-68
	             Integer secIdObj = section.getSectionId();
				 int sectionId = secIdObj.intValue();
				 logger.info("SectionId is "+sectionId);

				 //Store file in file system
				 fileName = new String("Section_" + sectionId +".html");

			   }

			   logger.info("Before storecontentfiles "+fileName);
			   String path = storeContentFiles(dataPath,null, fileName, module.getModuleId().toString(), section.getTitle(), homeDir, meleteDocsDir);
				  	  
			   section.setContentPath(dataPath+path);
			   section.setUploadPath(null);
			  	section.setLink(null);
			  }
			  else if(section.getContentType().equals("typeLink"))
			  {
			  	 section.setUploadPath(null);
			  	 section.setContentPath(null);
			  }
			  // save object
			  tx = session.beginTransaction();
	//		  logger.info("saving section");
			  session.saveOrUpdate(section);
	//		  logger.info("after saving section");
			  tx.commit();
			  logger.info("commit transaction and edit section :" + section.getModuleId() + ","+section.getTitle());
			  return ;

	        }
			catch(StaleObjectStateException sose)
		     {
				if(tx !=null) tx.rollback();
				logger.error("stale object exception" + sose.toString());
				throw new MeleteException("edit_section_multiple_users");
		     }
			catch (HibernateException he)
				     {
						if(tx !=null) tx.rollback();
						logger.error(he.toString());
						he.printStackTrace();
						throw he;
				     }
	       	finally{
	       			hibernateUtil.closeSession();
				 	}
		}
		catch(MeleteException ex){
			// Throw application specific error
			throw ex;
		}
		catch(Exception ex){
				// Throw application specific error
			throw new MeleteException("add_section_fail");
			}
	}
	 public void deleteSection(Section sec) throws Exception
	 {
	 	Transaction tx = null;
	 	Session session = hibernateUtil.currentSession();
	 	boolean deleteFlag = false;
	 	boolean uploadFlag = false;
	 	String fileName=null;
	 	try
		{
	      logger.info("coming to sectiondb: deleteSection");
	      tx = session.beginTransaction();

	      //Delete section
	      logger.info("Deleting section "+sec.getTitle());
	    
	      if ((sec.getContentType().equals("typeEditor"))||(sec.getContentType().equals("typeUpload")))
	      {
	      	try
		    {
	      	
	      	if (sec.getContentType().equals("typeEditor"))
	      	{
	      		fileName = sec.getContentPath();
	      	}
	    	if (sec.getContentType().equals("typeUpload"))
	      	{
	    		uploadFlag = true;
	      		fileName = sec.getUploadPath();
	      	}
 		      		       
		    }
	        catch (Exception e)
		    {
	      	logger.error(e.toString());
		    }
		  }
	      session.delete(sec);
	         
	      tx.commit();
	      logger.info("successfully deleted section");
	      deleteFlag = true;
	    }	 	
	    catch (HibernateException he)
	    {
	      if (tx!=null) tx.rollback();
		  logger.error(he.toString());
		  throw he;
	    }	 
	    catch (Exception e) {
	      if (tx!=null) tx.rollback();
	      logger.error(e.toString());
	      throw e;
	    }
	    /*finally
		{
	    	try
			  {
		      	hibernateUtil.closeSession();
		      	logger.info("Closing session after delete");
			  }
		      catch (HibernateException he)
			  {
				  logger.info(he.toString());
				  throw he;
			  }		    	
		}*/	
	    session.flush();
	    tx = null;
	    try
		{
	         
	      tx = session.beginTransaction();

	      String queryString = "from Section sec where sec.moduleId = :moduleId and sec.seqNo > :seqno";
	      Query query = session.createQuery(queryString);
	      query.setParameter("moduleId", new Integer(sec.getModuleId()));
	      query.setParameter("seqno",new Integer(sec.getSeqNo()));
	      //logger.info("Query created");
	      Iterator itr = query.iterate();
	      //logger.info("Iterating");
	      Section secObj = null;
	      while (itr.hasNext()) {
	      	//logger.info("Going thru loop");
	      	secObj = (Section) itr.next();
	      	//logger.info("Section title is "+secObj.getTitle());
	      	//logger.info("Section seq before is "+secObj.getSeqNo());
	      	secObj.setSeqNo(secObj.getSeqNo() - 1);
	      	//logger.info("Section seq after is "+secObj.getSeqNo());
	      	session.saveOrUpdate(secObj);
	      }
	      session.flush();
	      tx.commit();
	      logger.info("Completed updating sequence");
	      deleteFlag = true;	      
	    }	 	
	    catch (HibernateException he)
	    {
	      if (tx!=null) tx.rollback();
		  logger.error(he.toString());
		  throw he;
	    }	 
	    catch (Exception e) {
	      if (tx!=null) tx.rollback();
	      logger.error(e.toString());
	      throw e;
	    }
	    	    
	    //Mallika - new code beg to check if other sections have same file
	    //Needed only for uploaded files
	    	
	    try
		{
	       if (uploadFlag == true)
	       {	
	 	   Query q=session.createQuery("select count(*) from Section s where s.uploadPath =:uploadPath");
		   q.setString("uploadPath",fileName);
		   
   	  	    Integer fileCount = (Integer)q.uniqueResult();
   		    if (fileCount.intValue() > 0)
		    {
		 	  deleteFlag = false;
		 	  logger.info("File is associated with other sections");
		    }
		    else
		    {
		 	  deleteFlag = true;
		    }
	       }
	     }
	     catch (HibernateException he)
	     {
			 logger.error(he.toString());
	     }	
	     finally
		 {
	    	try
		    {
		     	hibernateUtil.closeSession();
		      	logger.info("Closing session after delete");
		    }
			catch (HibernateException he)
			{
			  logger.error(he.toString());
			  throw he;
			}		    	
		 }	     
	 
	    //Only delete file from file system if deletion is successful
	    //at db level
	    if (deleteFlag == true)
	    {	
	      try
		  {
	        File f=new File(fileName);
		    // to overwrite for editor contents in case of edit
		    if(f.exists())
		    {
		      //logger.info("file exists and renaming it");
		      String newFileName = fileName + ".del";
		      logger.info("New filename is "+newFileName);
		      File newF = new File(newFileName);
		      f.renameTo(newF);
			  logger.info("Renamed file");
		    }
		  }
	      catch (Exception e)
		  {
	    	logger.error(e.toString());
		  }
	    }  
	 }	
		
	//Mallika 5/2/06 - new updateSectionsSequence method that does not do 
	// any file renaming, to revert to previous method just 
	// get previous method from cvs
	public void updateSectionsSequence(List newSeqList)throws MeleteException
	{
		try{
		     Session session = hibernateUtil.currentSession();
		      Transaction tx = null;
		
		   try{
//		  		4a. begin transaction
   				tx = session.beginTransaction();
   				
   			   for(int i=0; i < newSeqList.size(); i++ )
		   		{
		   	//	2.get section element and assign new seq
		   		Section section = (Section)newSeqList.get(i);
		   		
		   		section.setSeqNo(i+1);
		   		   		
		   	//3a		save all objects
		   			session.saveOrUpdate(section);
		   			logger.info("section updated");			   			
		   		}
				   
				tx.commit();
		 //  		logger.info("newSeqList success");
	   			return ; 
		     }
		     catch (HibernateException he)
		     {
				if(tx !=null) tx.rollback();
				logger.error("error in section seq save"+he.toString());
				throw new MeleteException(he.toString());
		     }
		
		} catch (Exception e)
	     {
			 logger.error(e.toString());
			 throw new MeleteException(e.toString());
	     }
	     finally
			{
		    	try
				  {
			      	hibernateUtil.closeSession();
				  }
			      catch (HibernateException he)
				  {
					  logger.error(he.toString());
				  }
			}
	}
		
	/**
	 * @return Returns the hibernateUtil.
	 */
	public HibernateUtil getHibernateUtil() {
		return hibernateUtil;
	}
	/**
	 * @param hibernateUtil The hibernateUtil to set.
	 */
	public void setHibernateUtil(HibernateUtil hibernateUtil) {
		this.hibernateUtil = hibernateUtil;
	}
	
	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Log logger) {
		this.logger = logger;
	}
}