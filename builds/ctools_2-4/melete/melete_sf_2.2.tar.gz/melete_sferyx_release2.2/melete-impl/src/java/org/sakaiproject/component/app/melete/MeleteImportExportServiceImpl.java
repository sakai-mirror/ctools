/**********************************************************************************
*
* $Header:
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.component.app.melete;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.QName;
import org.dom4j.XPath;
import org.doomdark.uuid.UUID;
import org.doomdark.uuid.UUIDGenerator;
import org.sakaiproject.api.app.melete.MeleteImportExportService;
import org.sakaiproject.component.cover.ServerConfigurationService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.sakaiproject.tool.cover.ToolManager;
import org.sakaiproject.user.cover.UserDirectoryService;
import org.xml.sax.SAXException;
import org.sakaiproject.api.app.melete.exception.MeleteException;
import org.sakaiproject.api.app.melete.util.XMLHelper;

/**
 * MeleteImportExportServiceImpl is the implementation of MeleteImportExportService
 * that provides the methods for import export
 *
 * @author Foot hill college
 * @version
 * Mallika - 3/7/06 - getting rid of instr_ from datapath
 * Mallika - 3/29/06 - Adding meleteDocsDir reference
 * Mallika - 4/17/06 - Adding meleteDocsDir references
 * Murthy  - 04/05/06 - xpath expression updated for module description
 * 						in buildModule() method
 * Rashmi - 05/02/06 - import/export of section instructions
 * Rashmi - 05/03/06 - import/export of whats next steps
 * Rashmi - 05/09/06 - revised export of whats next
 * Mallika - 5/9/06 - Added log exception instead of throw
 * Rashmi - 05/10/06 - revised buildmodule() and restructured it. 
 *  Rashmi - 05/11/06 -import/export of keywords and license information.
 * Mallika - 6/1/06 - fixing long filenames bug
 */
public class MeleteImportExportServiceImpl implements MeleteImportExportService{
	/*******************************************************************************
	* Dependencies
	*******************************************************************************/
	/** Dependency:  The logging service. */
	protected Log m_logger = LogFactory.getLog(MeleteImportExportServiceImpl.class);

	/**default namespace and metadata namespace*/
	protected String DEFAULT_NAMESPACE_URI = "http://www.imsglobal.org/xsd/imscp_v1p1";
	protected String IMSMD_NAMESPACE_URI ="http://www.imsglobal.org/xsd/imsmd_v1p2";
	protected int MOD_LICENSE_CODE = 4; //Fair Use Exception
	protected String MOD_LICENSE_URL = "Copyrighted Material - subject to fair use exception"; //Fair Use Exception
// add by rashmi
	protected int MOD_LICENSE_COPYRIGHT_CODE = 1; //Copyright of author
	protected int MOD_LICENSE_PD_CODE = 2; //		Public Domain
	protected int MOD_LICENSE_CC_CODE = 3; //Creative Commons
// add end	
	protected SectionDB sectionDB;
	protected ModuleDB moduleDB;
	protected ModuleShdates moduleShdates;

	protected String unzippeddirpath = null;
	protected String homedirpath = null;

	//Mallika - new code beg
	protected String meletedocsdirpath = null;
	//Mallika - new code end


	/**
	 * Establish my logger component dependency.
	 * @param logger the logger component.
	 */
	public void setLogger(Log logger){
		m_logger = logger;
	}
	/**
	 * Final initialization, once all dependencies are set.
	 */
	public void init(){
		m_logger.info(this +".init()");
	}

	/**
	 * Final cleanup.
	 */
	public void destroy(){
		m_logger.info(this +".destroy()");
	}
	/**
	 *constructor
	 */
	public MeleteImportExportServiceImpl() {
		super();
	}


	/**
	 * creates document root element "manifest" and adds the namespaces
	 *
	 * @return returns the manifest element
	 * @throws  Exception
	 */
	public Element createManifest() throws Exception {
		Element root = DocumentHelper.createElement("manifest");
		//Set up the necessary namespaces
		root.setQName(new QName("manifest", new Namespace(null,	DEFAULT_NAMESPACE_URI)));
		root.add(new Namespace("imsmd",IMSMD_NAMESPACE_URI));
		root.add(new Namespace("xsi", "http://www.w3.org/2001/XMLSchema-instance"));

		root.addAttribute("xsi:schemaLocation",
				"http://www.imsglobal.org/xsd/imscp_v1p1 "
						+ "http://www.imsglobal.org/xsd/imscp_v1p1.xsd "
						+ "http://www.imsglobal.org/xsd/imsmd_v1p2 "
						+ "http://www.imsglobal.org/xsd/imsmd_v1p2.xsd ");
		root.addAttribute("identifier", "Manifest-" + getUUID().toString());
		root.addAttribute("version", "IMS CP 1.1.4");
		return root;
	}

	/**
	 * creates document root element "manifest" from the default manifest file
	 * and adds the namespaces
	 * @param xmlFile - Default manifest file
	 * @return returns the manifest element
	 * @throws  Exception
	 */
	public Element getManifest(File xmlFile) throws Exception {
		try {
			Document document = XMLHelper.getSaxReader().read(xmlFile);
			Element root = document.getRootElement();
			Element rootnew = root.createCopy();
			List childEleList  = rootnew.elements();
			childEleList.clear();

			this.DEFAULT_NAMESPACE_URI = rootnew.getNamespaceURI();

			List nslist = rootnew.declaredNamespaces();

			for (int i=0; i<nslist.size(); i++){
				if (((Namespace)nslist.get(i)).getPrefix().equals("imsmd")){
					this.IMSMD_NAMESPACE_URI = ((Namespace)nslist.get(i)).getURI();
					break;
				}
			}
			rootnew.addAttribute("identifier", "Manifest-" + getUUID().toString());
			return rootnew;
		} catch (DocumentException de) {
			throw de;
		} catch (SAXException se) {
			throw se;
		}catch (Exception e) {
			throw e;
		}
	}

	/**
	 * create manifest metadata element with schema and schemaversion elements
	 *
	 * @return - returns metadata element
	 */
	public Element createManifestMetadata() {
        Element metadata = createDefaultNSElement("metadata", "metadata");

        //schema element
        Element schema = createDefaultNSElement("schema", "schema");
        schema.setText("IMS Content");
        metadata.add(schema);

        //schema version element
        Element schemaVersion = createDefaultNSElement("schemaversion", "schemaversion");
        schemaVersion.setText("1.1.4");
        metadata.add(schemaVersion);

        return metadata;
    }


	/**
	 * creates the default namespace element
	 * @param elename - element name
	 * @param qname - qualified name
	 * @return - returns the default namespace element
	 */
	public Element createDefaultNSElement(String elename, String qname) {
		Element metadata = DocumentHelper.createElement(elename);
        metadata.setQName(new QName(qname,new Namespace(null, DEFAULT_NAMESPACE_URI)));
		return metadata;
	}


	/**
	 * creates the LOM metadata element
	 * @param elename - element name
	 * @param qname - qualified name
	 * @return - returns the metadata element
	 */
	public Element createLOMElement(String elename, String qname) {

		Element imsmdlom = DocumentHelper.createElement(elename);
		imsmdlom.setQName(new QName(qname,new Namespace("imsmd", IMSMD_NAMESPACE_URI)));

		return imsmdlom;
	}

	/**
	 * creates metadata title element
	 * @param title - title
	 * @return - returns the title element
	 */
	public Element createMetadataTitle(String title) {
		//imsmd:title
        Element imsmdtitle = createLOMElement("imsmd:title", "title");

        //imsmd:langstring
        Element imsmdlangstring = createLOMElement("imsmd:langstring", "langstring");
        //imsmdlangstring.addAttribute("xml:lang", "en-US");
        imsmdlangstring.setText(title);

        imsmdtitle.add(imsmdlangstring);

        return imsmdtitle;
	}

	/**
	 * creates metadata description element
	 * @param description - description
	 * @return - returns the metadata description element
	 */
	public Element createMetadataDescription(String description) {
		//imsmd:description
		Element mdDesc = createLOMElement("imsmd:description", "description");

		//imsmd:langstring
		Element mdLangString = createLOMElement("imsmd:langstring", "langstring");
		//mdLangString.addAttribute("xml:lang", "en-US");
		mdLangString.setText(description);

		mdDesc.add(mdLangString);

		return mdDesc;
	}

	/*
	 * create keyword element
	 * add by rashmi
	 */
	public Element createMetadataKeyword(String keyword) {
		//imsmd:keyword
		Element mdKeyword = createLOMElement("imsmd:keyword", "keyword");

		//imsmd:langstring
		Element mdLangString = createLOMElement("imsmd:langstring", "langstring");
		//mdLangString.addAttribute("xml:lang", "en-US");
		mdLangString.setText(keyword);

		mdKeyword.add(mdLangString);

		return mdKeyword;
	}

	/*
	 * create copyright element 
	 * add by rashmi
	 */
	public Element createMetadataCopyright(int licenseCode)
	{
		//imsmd:copyright
		Element mdCopyright = createLOMElement("imsmd:copyrightandotherrestrictions", "copyrightandotherrestrictions");
		
		Element mdSource = createLOMElement("imsmd:source", "source");
		Element mdLangString = createLOMElement("imsmd:langstring", "langstring");
		mdLangString.setText("Melete");
		mdSource.add(mdLangString);
		mdCopyright.add(mdSource);
		// if public domain then no restrictions are applied
		// and for all other licenses restrictions are applied
		Element mdValue = createLOMElement("imsmd:value", "value");
		Element mdLangString1 = createLOMElement("imsmd:langstring", "langstring");
		if(licenseCode != MOD_LICENSE_PD_CODE)
			mdLangString1.setText("yes");
		else mdLangString1.setText("no");
		mdValue.add(mdLangString1);
		mdCopyright.add(mdValue);	
		
		return mdCopyright;
	}
	
	/*
	 * create license url for manifest file
	 * add by rashmi 
	 */
	private String createLicenseUrl (int lcode, String lurl)
	{
		if(lcode == MOD_LICENSE_PD_CODE || lcode == MOD_LICENSE_CC_CODE)
		{
			lurl = moduleDB.fetchCcLicenseName(lurl);
			if(lcode == MOD_LICENSE_CC_CODE)
				lurl = "Creative Commons " + lurl;
			
		}
		return lurl;
	}
	
	/**
	 * adds organization and resource items tomanifest
	 * @param modDateBeans - module date beans
	 * @param packagedir - package directory
	 * @return - returns the list of manifest elements
	 * @throws Exception
	 */
	public List generateOrganizationResourceItems(List modDateBeans, File packagedir, String homeDirPath)throws Exception{
		try{
			String packagedirpath = packagedir.getAbsolutePath();
			String resourcespath  = packagedirpath + File.separator + "resources";
			File resoucesDir = new File(resourcespath);
			if (!resoucesDir.exists())
				resoucesDir.mkdir();

			String imagespath  = resoucesDir.getAbsolutePath() + File.separator + "images";

			Element organizations = createOrganizations();
			Element resources = createResources();

			Element organization = addOrganization(organizations);

			organizations.addAttribute("default", organization.attributeValue("identifier"));

			Iterator mdBeanIter = modDateBeans.iterator();
			ModuleDateBean mdBean = null;
			int i = 0, j=0, k=0;
			//create item for each module and items under the module item for
			// scetions
			while (mdBeanIter.hasNext()){
				mdBean = (ModuleDateBean)mdBeanIter.next();

				Module module = (Module)mdBean.getModule();
				Element modMainItem = organization.addElement("item");
				modMainItem.addAttribute("identifier", "MF01_ORG1_MELETE_MOD"+ ++i);

				Element title = modMainItem.addElement("title");
				if (module.getTitle() != null && module.getTitle().trim().length() > 0)
					title.setText(mdBean.getModule().getTitle());

				List sectionBeans = mdBean.getSectionBeans();
				if (sectionBeans != null && sectionBeans.size() > 0){
					Iterator secBeanIter = sectionBeans.iterator();
					SectionBean sectionBean = null;
					//create items and resources for sections
					while (secBeanIter.hasNext()){
						sectionBean = (SectionBean)secBeanIter.next();
						Section section = sectionBean.getSection();
						Element secElement = modMainItem.addElement("item");
						secElement.addAttribute("identifier", "ITEM"+ ++k);

						Element secTitleEle = secElement.addElement("title");
						secTitleEle.setText(section.getTitle());

						Element resource = resources.addElement("resource");
						resource.addAttribute("identifier","RESOURCE"+ ++j);
						resource.addAttribute("type ","webcontent");
						if (section.getContentType().equals("typeLink") && section.getLink().startsWith("http://")){
							resource.addAttribute("href", section.getLink());
						}else if (section.getContentType().equals("typeEditor")){
							Element file = resource.addElement("file");
							String fileName = section.getContentPath().substring(section.getContentPath().lastIndexOf(File.separator)+1);
							//Mallika - new code to truncate fileName

							if (fileName.startsWith("module_"))
							{
								int und_index = fileName.indexOf("_",7);
								m_logger.info("Second und index is "+und_index);
								fileName = fileName.substring(und_index+1, fileName.length());
								m_logger.info("Truncated fileName is "+fileName);
						    }

							file.addAttribute("href", "resources/module_"+ i +"_"+ fileName);
							resource.addAttribute("href", "resources/module_"+ i +"_"+ fileName);

							//read the content to modify the path for images
							String filecontent = readFromFile(new File(section.getContentPath()));
							//replace image path and create image files
							String modSecContent = replaceImagePath(filecontent, imagespath, resource, homeDirPath);

							//create the file
							File resfile = new File(resoucesDir+ "/module_"+ i +"_"+ fileName);
							//createFile( section.getContentPath(), resfile.getAbsolutePath());
							createFileFromContent( modSecContent, resfile.getAbsolutePath());

						}else if(section.getContentType().equals("typeUpload")){
							Element file = resource.addElement("file");
							String fileName = section.getUploadPath().substring(section.getUploadPath().lastIndexOf(File.separator)+1);

                            if (fileName.startsWith("module_"))
							{
								int und_index = fileName.indexOf("_",7);
								m_logger.info("Second und index is "+und_index);
								fileName = fileName.substring(und_index+1, fileName.length());
								m_logger.info("Truncated fileName is "+fileName);
						    }

							file.addAttribute("href", "resources/module_"+ i +"_"+ fileName);
							resource.addAttribute("href", "resources/module_"+ i +"_"+ fileName);

							//create the file
							File resfile = new File(resoucesDir+ "/module_"+ i +"_"+ fileName);
							createFile( section.getUploadPath(), resfile.getAbsolutePath());
						}
						secElement.addAttribute("identifierref", resource.attributeValue("identifier"));

						//add section instructions by rashmi thru metadata

						Element imsmdlom = createLOMElement("imsmd:lom", "lom");
						Element imsmdgeneral = imsmdlom.addElement("imsmd:general");

						if (section.getInstr() != null && section.getInstr().trim().length() > 0)
							imsmdgeneral.add(createMetadataDescription(section.getInstr()));

						secElement.add(imsmdlom);

						// add section instructions end

					}
//					 add next steps as the last section of the module by rashmi
					if (module.getWhatsNext() != null && module.getWhatsNext().trim().length() > 0)
					{
						Element whatsNextElement = modMainItem.addElement("item");
						whatsNextElement.addAttribute("identifier", "NEXTSTEPS"+ ++k);

						Element nextTitleEle = whatsNextElement.addElement("title");
						nextTitleEle.setText("NEXTSTEPS");

						Element resource = resources.addElement("resource");
						resource.addAttribute("identifier","RESOURCE"+ ++j);
						resource.addAttribute("type ","webcontent");

//						create the file
						File resfile = new File(resoucesDir+ "/module_"+ i +"_nextsteps.html");
						createFileFromContent( module.getWhatsNext(), resfile.getAbsolutePath());
						whatsNextElement.addAttribute("identifierref", resource.attributeValue("identifier"));
						Element file = resource.addElement("file");
						file.addAttribute("href", "resources/module_"+ i +"_nextsteps.html");
						resource.addAttribute("href", "resources/module_"+ i +"_nextsteps.html");
					}
				// add next steps end

				}
				//add module description thru metadata
				Element imsmdlom = createLOMElement("imsmd:lom", "lom");
				Element imsmdgeneral = imsmdlom.addElement("imsmd:general");

				if (module.getDescription() != null && module.getDescription().trim().length() > 0)
					imsmdgeneral.add(createMetadataDescription(module.getDescription()));

				// add keyword if available - rashmi
				if (module.getKeywords() != null && module.getKeywords().trim().length() > 0)
					imsmdgeneral.add(createMetadataKeyword(module.getKeywords()));

				// add copyright information - rashmi
				// create rights elemnet
				Element imsmdright = imsmdlom.addElement("imsmd:rights");
				// create copyright element
				imsmdright.add(createMetadataCopyright(module.getLicenseCode()));
				// add license description
				Element mdLicenseDesc = createLOMElement("imsmd:description", "description");
				Element mdLangString2 = createLOMElement("imsmd:langstring", "langstring");
				String lurl = createLicenseUrl(module.getLicenseCode(),module.getCcLicenseUrl());
				mdLangString2.setText(lurl);
				mdLicenseDesc.add(mdLangString2);
				imsmdright.add(mdLicenseDesc);
				// copyright info add end
				
				modMainItem.add(imsmdlom);

			}
			ArrayList manElements = new ArrayList();
			manElements.add(organizations);
			manElements.add(resources);

			return manElements;

		}catch(Exception e){
			throw e;
		}

	}

	/**
	 * creates file from input path to output path
	 * @param inputpath - input path for file
	 * @param outputpath - output path for file
	 * @throws Exception
	 */
	public void createFile(String inputurl, String outputurl)throws Exception{
		FileInputStream in = null;
		FileOutputStream out = null;
		try {
			File inputFile = new File(inputurl);
			File outputFile = new File(outputurl);
			in = new FileInputStream(inputFile);
			out = new FileOutputStream(outputFile);
			int c;
//			while ((c = in.read()) != -1)
//				out.write(c);

			int len;
			byte buf[] = new byte[102400];
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
		} catch (FileNotFoundException e) {
			m_logger.error(e.toString());
		} catch (IOException e) {
			throw e;
		} finally{
			try {
				if (in != null)
					in.close();
			} catch (IOException e1) {
			}
			try {
				if (out != null)
					out.close();
			} catch (IOException e2) {
			}
		}
	}

	/**
	 * creates file from input path to output path
	 * @param inputpath - input path for file
	 * @param outputpath - output path for file
	 * @throws Exception
	 */
	public void createFileFromContent(String content, String outputurl)throws Exception{
		PrintWriter out = null;
		try {
			out = new PrintWriter(new BufferedWriter(new FileWriter(outputurl)));
			out.write(content);
			out.flush();
		} catch (IOException e) {
			throw e;
		} catch (Exception e) {
			throw e;
		} finally {
			if (out != null)
				out.close();
		}
	}

	/**
	 * deletes the file and its children
	 * @param delfile - file to be deleted
	 */
	public void deleteFiles(File delfile){

		if (delfile.isDirectory()){
			File files[] = delfile.listFiles();
			int i = files.length;
			while (i > 0)
				deleteFiles(files[--i]);

			delfile.delete();
		}else
			delfile.delete();

	}


	/**
	 * Parses the manifest and build modules
	 *
	 * @param document document
	 * @param unZippedDirPath unZipped fiels Directory Path
	 * @exception throws exception
	 */
	public void parseAndBuildModules(Document document, String unZippedDirPath, String homeDirPath, String meleteDocsDirPath) throws Exception {
		if (m_logger.isInfoEnabled())
			m_logger.info("Entering parseAndBuildModules");
		setUnzippeddirpath(unZippedDirPath);
		setHomedirpath(homeDirPath);
		//Mallika - new code beg
		setMeletedocsdirpath(meleteDocsDirPath);
		//Mallika - new code end


		Map uris = new HashMap();
		uris.put("imscp", DEFAULT_NAMESPACE_URI);
		uris.put("imsmd", IMSMD_NAMESPACE_URI);

		//organizations
		XPath xpath = document
				.createXPath("/imscp:manifest/imscp:organizations/imscp:organization");
		xpath.setNamespaceURIs(uris);

		Element eleOrg = (Element) xpath.selectSingleNode(document);

		//build module
		//loop thru organization elements - item elements
		List elements = eleOrg.elements();
		for (Iterator iter = elements.iterator(); iter.hasNext();) {
			Element element = (Element) iter.next();
			buildModule(element, document);
		}

		if (m_logger.isInfoEnabled())
			m_logger.info("Exiting parseAndBuildModules");
	}

	/**
	 * Builds the module for each Item element under organization
	 *
	 * @param eleItem item element
	 * @exception throws exception
	 * revised by rashmi - change the whole structure of accessing elements
	 */
	private void buildModule(Element eleItem, Document document)
	throws Exception {

		if (m_logger.isInfoEnabled())
			m_logger.info("Entering buildModule..." );

//		create module object
		Module module = new Module();
		Element titleEle = (Element)eleItem.elements( "title" ).get(0);
		
		String title = titleEle.getTextTrim();
		if (title != null && title.length() !=0)module.setTitle(title);
		else module.setTitle("Untitled Module");
							
		Element generalElement = (Element)eleItem.selectNodes("./imsmd:lom/imsmd:general").get(0);
			
		List moduleMetadataList = generalElement.elements();
		for (Iterator iter = moduleMetadataList.iterator(); iter.hasNext();) {
			Element metaElement = (Element) iter.next();
			
			if (metaElement.getName().equals("description"))
				{
					String desc = metaElement.selectSingleNode( ".//imsmd:langstring").getText();
					module.setDescription(desc.trim());		
				}

			if (metaElement.getName().equals("keyword"))
				{
					String modkeyword = metaElement.selectSingleNode( ".//imsmd:langstring").getText();
					if(modkeyword !=null) module.setKeywords(modkeyword.trim());		
					else module.setKeywords(module.getTitle());
				}
		 }
		
		// get license information
		Element rightsElement = (Element)eleItem.selectNodes("./imsmd:lom/imsmd:rights").get(0);
		if(rightsElement != null)
		{
			Element licenseElement = rightsElement.element("description");
			String licenseUrl = licenseElement.selectSingleNode( ".//imsmd:langstring").getText();
			if(licenseUrl != null)
			{
				buildLicenseInformation(module,licenseUrl);
			}
		}	
		else
		{
			//default to Fair Use Exception
			module.setLicenseCode(MOD_LICENSE_CODE);
			module.setCcLicenseUrl(MOD_LICENSE_URL);
		}
		createModule(module);

//		build sections
		List sectionsList = eleItem.elements( "item" );
		System.out.println("sections list " + sectionsList.size());
		 for (Iterator iter = sectionsList.iterator(); iter.hasNext();) {
			Element element = (Element) iter.next();
			if (element.attributeValue("identifier").startsWith("ITEM"))
			{
				buildSection(element, document, module);
				
			}
//			next steps add by rashmi 05/03/06
			else if (element.attributeValue("identifier").startsWith("NEXTSTEPS"))
			{
				buildWhatsNext(element,document,module);				
			}
		}

if (m_logger.isInfoEnabled())
	m_logger.info("Exiting buildModule...");
}

	/*
	 * build license information
	 * add by rashmi
	 */	
		
	private void buildLicenseInformation(Module module,String licenseUrl)
	{
		int lcode = MOD_LICENSE_CODE ;
					
		if(licenseUrl.startsWith("Copyright (c)"))
		{
			 lcode = MOD_LICENSE_COPYRIGHT_CODE;			
		}else if(licenseUrl.startsWith("Public Domain"))
		{
			lcode = MOD_LICENSE_PD_CODE;
			licenseUrl = moduleDB.fetchCcLicenseUrl(licenseUrl);
		}else if(licenseUrl.startsWith("Creative Commons"))
		{
			lcode = MOD_LICENSE_CC_CODE;
			//remove "creative commons" phrase from the name
			licenseUrl = licenseUrl.substring(17);
			licenseUrl = moduleDB.fetchCcLicenseUrl(licenseUrl.trim());
		}
		module.setLicenseCode(lcode);
		module.setCcLicenseUrl(licenseUrl);
		
	}
	/*
	 * build whats next
	 * added by rashmi
	 */
	private void buildWhatsNext(Element eleItem,Document  document,Module module) throws Exception
	{
		Attribute identifierref = eleItem.attribute("identifierref");
		Element eleRes;

		if (identifierref != null) {
			eleRes = getResource(identifierref.getValue(), document);
			String hrefVal = eleRes.attributeValue("href");
			String nextsteps = readFromFile(new File(getUnzippeddirpath() + File.separator+ hrefVal));
			module.setWhatsNext(nextsteps);
			ModuleDateBean mdbean = new ModuleDateBean();
			mdbean.setModuleId(module.getModuleId().intValue());
			mdbean.setModule(module);
			mdbean.setModuleShdate(module.getModuleshdate());
			moduleDB.updateModuleDateBean(mdbean);
		}

	}

	/**
	 * creates the module
	 * @param module Module
	 */
	private void createModule(Module module)throws Exception {
		if (m_logger.isInfoEnabled())
			m_logger.info("Entering createModule...");

		//String courseId = PortalService.getCurrentSiteId();
		String courseId =ToolManager.getCurrentPlacement().getContext();
		String userId = UserDirectoryService.getCurrentUser().getEid();
		String firstName = UserDirectoryService.getCurrentUser()
				.getFirstName();
		String lastName = UserDirectoryService.getCurrentUser()
				.getLastName();

		module.setReqAttr(true);
		module.setUserId(userId);
		module.setCreatedByFname(firstName);
		module.setCreatedByLname(lastName);
  	    //module.setInstitute("");
		module.setModuleshdate(getModuleShdates());
		moduleDB.addModule(module, getModuleShdates(), userId, courseId);
		if (m_logger.isInfoEnabled())
			m_logger.info("Exiting createModule...");
	}

	/**
	 * Builds section for each item under module item
	 * @param eleItem item element
	 * @param document document
	 * @param module Module
	 * @throws Exception
	 */
	private void buildSection(Element eleItem, Document document, Module module)
			throws Exception {
		if (m_logger.isInfoEnabled())
			m_logger.info("Entering buildSection...");

		Attribute identifier = eleItem.attribute("identifier");

		Attribute identifierref = eleItem.attribute("identifierref");
		Element eleRes;

		Section section = new Section();
		String dataPath = null;

		List elements = eleItem.elements();
		for (Iterator iter = elements.iterator(); iter.hasNext();) {
			Element element = (Element) iter.next();

			//title
			if (element.getQualifiedName().equalsIgnoreCase("title")) {
				section.setTitle(element.getTextTrim());
			}
			//item
			else if (element.getQualifiedName().equalsIgnoreCase("item")) {
			}
			//metadata
			else if (element.getQualifiedName().equalsIgnoreCase("imsmd:lom")){
//				 add by rashmi on 5/2/06 to import section instructions
				Element descEle = (Element) element.selectSingleNode(".//imsmd:description");
				if (descEle != null) {
					List eleMetDescList = descEle.elements();

					for (Iterator metDescEleIter = eleMetDescList.iterator(); metDescEleIter.hasNext();) {
						Element metChldEle = (Element) metDescEleIter.next();

						if (metChldEle.getQualifiedName().equals("imsmd:langstring")) {
							String instr = metChldEle.getText();
							section.setInstr(instr.trim());
							}
						}
				}
				// add end

			}
		}

		if (identifierref != null) {
			eleRes = getResource(identifierref.getValue(), document);
			if (eleRes != null) {
				Attribute resTypeAttr = eleRes.attribute("type");
				if (resTypeAttr != null
						&& resTypeAttr.getValue().trim().equalsIgnoreCase(
								"webcontent")) {
					Attribute resHrefAttr = eleRes.attribute("href");
					boolean refHrefValExis = false;
					if (resHrefAttr != null) {
						refHrefValExis = true;
						String hrefVal = resHrefAttr.getValue();

						dataPath = createSection(module, section, hrefVal);
					}

					//resource elements - <file>
					List resElements = eleRes.elements();
					for (Iterator iter = resElements.iterator(); iter.hasNext();) {
						Element element = (Element) iter.next();
						if (element.getQualifiedName().equalsIgnoreCase("file")) {
							Attribute hrefAttr = element.attribute("href");
							if (refHrefValExis
									&& hrefAttr.getValue().trim()
											.equalsIgnoreCase(
													resHrefAttr.getValue()
															.trim())) {
								//Do nothing section already added
							} else {
								//upload the file - assuming this is part of
								// the section(example images)
								uploadSectionDependentFile(hrefAttr.getValue()
										.trim());
							}
//							if (!refHrefValExis) {
//							}
						}
					}
				}
				//save section
				//Mallika - line below changes to send dirs
				sectionDB.addSection(module, section, dataPath, getHomedirpath(), getMeletedocsdirpath());
			}
		}

		if (m_logger.isInfoEnabled())
			m_logger.info("Exiting buildSection...");
	}

	/**
	 * creates section dependent file
	 * @param hrefVal href value of the item
	 */
	private void uploadSectionDependentFile(String hrefVal) {
		try {
			String instr_id = UserDirectoryService.getCurrentUser().getId();
		//	String courseId = PortalService.getCurrentSiteId();
			String courseId =ToolManager.getCurrentPlacement().getContext();
			
			String filename = null;
			if (hrefVal.lastIndexOf('\\') != -1)
				filename = hrefVal.substring( hrefVal.lastIndexOf('\\') + 1);
			else if (hrefVal.lastIndexOf('/') != -1)
				filename = hrefVal.substring( hrefVal.lastIndexOf('/') + 1);
			if (filename != null && filename.trim().length() > 0){

				//Mallika - comments beg
				/*File uploadDir = new File(getHomedirpath()
						+ File.separator +"meleteDocs"+ File.separator +"instr_"
						+ instr_id + File.separator
						+ "course_" + courseId + File.separator
						+ "uploads");*/
				//Mallika - comments end
                //Mallika - comments beg
				/*File uploadDir = new File(getHomedirpath()
						+ File.separator +"meleteDocs"
						+ File.separator
						+ "course_" + courseId + File.separator
						+ "uploads");*/
				//Mallika - comments end
				//Mallika - new code beg
				File uploadDir = new File(getMeletedocsdirpath()
						+ File.separator
						+ "course_" + courseId + File.separator
						+ "uploads");
				//Mallika - new code end
				if (!uploadDir.exists())
					uploadDir.mkdirs();

				String uploadFilePath = uploadDir.getAbsolutePath() + File.separator+ filename;

				createFile(getUnzippeddirpath() + File.separator
						+ hrefVal,
						uploadFilePath);
			}
		} catch (Exception e) {
			if (m_logger.isErrorEnabled())
				m_logger.error("ExportMeleteModules : uploadSectionDependentFile() :"+ e.toString());
		}

	}

	/**
	 * creates the section
	 * @param module Module
	 * @param section Section
	 * @param hrefVal href value of the item
	 * @return @throws
	 *         MalformedURLException
	 * @throws UnknownHostException
	 * @throws MeleteException
	 * @throws Exception
	 */
	private String createSection(Module module, Section section, String hrefVal)
			throws MalformedURLException, UnknownHostException,
			MeleteException, Exception {
		if (m_logger.isInfoEnabled())
			m_logger.info("Entering createSection...");

		String dataPath;
	//	String courseId = PortalService.getCurrentSiteId();
		String courseId =ToolManager.getCurrentPlacement().getContext();
		String userId = UserDirectoryService.getCurrentUser().getEid();
		String firstName = UserDirectoryService.getCurrentUser()
				.getFirstName();
		String lastName = UserDirectoryService.getCurrentUser()
				.getLastName();

		section.setTextualContent(true);
		section.setCreatedByFname(firstName);
		section.setCreatedByLname(lastName);

		dataPath = createDataPath(userId, courseId, module);

		//link
		if (hrefVal.startsWith("http://") || hrefVal.startsWith("https://")) {
			//getAddSectionPage().validateLink(hrefVal.trim());
			section.setLink(hrefVal.trim());
			section.setContentType("typeLink");
		}
		//html file
		else if (hrefVal.lastIndexOf('.') != -1
				&& (hrefVal.substring(hrefVal.lastIndexOf('.') + 1)
						.equalsIgnoreCase("html") || hrefVal.substring(
						hrefVal.lastIndexOf('.') + 1).equalsIgnoreCase("htm"))) {

			section.setContentType("typeEditor");
			createContentFile(new File(getUnzippeddirpath() + File.separator
					+ hrefVal), module, section);
		}
		//uploaded file
		else {
			//getAddSectionPage().validateUploadFileName(hrefVal.trim());
			section.setContentType("typeUpload");
			createUploadedFile(new File(getUnzippeddirpath() + File.separator
					+ hrefVal), hrefVal, section);
		}

		if (m_logger.isInfoEnabled())
			m_logger.info("Exiting createSection...");

		return dataPath;
	}

	/**
	 * gets the resource element
	 * @param resName resource name
	 * @param document document
	 * @return resource element
	 * @throws Exception
	 */
	private Element getResource(String resName, Document document)
			throws Exception {
		if (m_logger.isInfoEnabled())
			m_logger.info("Entering getResource...");

		Map uris = new HashMap();
		uris.put("imscp", DEFAULT_NAMESPACE_URI);
		uris.put("imsmd", IMSMD_NAMESPACE_URI);

		//resource
		XPath xpath = document
				.createXPath("/imscp:manifest/imscp:resources/imscp:resource[@identifier = '"
						+ resName + "']");
		xpath.setNamespaceURIs(uris);

		Element eleRes = (Element) xpath.selectSingleNode(document);

		if (m_logger.isInfoEnabled())
			m_logger.info("Exiting getResource...");

		return eleRes;
	}


	/**
	 *
	 * create an instance of moduleshdates. Revised to open a course for one
	 * year by default --Rashmi 12/6 Revised on 12/20 Rashmi to set start
	 * default time as 8:00 am and end date time as 11:59 pm
	 */
	private ModuleShdates getModuleShdates() {
		if (moduleShdates == null) {
			moduleShdates = new ModuleShdates();
			GregorianCalendar cal = new GregorianCalendar();
			cal.set(Calendar.HOUR, 8);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.AM_PM, Calendar.AM);
			moduleShdates.setStartDate(cal.getTime());
			cal.add(Calendar.YEAR, 1);
			cal.set(Calendar.HOUR, 11);
			cal.set(Calendar.MINUTE, 59);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.AM_PM, Calendar.PM);
			moduleShdates.setEndDate(cal.getTime());
		}
		return moduleShdates;
	}

	/**
	 * @return datapath for storing uploaded file or new content file Directory
	 *         structure is Instructor |_ Course |_Images |_Module
	 *         |_Section_seq.html
	 *
	 */
	protected String createDataPath(String instr_id, String courseId,
			Module module) {
		StringBuffer dataPath = new StringBuffer();

		//Mallika - comments beg
		/*dataPath.append(getHomedirpath() + File.separator + "meleteDocs"
				+ File.separator + "instr_" + instr_id + File.separator
				+ "course_" + courseId + File.separator);*/
		//Mallika - comments end
		//Mallika - comments beg
		/*dataPath.append(getHomedirpath() + File.separator + "meleteDocs"
				+ File.separator
				+ "course_" + courseId + File.separator);*/
		//Mallika - comments end
        //Mallika - new code beg
		dataPath.append(getMeletedocsdirpath()
				+ File.separator
				+ "course_" + courseId + File.separator);
		//Mallika - new code end

		dataPath.append("module_" + module.getModuleId() + File.separator);

		return dataPath.toString();
	}

	/**
	 *
	 * uploaded or new content written file is temp stored at c:\\uploads.
	 * filename format of temporary file is moduleidSectionTitle.html later on,
	 * when saving module, this file will be stored under right directory
	 * structure under module dir with name as section_"seq".html
	 *
	 * IMP NOTE: NEED TO READ IP ADDRESS FROM SESSION OR SOMEWHERE ELSE
	 */
	private void createContentFile(File file, Module module, Section section)throws Exception{
		//save uploaded img inside content editor to destination directory
		String contentEditor = readFromFile(file);
		String checkforimgs = contentEditor;
		int imgindex = -1;

		String imgSrcPath, imgName, imgLoc;

		while (checkforimgs != null
				&& (imgindex = checkforimgs.indexOf("<img")) != -1) {
			checkforimgs = checkforimgs.substring(imgindex);
			checkforimgs = checkforimgs.substring(checkforimgs.indexOf("src"));

			int startSrc = checkforimgs.indexOf("\"") + 1;
			int endSrc = checkforimgs.indexOf("\"", startSrc);
			imgSrcPath = checkforimgs.substring(startSrc, endSrc);
			imgName = imgSrcPath.substring(imgSrcPath.lastIndexOf("/") + 1);

			if (!imgSrcPath.startsWith("http://")) {

			//	String courseId = PortalService.getCurrentSiteId();
				String courseId =ToolManager.getCurrentPlacement().getContext();
				String instr_id = UserDirectoryService.getCurrentUser().getEid();

				checkforimgs = checkforimgs.substring(endSrc);

				//Mallika - comments beg
				/*String replacementStr = ServerConfigurationService
						.getServerUrl()
						+ "/meleteDocs/instr_"
						+ instr_id
						+ "/course_"
						+ courseId + "/uploads/" + imgName;*/
				//Mallika - comments end

				//Mallika - new code beg
				String replacementStr = ServerConfigurationService
				.getServerUrl()
				+ "/meleteDocs"
				+ "/course_"
				+ courseId + "/uploads/" + imgName;
				//Mallika - new code end

				Pattern pattern = Pattern.compile(imgSrcPath);

				// Replace all occurrences of pattern in input
				Matcher matcher = pattern.matcher(contentEditor);
				contentEditor = matcher.replaceAll(replacementStr);
			}
			imgindex = -1;

		}

        //Mallika - changing line below to use new reference
		//String fname = new String(getHomedirpath() + File.separator + "uploads"
		//		+ File.separator + module.getModuleId().toString()
		//		+ section.getTitle() + ".html");
        String fname = new String(getHomedirpath() + File.separator + "uploads"
				+ File.separator + module.getModuleId().toString()
				+ "section_temp.html");
		PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(
				fname)));
		out.write(contentEditor);
		out.flush();
		out.close();
	}

	/**
	 * create uploaded file
	 *
	 * @param uploadFile
	 *            uploaded file
	 * @param hrefVal
	 *            href value
	 * @param section
	 *            Section
	 * @throws Exception
	 */
	private void createUploadedFile(File uploadFile, String hrefVal,
			Section section) throws Exception {
		String uploadedFileName = null;
		if (hrefVal.indexOf("\\") != -1) {
			uploadedFileName = hrefVal.substring(hrefVal.lastIndexOf("\\") + 1);
		} else {
			uploadedFileName = hrefVal.substring(hrefVal.lastIndexOf("/") + 1);
		}

        //Mallika - changing lines below to use new reference
		File uFile = new File(getHomedirpath() + File.separator + "uploads"
				+ File.separator + uploadedFileName);

		createFile(uploadFile.getAbsolutePath(),
				getHomedirpath() + File.separator + "uploads" + File.separator
						+ uploadedFileName);

		// check filesize
		double size = uFile.length() / 1024;

		section.setUploadPath(uploadedFileName);
	}



	/**
	 * gets UUID
	 * @return - returns the UUID
	 */
	private UUID getUUID() {
		return UUIDGenerator.getInstance().generateRandomBasedUUID();
	}


	/**
	 * creates organizations element
	 * @return returns organizations element
	 */
	private Element createOrganizations(){
		return createDefaultNSElement("organizations", "organizations");
	}


	/**
	 * creates resources element
	 * @return returns resources element
	 */
	private Element createResources(){

		return createDefaultNSElement("resources", "resources");
	}

	/**
	 * add organization for melete modules
	 * @param organizations - organizations element
	 */
	private Element addOrganization(Element organizations) {
		Element organization = organizations.addElement("organization");
		organization.addAttribute("identifier", "MF01_ORG1_MELETE");
		organization.addAttribute("structure", "hierarchical");

		return organization;
	}


	/**
	 * reading characters from file
	 * @param contentfile - file to read
	 * @return content of the file
	 */
	private String readFromFile(File contentfile) throws Exception{
		StringBuffer lines= new StringBuffer();
		FileInputStream fis = null;
		try{
			fis = new FileInputStream(contentfile);
			int len;

			byte buf[] = new byte[1];
			while ((len = fis.read(buf)) > 0) {
				String temp = new String(buf);
				lines.append(temp);
			}
			return lines.toString();
	  	}catch(Exception ex){
	  		throw ex;
	  		}finally{
	  		if (fis != null)
	  			fis.close();
	  		}
	}

	/**
	 * replace image path in the section content for uploaded images thru
	 * content editor and create the image files under resources/images
	 * @param secContent
	 * @param imagespath
	 * @param resource
	 * @param homeDirPath
	 * @return the content with modifed image path
	 */
	private String replaceImagePath(String secContent, String imagespath, Element resource, String homeDirPath)throws Exception{
		StringBuffer strBuf = new StringBuffer();
		String checkforimgs = secContent;
		int imgindex = -1;

		String imgSrcPath, imgName, imgLoc;
		String modifiedSecContent = new String(secContent);


		try {
			File imagesDir = new File(imagespath);

			while(checkforimgs !=null && (imgindex = checkforimgs.indexOf("<img")) != -1){
				checkforimgs = checkforimgs.substring(imgindex);
				checkforimgs = checkforimgs.substring(checkforimgs.indexOf("src"));

				int startSrc = checkforimgs.indexOf("\"")+1;
				int endSrc = checkforimgs.indexOf("\"", startSrc);
				imgSrcPath = checkforimgs.substring(startSrc, endSrc);
				imgName = imgSrcPath.substring(imgSrcPath.lastIndexOf("/")+1);


				if (imgSrcPath.indexOf("meleteDocs") != -1){
					imgLoc = imgSrcPath.substring(imgSrcPath.indexOf("meleteDocs"));;


					if (!imagesDir.exists())
						imagesDir.mkdir();

					//create image file under resources/images
					createFile(homeDirPath +File.separator+ imgLoc, imagesDir.getAbsolutePath()+File.separator+ imgName);


					String patternStr = imgSrcPath;
					String replacementStr = "images/"+ imgName;
					Pattern pattern = Pattern.compile(patternStr);

					// Replace all occurrences of pattern in input
					Matcher matcher = pattern.matcher(modifiedSecContent);
					modifiedSecContent = matcher.replaceAll(replacementStr);

					//add image to resources element
					Element file = resource.addElement("file");
					file.addAttribute("href", "resources/images/"+ imgName);
				}
			}
		} catch (Exception e) {
			throw e;
		}

		return modifiedSecContent;
	}

	/**
	 * @param moduleDB The moduleDB to set.
	 */
	public void setModuleDB(ModuleDB moduleDB) {
		this.moduleDB = moduleDB;
	}

	/**
	 * @param sectionDB The sectionDB to set.
	 */
	public void setSectionDB(SectionDB sectionDB) {
		this.sectionDB = sectionDB;
	}
	/**
	 * @return Returns the unzippeddirpath.
	 */
	protected String getUnzippeddirpath() {
		return unzippeddirpath;
	}
	/**
	 * @param unzippeddirpath The unzippeddirpath to set.
	 */
	protected void setUnzippeddirpath(String unzippeddirpath) {
		this.unzippeddirpath = unzippeddirpath;
	}
	/**
	 * @return Returns the homedirpath.
	 */
	protected String getHomedirpath() {
		return homedirpath;
	}
	/**
	 * @param homedirpath The homedirpath to set.
	 */
	protected void setHomedirpath(String homedirpath) {
		this.homedirpath = homedirpath;
	}

    /**
	 * @return Returns the meletedocsdirpath.
	 */
	protected String getMeletedocsdirpath() {
		return meletedocsdirpath;
	}
	/**
	 * @param meletedocsdirpath The meletedocsdirpath to set.
	 */
	protected void setMeletedocsdirpath(String meletedocsdirpath) {
		this.meletedocsdirpath = meletedocsdirpath;
	}


}