/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-api/src/java/org/sakaiproject/api/app/melete/TermService.java,v 1.1 2006/06/05 19:57:24 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.api.app.melete;

import java.util.Date;
import java.util.Set;

/**
 * Filename:
 * Description:
 * Author:
 * Date:
 * Copyright 2004, Foothill College
 */
public interface TermService {
	public abstract Short getTermId();

	public abstract void setTermId(Short termId);

	public abstract String getSeason();

	public abstract void setSeason(String season);

	public abstract int getYear();

	public abstract void setYear(int year);

	public abstract Date getStartDate();

	public abstract void setStartDate(Date startDate);

	public abstract Date getEndDate();

	public abstract void setEndDate(Date endDate);

	public abstract String getInstitute();

	public abstract void setInstitute(String institute);

	public abstract Set getModuleshdates();

	public abstract void setModuleshdates(Set moduleshdates);

	public abstract Set getModulestudentprivs();

	public abstract void setModulestudentprivs(Set modulestudentprivs);

	public abstract Set getCoursemodules();

	public abstract void setCoursemodules(Set coursemodules);

	public abstract String toString();
}