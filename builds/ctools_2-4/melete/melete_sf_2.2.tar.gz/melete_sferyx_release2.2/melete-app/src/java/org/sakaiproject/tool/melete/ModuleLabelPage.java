/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-app/src/java/org/sakaiproject/tool/melete/ModuleLabelPage.java,v 1.1 2006/06/05 19:57:24 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/

package org.sakaiproject.tool.melete;

import java.io.Serializable;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.sakaiproject.api.app.melete.CoursePrefsService;

//import org.sakaiproject.jsf.ToolBean;
/**
 * @author Mallika
 * Created on Apr 21, 2005
 *
 */
public class ModuleLabelPage implements Serializable/*,ToolBean*/{

	// attributes
	int count;
	private String mval;
	String courseId;
	private CoursePrefsService coursePrefsService;
	 protected Log logger = LogFactory.getLog(ModuleLabelPage.class);


	/**
	 * constructor
	 */
	public ModuleLabelPage() {
		//logger.info("Executing ModuleLabelPage constructor");

	}

	public void setMval(String mval)
	{
		this.mval = mval;
	}

	public String getMval()
	{
		//logger.info("coming to getmval");
		FacesContext ctx = FacesContext.getCurrentInstance();
	  	Map sessionMap = ctx.getExternalContext().getSessionMap();
	  	courseId = (String)sessionMap.get("courseId");
	  	//logger.info("Got course id "+courseId);
		mval = getCoursePrefsService().getModuleLabel(courseId);
		//logger.info("Got mlabel "+mval);
		return mval;
	}

	public String save()
	{
		//logger.info("Coming to save");
		FacesContext ctx = FacesContext.getCurrentInstance();
	  	Map sessionMap = ctx.getExternalContext().getSessionMap();
	  	courseId = (String)sessionMap.get("courseId");
	  	//logger.info("Courseid "+courseId+" modlabel is "+this.mval);
	  	LabelValidator lv = new LabelValidator();
	  	lv.isValidLabel(this.mval);
	  	try
		{
	  	  getCoursePrefsService().setModuleLabel(courseId, this.mval);
		}
	  	catch (Exception e)
		{
	  		logger.error("Error setting module label "+e.toString());
		}
	  	//logger.info("set module label");
	  	FacesMessage msg =
	  		new FacesMessage("Module Label Message", "Label has been successfully changed.");
	  	msg.setSeverity(FacesMessage.SEVERITY_INFO);
	  	ctx.addMessage(null,msg);
	    return "modules_author_manage";
	}

	public String cancel()
	{
		return "modules_author_manage";
	}

	/**
	 * @return Returns the CoursePrefsService.
	 */
	public CoursePrefsService getCoursePrefsService() {
		return coursePrefsService;
	}
	/**
	 * @param CoursePrefsService The CoursePrefsService to set.
	 */
	public void setCoursePrefsService(CoursePrefsService coursePrefsService) {
		this.coursePrefsService = coursePrefsService;
	}
	/**
	 * @return Returns the logger.
	 */

	public void setLogger(Log logger) {
		this.logger = logger;
	}
}
