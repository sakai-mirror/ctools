/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-app/src/java/org/sakaiproject/tool/melete/ListAuthModulesPage.java,v 1.3 2006/06/19 19:23:20 mallikat Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 *
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.opensource.org/licenses/ecl1.php
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*
**********************************************************************************/

package org.sakaiproject.tool.melete;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.sakaiproject.api.app.melete.*;

import java.util.*;

import javax.faces.component.*;
import javax.faces.event.*;
import java.io.Serializable;

import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.application.FacesMessage;


//import com.sun.faces.util.Util;
import org.sakaiproject.component.app.melete.*;

import org.sakaiproject.api.app.melete.ModuleService;
//import org.sakaiproject.jsf.ToolBean;
/**
 * Gets the module beans for author
 *
 * @version 	1.00 	08 Mar 2005
 * @author 	Mallika M Thoppay
 */
/*
 * @author 	Murthy Tanniru	08 Mar 2005
 * 			Fixed the bug #91 Section bread crumbs are not shown as links
 * 			on edit module page
 * Mallika - 3/22/05 Fixed bug #375 in edit action method
 * Mallika - 3/24/05 Fixed bug #427 in inactivate action method
  * Mallika - 3/30/05 Added resetValues method and put != null check in constructor
  * Rashmi - 4/7/05  add functionality to what's next revised.
  * Rashmi - 4/8/05  Isnull() to render + or view image for next steps.
  * Mallika - 4/20/05 - Added method to delete module and section
  * Mallika - 4/22/05 - Added the association to display module label
  * Mallika - 5/19/05 - Added functionality to reset delete page
  * Mallika - 6/1/05 - Fixed the invalid format msg bug and lollipop persists bug
  * Mallika - 6/6/06 - Adding functionality to expand all modules
  * Mallika - 6/7/06 - Adding functionality to change editmodule and editsection
 */
public class ListAuthModulesPage implements Serializable/*,ToolBean*/ {

/** Dependency:  The logging service. */
	  protected Log logger = LogFactory.getLog(ListAuthModulesPage.class);
	  private List moduleDateBeans = null;
	  private List moduleDatePrivBeans = null;
	  private List errModuleIds = null;

	  /** identifier field */
      private int showModuleId;
      private String formName;
      private Date currentDate;
      private boolean selectedSection;
      private boolean invFlag;
      private boolean nomodsFlag;
      private boolean expandAllFlag;

	  //This needs to be set later using Utils.getBinding
	  String courseId;
	  String userId;
      // rashmi added
	  int count;
	  int selectedModIndex;
	  //List selectedModIndices;
	  boolean moduleSelected;
	  int selectedSecIndex;
	  boolean sectionSelected;
      private ModuleService moduleService;
      private CoursePrefsService coursePrefsService;
      private boolean trueFlag = true;
      private List nullList = null;
      // added by rashmi on apr 8
      private String isNull = null;
      private String mval;
      private UIData table;

      public UIData getTable() {
            return table;
      }


      public void setTable(UIData table) {
            this.table = table;
      }

	  public ListAuthModulesPage() {

	  	FacesContext context = FacesContext.getCurrentInstance();
	  	Map sessionMap = context.getExternalContext().getSessionMap();
	  	courseId = (String)sessionMap.get("courseId");
		userId = (String)sessionMap.get("userId");
		invFlag = false;
		nomodsFlag = false;
	  	setShowModuleId(-1);
        count =0;
	  	selectedModIndex= -1;
	    moduleSelected= false;
	    selectedSecIndex = -1;
	    sectionSelected = false;
	    expandAllFlag = false;
	  }

	  public void resetValues()
	  {
	  	setShowModuleId(-1);
	  	errModuleIds = null;
	  	invFlag = false;
		nomodsFlag = false;
		expandAllFlag = false;
		count =0;
		selectedModIndex= -1;
		moduleSelected= false;
		selectedSecIndex = -1;
		sectionSelected = false;
		FacesContext ctx = FacesContext.getCurrentInstance();
		ValueBinding binding =
            Util.getBinding("#{deleteModulePage}");
		DeleteModulePage dmPage = (DeleteModulePage)
        binding.getValue(ctx);
        dmPage.setMdbean(null);
        dmPage.setModuleSelected(false);
        dmPage.setSection(null);
        dmPage.setSectionSelected(false);
	  }

	  public void resetDateFlags()
	  {
	  	for (ListIterator i = moduleDateBeans.listIterator(); i.hasNext(); )
	  	{
	        ModuleDateBean mdbean = (ModuleDateBean) i.next();
	        logger.info("SETTING date flag to false");
	        mdbean.setDateFlag(false);
	  	}

	  }


      /**
	   * @return Returns the ModuleService.
	   */
	  public ModuleService getModuleService() {
		return moduleService;
	  }

	 /**
	  * @param moduleService The moduleService to set.
	  */
	  public void setModuleService(ModuleService moduleService) {
		this.moduleService = moduleService;
	  }
	  public boolean  getTrueFlag() {
	  	return trueFlag;
	  }

	  public void setTrueFlag(boolean  trueFlag) {
	  	this.trueFlag = trueFlag;
	  }
	  public List  getNullList() {
	  	return nullList;
	  }

	  public void setNullList(List nullList) {
	  	this.nullList = nullList;
	  }

	  public void setMval(String mval)
	  {
			this.mval = mval;
	  }

	  public String getMval()
	  {
		  return mval;
	   }
	  /*
	   * adding listener
	   */
	  public void selectedModuleSection(ValueChangeEvent event)throws AbortProcessingException
		{
	  		FacesContext context = FacesContext.getCurrentInstance();
			UIInput mod_Selected = (UIInput)event.getComponent();
			if (((Boolean)mod_Selected.getValue()).booleanValue() == true)
			  count++;
			else
			  count--;

			logger.info("listener catches as selected at a time" +count);

			String selclientId = mod_Selected.getClientId(context);
			logger.info("Sel client ID is "+selclientId);
			selclientId = selclientId.substring(selclientId.indexOf(':')+1);
			selclientId = selclientId.substring(selclientId.indexOf(':')+1);
			String modId = selclientId.substring(0,selclientId.indexOf(':'));
			selectedModIndex = Integer.parseInt(modId);
			//selectedModIndices.add(new Integer(selectedModIndex));
			moduleSelected=true;
			return;
		}

	  public void selectedSection(ValueChangeEvent event)throws AbortProcessingException
		{
	  		FacesContext context = FacesContext.getCurrentInstance();
			UIInput sec_Selected = (UIInput)event.getComponent();
			if (((Boolean)sec_Selected.getValue()).booleanValue() == true)
			  count++;
			else
			  count--;

			logger.info("listener catches as selected at a time" +count);

			String selclientId = sec_Selected.getClientId(context);
			logger.info("Sel client ID is "+selclientId);
			selclientId = selclientId.substring(selclientId.indexOf(':')+1);
			selclientId = selclientId.substring(selclientId.indexOf(':')+1);
			String modId = selclientId.substring(0,selclientId.indexOf(':'));
			selectedModIndex = Integer.parseInt(modId);
			selclientId = selclientId.substring(selclientId.indexOf(':')+1);
			selclientId = selclientId.substring(selclientId.indexOf(':')+1);
			String sectionseq=selclientId.substring(0,selclientId.indexOf(':'));
			selectedSecIndex = Integer.parseInt(sectionseq);
			sectionSelected = true;

			return;
		}

	  public List getModuleDateBeans() {
	  	//logger.info("ListAuthModulesPage: Coming to getModuleDateBeans");
	  	setCurrentDate(Calendar.getInstance().getTime());
	  	FacesContext context = FacesContext.getCurrentInstance();

     	boolean flagsReset = false;
	  	try {
	  		ModuleService modServ = getModuleService();
	  		moduleDateBeans = modServ.getModuleDateBeans(courseId);
	  		Iterator itr = context.getMessages();
		  	while (itr.hasNext())
		  	{
		  	 String msg = ((FacesMessage)itr.next()).getDetail();
		  	  System.out.println(msg);
		  	  if (msg.equals("Input data is not in the correct format."))
		  	  {
		  	    logger.info("If condn satisfied");
		  	    resetDateFlags();
		  	    flagsReset = true;
		  	  }
		  	  else
		  	  {
		  	    break;
		  	  }
		  	}
	  		 //selectedModIndices = new ArrayList();
	  		for (ListIterator i = moduleDateBeans.listIterator(); i.hasNext(); ) {
		        ModuleDateBean mdbean = (ModuleDateBean) i.next();
		        //If there is an invalid format message, don't set lollipop
		        if (flagsReset == false)
		        {
		          if (errModuleIds != null)
		          {
		        	if (errModuleIds.size() > 0)
		        	{
		        		for (ListIterator l = errModuleIds.listIterator(); l.hasNext();)
		        		{
		        		  ModuleDateBean errmdbean = (ModuleDateBean) l.next();
		        		  if (errmdbean.getModuleId() == mdbean.getModuleId())
		        		  {
		        			mdbean.setDateFlag(true);
		        			mdbean.getModuleShdate().setStartDate(errmdbean.getModuleShdate().getStartDate());
		        			mdbean.getModuleShdate().setEndDate(errmdbean.getModuleShdate().getEndDate());
		        		  }
		        		}

		        	}
		          }
		        }

		        if (mdbean.getModuleShdate().isHideFlag() == true)
		        {
		        	invFlag = true;
		        }

	  		}
	  	}catch (Exception e)
		{
	  		//e.printStackTrace();
	  		logger.error(e.toString());
		}
		if (moduleDateBeans.size() == 0)
	  	{
	  	  nomodsFlag = true;
	  	  FacesContext ctx = FacesContext.getCurrentInstance();
  		  addNoModulesMessage(ctx);
	  	}
		else
		{
			nomodsFlag = false;
		}
		mval = getCoursePrefsService().getModuleLabel(courseId);
		if (mval == null)
		{
			mval = "Module ";
		}
		setMval(mval);
	  	return moduleDateBeans;
	  }



	  public Date getCurrentDate() {
	  	return currentDate;
	  }

	  public void setCurrentDate(Date currentDate) {
	  	this.currentDate = currentDate;
	  }

	  public void setModuleDateBeans(List moduleDateBeansList) {
	    moduleDateBeans = moduleDateBeansList;
	  }


	  public int getShowModuleId() {
	        return this.showModuleId;
	  }

	  public void setShowModuleId(int moduleId) {
	        this.showModuleId = moduleId;
	  }

	  public boolean getSelectedSection()
	  {
	    	return selectedSection;
	  }

	  public void setSelectedSection(boolean selectedSection)
	  {
	    	this.selectedSection = selectedSection;
	  }
	  public boolean getInvFlag()
	  {
	    	return invFlag;
	  }

	  public void setInvFlag(boolean invFlag)
	  {
	    	this.invFlag = invFlag;
	  }
	  public boolean getNomodsFlag() {
	  	return nomodsFlag;
	  }

	  public void setNomodsFlag(boolean nomodsFlag) {
	  	this.nomodsFlag = nomodsFlag;
	  }

      public boolean getExpandAllFlag() {
	  	return expandAllFlag;
	  }

	  public void setExpandAllFlag(boolean expandAllFlag) {
	  	this.expandAllFlag = expandAllFlag;
	  }


	  public String showAuthSections() {
	  	//logger.info("SHOW AUTH SECTIONS BEING INVOKED: ListAuthModulesPage ");
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	 UIViewRoot root = ctx.getViewRoot();
	        UIData table = (UIData)
	            root.findComponent("listauthmodulesform").findComponent("table");
	        ModuleDateBean mdbean = (ModuleDateBean) table.getRowData();
	        ValueBinding binding =
	            Util.getBinding("#{listAuthModulesPage}");
	        ListAuthModulesPage lamPage = (ListAuthModulesPage)
	            binding.getValue(ctx);
            //logger.info("SHOW MODULE id is "+mdbean.getModuleId());
	        lamPage.setShowModuleId(mdbean.getModuleId());

	  	return "list_auth_modules";
	  }
	  public String hideAuthSections() {
	  	setShowModuleId(-1);
	  	setExpandAllFlag(false);
	  	return "list_auth_modules";
	  }

      //Mallika - 6/6/06 - adding this method to expand all modules
      public String expandAllAction() {
	  	//logger.info("SHOW ALL MODULES BEING INVOKED: ListAuthModulesPage ");
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	       ValueBinding binding =
	            Util.getBinding("#{listAuthModulesPage}");
	        ListAuthModulesPage lamPage = (ListAuthModulesPage)
	            binding.getValue(ctx);
            //logger.info("SHOW MODULE id is "+mdbean.getModuleId());
	        lamPage.setExpandAllFlag(true);

	  	return "list_auth_modules";
	  }

      public String collapseAllAction() {
	  	//logger.info("SHOW ALL MODULES BEING INVOKED: ListAuthModulesPage ");
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	       ValueBinding binding =
	            Util.getBinding("#{listAuthModulesPage}");
	        ListAuthModulesPage lamPage = (ListAuthModulesPage)
	            binding.getValue(ctx);
            //logger.info("SHOW MODULE id is "+mdbean.getModuleId());
	        lamPage.setExpandAllFlag(false);
	        lamPage.setShowModuleId(-1);

	  	return "list_auth_modules";
	  }
	  //Mallika - new code end

	  /*
	   * Revised by Rashmi to include module number
	   *
	   * Revised by Rashmi to point to editmodulesections.jsp page
	   * instead of edit_section nav rule.
	   */
	  public String editAction() {

	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	logger.info("EDIT ACTION BEING INVOKED: ListAuthModulesPage " + count);

	  	if (count >= 2)
	    {
	  	  addSelectErrorMessage(ctx);
	  	  count=0;
	  	  //logger.info("EDIT ACTION BEING INVOKED : ListAuthModulesPage error encountered");
	  	  moduleSelected = false;
	  	  sectionSelected = false;
	  	  return "list_auth_modules";
	  	 }
		  count = 0;
		  //logger.info("EDIT ACTION BEING INVOKED : ListAuthModulesPage after count check");
		  //logger.info("Section selected is "+sectionSelected);

		  // module selected
		  if(moduleSelected)
		  {
		  	ModuleDateBean mdbean = (ModuleDateBean) moduleDateBeans.get(selectedModIndex);
		 	  ValueBinding binding =
	            Util.getBinding("#{editModulePage}");
	        EditModulePage emPage = (EditModulePage)
	            binding.getValue(ctx);
	        emPage.setEditInfo(mdbean);
	        // added by rashmi to show correct module number
	        emPage.resetModuleNumber();

	        binding= Util.getBinding("#{secBcPage}");
	  	    SecBcPage sbcPage = (SecBcPage)  binding.getValue(ctx);
	  	    sbcPage.setModuleId(mdbean.getModuleId());
	  	    sbcPage.setShowSeqNo(-1);
	  	    sbcPage.setEditMode(true);
	  	    sbcPage.setShowTextOnly(false);
	  	    count=0;
	  	    moduleSelected = false;
	  	    //Mallika -3/24/05
	  	    sectionSelected = false;
	  		return "edit_module";
		  }
		  if (sectionSelected)
		  {
		  	ModuleDateBean mdbean = (ModuleDateBean) moduleDateBeans.get(selectedModIndex);
		  	SectionBean secBean = (SectionBean) mdbean.getSectionBeans().get(selectedSecIndex);
	  		ValueBinding binding =
		            Util.getBinding("#{editSectionPage}");
		     EditSectionPage esPage = (EditSectionPage)
		            binding.getValue(ctx);
		     esPage.setEditInfo((Section)secBean.getSection());
		     binding= Util.getBinding("#{secBcPage}");
		     SecBcPage sbcPage = (SecBcPage)
	  		  	binding.getValue(ctx);
	  		 sbcPage.setModuleId(mdbean.getModuleId());
	  		 sbcPage.setShowModuleId(mdbean.getModuleId());
	  		 sbcPage.setShowSeqNo(secBean.getSection().getSeqNo());
	  		 sbcPage.setEditMode(true);
	  		 sbcPage.setShowTextOnly(false);
	  		 sectionSelected = false;
	  		 //Mallika - 3/24/05
	  		 moduleSelected = false;
	  		 return "editmodulesections";
		  }
		  if ((moduleSelected == false)&&(sectionSelected == false))
		  {
		  	  addSelectOneMessage(ctx);
		  }
		  moduleSelected = false;
		  sectionSelected = false;
		  return "list_auth_modules";
	  }

	  /*
	   * Revised by Rashmi on 1/21
	   * to set module number to fix bug#211
	   */
	  public String AddModuleAction()
	  {
	  	//logger.info("add module clicked setting module to null");
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	ValueBinding binding =
		  	    Util.getBinding("#{addModulePage}");

		  	AddModulePage amPage = (AddModulePage)binding.getValue(ctx);
		  	amPage.setModuleNull();
		/*  	if(moduleDateBeans != null)
		  		amPage.setModuleNumber(moduleDateBeans.size());
		  	else amPage.setModuleNumber(1);
		  	*/
	  	return "add_module";
	  }
	  public String InactivateAction()
	  {
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	logger.info("INACTIVATE ACTION BEING INVOKED");
	  	 if (sectionSelected)
		  {
		  	addSelectModuleMessage(ctx);
		  	sectionSelected = false;
		  	moduleSelected = false;
		  	count = 0;
	  		 return "list_auth_modules";
		  }
	  	if (count >= 2)
	    {
	  	  addSelectInactivateErrorMessage(ctx);
	  	  count=0;
	  	  //Mallika - 3/24/05 added this to prevent selected value from being stored
	  	  sectionSelected = false;
	  	  moduleSelected = false;
	  	  return "list_auth_modules";
	  	 }
	    // module selected
		  if(moduleSelected)
		  {
		  	ModuleDateBean mdbean = (ModuleDateBean) moduleDateBeans.get(selectedModIndex);

		  	try
			{
		  	  int origSeqNo = mdbean.getCmod().getSeqNo();
		  	  getModuleService().archiveModule(mdbean);
		  	  addInactivateModuleMessage(ctx, origSeqNo, mdbean.getModule().getTitle());
			}
		  	catch (Exception ex)
			{
		  		logger.error(ex.toString());
			}
		  	count=0;
            //Mallika - 3/24/05 added this to prevent selected value from being stored
		  	moduleSelected = false;
			sectionSelected = false;
	  	    return "list_auth_modules";
		  }

		  if ((moduleSelected == false)&&(sectionSelected == false))
		  {
		  	  addSelectOneModuleMessage(ctx);
		  }
		  count=0;
		  moduleSelected = false;
		  sectionSelected = false;
	  	return "list_auth_modules";
	  }

	  // Revised by rashmi to put module numbers on edit page
	  /*
	   * 03/08/05 Revised by Murthy to fix bug #91 to show section bread crumbs
	   * as hot links on edit module page
	  */
	  /*public String editModule()
	  {
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	UIViewRoot root = ctx.getViewRoot();
	  	UIData table = (UIData) root.findComponent("listauthmodulesform").findComponent("table");
	  	ModuleDateBean mdbean = (ModuleDateBean) table.getRowData();
	  	ValueBinding binding = Util.getBinding("#{editModulePage}");
	  	EditModulePage emPage = (EditModulePage) binding.getValue(ctx);
	  	emPage.setEditInfo(mdbean);
	  	emPage.resetModuleNumber();
	  	binding = Util.getBinding("#{secBcPage}");
	  	SecBcPage sbcPage = (SecBcPage)
	  	binding.getValue(ctx);
	  	sbcPage.setModuleId(mdbean.getModuleId());
	  	sbcPage.setShowSeqNo(-1);
	  	sbcPage.setEditMode(true);
	  	sbcPage.setShowTextOnly(false);

	  	return "edit_module";
	  }*/

      public String redirectToEditModule()
	  {
	  	return "edit_module";
	  }

      public void editModule(ActionEvent evt)
	  {
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	UICommand cmdLink = (UICommand)evt.getComponent();
		String selclientId = cmdLink.getClientId(ctx);
		logger.info("In editModule, Sel client ID is "+selclientId);
		selclientId = selclientId.substring(selclientId.indexOf(':')+1);
		selclientId = selclientId.substring(selclientId.indexOf(':')+1);
		String modId = selclientId.substring(0,selclientId.indexOf(':'));
		int selModIndex = Integer.parseInt(modId);

        ModuleDateBean mdbean = (ModuleDateBean) moduleDateBeans.get(selModIndex);
	  	ValueBinding binding = Util.getBinding("#{editModulePage}");
	  	EditModulePage emPage = (EditModulePage) binding.getValue(ctx);
	  	emPage.setEditInfo(mdbean);
	  	emPage.resetModuleNumber();
	  	binding = Util.getBinding("#{secBcPage}");
	  	SecBcPage sbcPage = (SecBcPage)
	  	binding.getValue(ctx);
	  	sbcPage.setModuleId(mdbean.getModuleId());
	  	sbcPage.setShowSeqNo(-1);
	  	sbcPage.setEditMode(true);
	  	sbcPage.setShowTextOnly(false);

	  }


	  /*public String editSection()
	  {
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	UIViewRoot root = ctx.getViewRoot();
	  	UIData tablesec = (UIData) root.findComponent("listauthmodulesform").findComponent("table").findComponent("tablesec");
	  	SectionBean secbean = (SectionBean) tablesec.getRowData();
	  	ValueBinding binding = Util.getBinding("#{editSectionPage}");
	  	EditSectionPage esPage = (EditSectionPage)binding.getValue(ctx);
	  	esPage.setEditInfo((Section)secbean.getSection());
	  	binding = Util.getBinding("#{secBcPage}");
	  	SecBcPage sbcPage = (SecBcPage)	binding.getValue(ctx);
	  	sbcPage.setModuleId(secbean.getSection().getModuleId());
	  	sbcPage.setShowModuleId(secbean.getSection().getModuleId());
	  	sbcPage.setShowSeqNo(secbean.getSection().getSeqNo());
	  	sbcPage.setEditMode(true);
        sbcPage.setShowTextOnly(false);
	  	return "editmodulesections";
	  }*/

      public String redirectToEditSection()
	  {
	  	return "editmodulesections";
	  }

      public void editSection(ActionEvent evt)
	  {
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	UICommand cmdLink = (UICommand)evt.getComponent();
        String selclientId = cmdLink.getClientId(ctx);
		logger.info("In editSection, Sel client ID is "+selclientId);
        selclientId = selclientId.substring(selclientId.indexOf(':')+1);
		selclientId = selclientId.substring(selclientId.indexOf(':')+1);
		String modId = selclientId.substring(0,selclientId.indexOf(':'));
		int selModIndex = Integer.parseInt(modId);
		selclientId = selclientId.substring(selclientId.indexOf(':')+1);
		selclientId = selclientId.substring(selclientId.indexOf(':')+1);
		String sectionseq=selclientId.substring(0,selclientId.indexOf(':'));
		int selSecIndex = Integer.parseInt(sectionseq);
        ModuleDateBean mdbean = (ModuleDateBean) moduleDateBeans.get(selModIndex);
	  	SectionBean secBean = (SectionBean) mdbean.getSectionBeans().get(selSecIndex);

        logger.info("Section clicked on is "+secBean.getSection().getTitle());
	  	ValueBinding binding = Util.getBinding("#{editSectionPage}");
	  	EditSectionPage esPage = (EditSectionPage)binding.getValue(ctx);
	  	esPage.setEditInfo((Section)secBean.getSection());
	  	binding = Util.getBinding("#{secBcPage}");
	  	SecBcPage sbcPage = (SecBcPage)	binding.getValue(ctx);
	  	sbcPage.setModuleId(secBean.getSection().getModuleId());
	  	sbcPage.setShowModuleId(secBean.getSection().getModuleId());
	  	sbcPage.setShowSeqNo(secBean.getSection().getSeqNo());
	  	sbcPage.setEditMode(true);
        sbcPage.setShowTextOnly(false);

	  }

	  public String deleteAction() {

	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	logger.info("DELETE ACTION BEING INVOKED: ListAuthModulesPage " + count);

	  	if (count >= 2)
	    {
	  	  addSelectErrorMessage(ctx);
	  	  count=0;
	  	  //logger.info("DELETE ACTION BEING INVOKED : ListAuthModulesPage error encountered");
	  	  moduleSelected = false;
	  	  sectionSelected = false;
	  	  return "list_auth_modules";
	  	 }
		  count = 0;
		  //logger.info("DELETE ACTION BEING INVOKED : ListAuthModulesPage after count check");
		  //logger.info("Section selected is "+sectionSelected);

		  // module selected
		  if(moduleSelected)
		  {
		  	ModuleDateBean mdbean = (ModuleDateBean) moduleDateBeans.get(selectedModIndex);
		 	ValueBinding binding =
	            Util.getBinding("#{deleteModulePage}");
	        DeleteModulePage dmPage = (DeleteModulePage)
	            binding.getValue(ctx);
	        dmPage.setMdbean(mdbean);
	        dmPage.setModuleSelected(true);
	        count=0;
	  	    moduleSelected = false;
	  	    sectionSelected = false;
	  		return "delete_module";
		  }
		  if (sectionSelected)
		  {
		  	ModuleDateBean mdbean = (ModuleDateBean) moduleDateBeans.get(selectedModIndex);
		  	SectionBean secBean = (SectionBean) mdbean.getSectionBeans().get(selectedSecIndex);
		 	ValueBinding binding =
	            Util.getBinding("#{deleteModulePage}");
		  	DeleteModulePage dmPage = (DeleteModulePage)
	            binding.getValue(ctx);
	        dmPage.setSection((Section)secBean.getSection());
	        dmPage.setSectionSelected(true);
	  		/*ValueBinding binding =
		            Util.getBinding("#{editSectionPage}");
		     EditSectionPage esPage = (EditSectionPage)
		            binding.getValue(ctx);
		     esPage.setEditInfo((Section)secBean.getSection());
		     binding= Util.getBinding("#{secBcPage}");
		     SecBcPage sbcPage = (SecBcPage)
	  		  	binding.getValue(ctx);
	  		 sbcPage.setModuleId(mdbean.getModuleId());
	  		 sbcPage.setShowModuleId(mdbean.getModuleId());
	  		 sbcPage.setShowSeqNo(secBean.getSection().getSeqNo());
	  		 sbcPage.setEditMode(true);
	  		 sbcPage.setShowTextOnly(false);*/
	         count = 0;
	  		 sectionSelected = false;
	  		 //Mallika - 3/24/05
	  		 moduleSelected = false;
	  		 return "delete_module";
		  }
		  if ((moduleSelected == false)&&(sectionSelected == false))
		  {
		  	  addSelectOneDelMessage(ctx);
		  }
		  moduleSelected = false;
		  sectionSelected = false;
		  return "list_auth_modules";
	  }


	  public String saveChanges() {
	  	logger.info("SAVE CHANGES BEING INVOKED: ListAuthModulesPage");
	  	FacesContext ctx = null;
	  	ResourceBundle bundle = null;
	  	boolean dateErrFlag = false;
	  	errModuleIds = new ArrayList();
	  	try {
	  		Iterator moduleIter = moduleDateBeans.iterator();
	  		ctx = FacesContext.getCurrentInstance();
	  		bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
            		ctx.getViewRoot().getLocale());
	  		while (moduleIter.hasNext()) {
		  		ModuleDateBean mdbean = (ModuleDateBean) moduleIter.next();
		  		if (mdbean.getModuleShdate().getStartDate().compareTo(mdbean.getModuleShdate().getEndDate()) >= 0)
		  		{
		  			dateErrFlag = true;
		  			mdbean.setDateFlag(true);
		  			errModuleIds.add(mdbean);
		  			/*addDateErrorMessage(ctx);
		  		    return "list_auth_modules";*/
		  		}
		  		else
		  		{
		  			mdbean.setDateFlag(false);
		  		}
	  		}
	  		getModuleService().updateModuleDateBeans(moduleDateBeans);

	  		if (dateErrFlag == true)
	  		{
	  			addDateErrorMessage(ctx);
	  		}
	  		else
	  		{
	  		  addSaveChangesMessage(ctx);
	  		}

	  	}catch (Exception e)
		{
	  		//e.printStackTrace();
	  		logger.error(e.toString());
	  		String errMsg = bundle.getString("list_auth_modules_fail");
	  		FacesMessage msg =
		  		new FacesMessage("Error Message", errMsg);
		  	msg.setSeverity(FacesMessage.SEVERITY_ERROR);
	  		ctx.addMessage (null, msg);
			return "list_auth_modules";
		}
	  	return "list_auth_modules";
	  }

	  public String cancelChanges() {
	  	return "list_auth_modules";
	  }

	  public String viewModule() {
	  	logger.info("VIEW MODULE BEING INVOKED");
	  	/*FacesContext ctx = FacesContext.getCurrentInstance();
	  	 UIViewRoot root = ctx.getViewRoot();
	        UIData table = (UIData)
	            root.findComponent("listauthmodulesform").findComponent("table");
	        ModuleDatePrivBean mdpbean = (ModuleDatePrivBean) table.getRowData();
	        System.out.println("GETTING mdpbean");
	        ValueBinding binding =
	            Util.getBinding("#{viewModulePage}");
	        viewModulePage vPage = (viewModulePage)
	            binding.getValue(ctx);
            System.out.println("SHOW MODULE id is "+mdpbean.getModuleId());
	        vPage.setModule(mdpbean.getModule());
	      */
	  	return "view_module";
	  }

	  public String viewSection() {
	  	logger.info("VIEW SECTION BEING INVOKED");
	  	/*FacesContext ctx = FacesContext.getCurrentInstance();
	  	 UIViewRoot root = ctx.getViewRoot();
	        UIData table = (UIData)
	            root.findComponent("listauthmodulesform").findComponent("table");
	        ModuleDatePrivBean mdpbean = (ModuleDatePrivBean) table.getRowData();
	        ValueBinding binding =
	            Util.getBinding("#{viewModulePage}");
	        viewSectionPage vsPage = (viewSectionPage)
	            binding.getValue(ctx);
	        vsPage.setModule(mdpbean.getModule());
	      */
	  	return "view_section";
	  }

	  public String viewPrereqs()
	  {
	  	return "list_auth_modules";
	  }

	  /*
	   * what's next revised by rashmi on Apr 7.
	   * add functionality for what's next. This method fetches the module and initialize
	   * moduleNextStepsPage instance and navigate to module post steps page
	   */
	  public String viewNextsteps()
	  {
	  	FacesContext ctx = FacesContext.getCurrentInstance();
	  	UIViewRoot root = ctx.getViewRoot();
	  	UIData table = (UIData) root.findComponent("listauthmodulesform").findComponent("table");
	  	ModuleDateBean mdbean = (ModuleDateBean) table.getRowData();
	  	ValueBinding binding = Util.getBinding("#{moduleNextStepsPage}");
	  	ModuleNextStepsPage nextPage = (ModuleNextStepsPage) binding.getValue(ctx);
	   	nextPage.setMdBean(mdbean);
	  	return "module_post_steps";
	  }

	  /*
	   *  added by rashmi on 8 Apr
	   *  returns a string whose value is null for render comparison on the page for
	   *  + icon or view icon for next steps
	   */
	  public String getIsNull()
	  {
	  	return isNull;
	  }




	  private void addSaveChangesMessage(FacesContext ctx){
	  	FacesMessage msg =
	  		new FacesMessage("Changes Saved", "Your changes have been saved.");
	  	msg.setSeverity(FacesMessage.SEVERITY_INFO);
	  	ctx.addMessage(null,msg);
	  }

	  private void addSelectOneMessage(FacesContext ctx){
	  	FacesMessage msg =
	  		new FacesMessage("Select One", "Please select a module or section to edit.");
	  	msg.setSeverity(FacesMessage.SEVERITY_ERROR);
	  	ctx.addMessage(null,msg);
	  }
	  private void addSelectOneDelMessage(FacesContext ctx){
	  	FacesMessage msg =
	  		new FacesMessage("Select One", "Please select a module or section to delete.");
	  	msg.setSeverity(FacesMessage.SEVERITY_ERROR);
	  	ctx.addMessage(null,msg);
	  }
	  private void addSelectOneModuleMessage(FacesContext ctx){
	  	FacesMessage msg =
	  		new FacesMessage("Select One Module", "Please select a module to inactivate.");
	  	msg.setSeverity(FacesMessage.SEVERITY_ERROR);
	  	ctx.addMessage(null,msg);
	  }
	  private void addSelectModuleMessage(FacesContext ctx){
	  	FacesMessage msg =
	  		new FacesMessage("Select Module", "Please select a module. Sections cannot be inactivated.");
	  	msg.setSeverity(FacesMessage.SEVERITY_ERROR);
	  	ctx.addMessage(null,msg);
	  }

	  private void addDateErrorMessage(FacesContext ctx){
	  	FacesMessage msg =
	  		new FacesMessage("Date Error", "The start date cannot be the same as or after the end date for a module.");
	  	msg.setSeverity(FacesMessage.SEVERITY_ERROR);
	  	ctx.addMessage(null,msg);
	  }

	  private void addSelectErrorMessage(FacesContext ctx){
	  	FacesMessage msg =
	  		new FacesMessage("Select Error", "You can only select one module or section at a time.");
	  	msg.setSeverity(FacesMessage.SEVERITY_ERROR);
	  	ctx.addMessage(null,msg);
	  }
	  private void addSelectInactivateErrorMessage(FacesContext ctx){
	  	FacesMessage msg =
	  		new FacesMessage("Select Inactivate Error", "You can only select one module at a time.");
	  	msg.setSeverity(FacesMessage.SEVERITY_ERROR);
	  	ctx.addMessage(null,msg);
	  }
	  private void addNoModulesMessage(FacesContext ctx){
	  	FacesMessage msg =
	  		new FacesMessage(null, "No modules are available for the course at this time.");
	  	msg.setSeverity(FacesMessage.SEVERITY_INFO);
	  	ctx.addMessage(null,msg);
	  }
	  private void addInactivateModuleMessage(FacesContext ctx, int modSeqNo, String moduleTitle){
	  	FacesMessage msg =
	  		new FacesMessage("Inactivate Message", "You have just inactivated Module "+modSeqNo+": "+moduleTitle+". To activate in the future, click on Manage >> Restore.");
	  	msg.setSeverity(FacesMessage.SEVERITY_INFO);
	  	ctx.addMessage(null,msg);
	  }
	  /**
		 * @return Returns the CoursePrefsService.
		 */
		public CoursePrefsService getCoursePrefsService() {
			return coursePrefsService;
		}
		/**
		 * @param CoursePrefsService The CoursePrefsService to set.
		 */
		public void setCoursePrefsService(CoursePrefsService coursePrefsService) {
			this.coursePrefsService = coursePrefsService;
		}

	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Log logger) {
		this.logger = logger;
	}

}
