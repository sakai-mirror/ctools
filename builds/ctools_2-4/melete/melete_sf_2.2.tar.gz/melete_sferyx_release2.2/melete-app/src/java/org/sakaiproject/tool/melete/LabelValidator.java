/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-app/src/java/org/sakaiproject/tool/melete/LabelValidator.java,v 1.1 2006/06/05 19:57:24 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.tool.melete;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.faces.application.FacesMessage;

//import com.sun.faces.util.MessageFactory;

import java.util.ResourceBundle;

/**
 * @author Mallika
 *
 * This class validates user input for module label 
 * Mallika - 5/23/05 - Did bug fix for space code
 **/

public class LabelValidator implements Validator {
	
	public void validate(FacesContext context, UIComponent component, Object value)
	throws ValidatorException
	{
		String val = (String) value;
		val = val.trim();
		int len =val.length();
	
		if(len < 3 || len > 15)
		{
			ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
            		context.getViewRoot().getLocale());
			String errMsg = "";
	     	errMsg = bundle.getString("invalid_label_len");
	        throw new ValidatorException(new FacesMessage(errMsg));
		}
		if (!isValidLabel(val))
		{
			ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
            		context.getViewRoot().getLocale());
			String errMsg = "";
	     	errMsg = bundle.getString("invalid_label");
	        throw new ValidatorException(new FacesMessage(errMsg));
		}
	}
	/**
	 * @param title
	 * @return
	 * Revision -- 11/29 Rashmi 
	 * check if string is empty or just spaces
	 *
	 */
	public boolean isValidLabel(String label)
	{
		String[] spaces = label.split("\\s");
		
		if (spaces.length > 2)
		{
			System.out.println("Too many spaces");
			return false;
		}

		int len =label.length();
			
		for(int i=0; i < len; i++)
		{
			char c = label.charAt(i);
			
			if (!Character.isLetter(c)&&!Character.isSpace(c))
				{
					System.out.println("label is not valid.");
					return false;
				}					
		}
		return true;
	}
	

}