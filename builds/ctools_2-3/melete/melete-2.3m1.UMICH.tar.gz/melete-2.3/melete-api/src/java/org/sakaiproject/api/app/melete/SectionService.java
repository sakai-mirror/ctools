/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-api/src/java/org/sakaiproject/api/app/melete/SectionService.java,v 1.3 2006/08/10 21:51:35 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *      http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
*
**********************************************************************************/
package org.sakaiproject.api.app.melete;

import java.util.List;
/**
 * Mallika - 4/20/05 - Added method to delete section
* Revised by rashmi 4/26 add signature for sort sections
* Mallika - 4/6/06 - Adding parameters for dirs to insertSection and editSection
* Mallika - 8/1/06 - Adding method to delete sections
* Rashmi - 8/10/06 - get max no of sections exisiting in a module
 */
public interface SectionService{
	public void insertSection(ModuleObjService module, SectionObjService section, String contentPath, String homeDir, String meleteDocsDir) throws Exception;
	public void editSection(ModuleObjService module, SectionObjService section,String dataPath, String homeDir, String meleteDocsDir) throws Exception;
	public SectionObjService getSection(int moduleId, int seqNo);

	// used by view pages -- Mallika pages
   public void setSection(SectionObjService sec);
   public List getSections(int moduleId);
   public void setSections(List sections);
   public void deleteSection(SectionObjService sec);
   public void deleteSections(List sectionBeans);
   public void updateSectionsSequence(List newSeqList) throws Exception;
   public int getMaxModuleSections(ModuleObjService module) throws Exception;

}