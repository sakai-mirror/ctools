/*
 * Created on Oct 11, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.sakaiproject.api.app.melete;

/**
 * @author Faculty
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface MeleteUserPreferenceService {
	/**
	 * @return Returns the editorChoice.
	 */
	public abstract String getEditorChoice();

	/**
	 * @param editorChoice The editorChoice to set.
	 */
	public abstract void setEditorChoice(String editorChoice);

	/**
	 * @return Returns the userId.
	 */
	public abstract String getUserId();

	/**
	 * @param userId The userId to set.
	 */
	public abstract void setUserId(String userId);
}