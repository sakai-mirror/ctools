/**********************************************************************************
*
* $Header: /usr/src/sakai/melete-2.2/melete-app/src/java/org/sakaiproject/tool/melete/AddSectionPage.java,v 1.4 2006/11/28 19:14:12 rashmim Exp $
*
***********************************************************************************
*
* Copyright (c) 2004, 2005, 2006 Foothill College.
 *
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.opensource.org/licenses/ecl1.php
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*
**********************************************************************************/

package org.sakaiproject.tool.melete;

import java.util.*;
import java.io.*;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

import javax.faces.context.FacesContext;

import javax.faces.application.FacesMessage;
import org.sakaiproject.api.app.melete.exception.MeleteException;


/**
 * @author Rashmi
 *
 * This class is the backing bean for AddModuleSections.jsp.
 * revised by rashmi 03/15/05 -- to make FS compatabile for linux and windows
 * revised by rashmi - 03/17/05 -- to put upload code in managed bean
 * revised by rashmi 3/23/05 to set form name and to display all error at a time
 * revised by rashmi 03/25 condition of upload file name
 * revised by rashmi 03/29 comment the check for 10000 characters for section content
 * revised to add validation for filename by rashmi on 3/30/05
 * revised to add validation for bad url format by rashmi 5/23/05
 * revised by rashmi 06/23/05 for nav rule from finish to list_auth_modules
 * Mallika - 4/6/06 - Adding new code to send homeDir  in insertSection
 * Mallika - 5/8/06 - Adding fix for https by Universidad Polit�cnica de Valencia
 * Mallika - 10/13/06 - Adding reference to checkUploadExists from saveHere
 * Mallika - 10/24/06 - Removed comments and changed logger.info to debug
 */

public class AddSectionPage extends SectionPage implements Serializable/*,ToolBean*/{
	private boolean sizeWarning=false;


	public AddSectionPage(){
		setFormName("AddSectionForm");
		}

	/**
	 * @return sizeWarning
	 * render sizeWarning message if this flag is true
	 */
	public boolean getSizeWarning()
	{
		return this.sizeWarning;
	}

	/**
	 * @param sizeWarning
	 * to set sizeWarning to true if section save is successful.
	 */
	public void setSizeWarning(boolean sizeWarning)
	{
		this.sizeWarning = sizeWarning;
	}

	/**
	 * instantiates saving of a section.
	 * if file needs to be uploaded, upload file.
	 * Validate content.
	 * save section.
	 * If sucess set success flag and show the success message.
	 * if any error, display error message to the user.
	 *
	 * revised - to get all error messages at one time
	 **/
	public String saveHere()
	{
		checkUploadExists();
		String dataPath=new String();
		logger.debug("save sections called");


		setSuccess(false);
		 FacesContext context = FacesContext.getCurrentInstance();

	     ResourceBundle bundle = ResourceBundle.getBundle("org.sakaiproject.tool.melete.bundle.Messages",
	                		context.getViewRoot().getLocale());

	  // upload code
	   uploadContent("file1");

	    if ((section.getTitle() == null || section.getTitle().length()== 0) && !validateModality() && section.getContentType().equals("typeEditor") && getContentEditor().length() <=17)
	     {
	     	String errMsg = bundle.getString("add_section_modality_reqd");
			context.addMessage(null, new FacesMessage(errMsg));
			errMsg = bundle.getString("section_content_required");
			context.addMessage("contentType", new FacesMessage(errMsg));
			return "failure";
	     }

//	   modality is required.
	     if (!validateModality())
	     {
	     	String errMsg = bundle.getString("add_section_modality_reqd");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
	     }

	     if(section.getContentType().equals("notype"))
	     {
	     	String errMsg = bundle.getString("section_content_required");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
	     }

	     // validate first if content is there for the right content type choice
	     if (!validateContent())
	     {
	     	String errMsg = bundle.getString("add_section_content_validate_fail");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
	     }

	     if (this.section.getContentType().equals("typeLink") && this.section.getLink() != null && !(this.section.getLink().startsWith("http://") || this.section.getLink().startsWith("https://")))

		 	{
	     	String errMsg = bundle.getString("add_section_bad_url_format");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
		 	}
	  	//set a datapath for all type of content -- link, upload or content
	     dataPath= createDataPath();

	     // revised to add validation for filename by rashmi on 3/30/05
	     if(section.getContentType().equals("typeUpload"))
	     {
	     	if(!validateUploadFileName(hiddenUpload))
	     		{
	     		String errMsg = bundle.getString("bad_uploadfile_name");
				context.addMessage (null, new FacesMessage(errMsg));
				return "failure";
	     		}

	       	String uploadFile;
	       	//	      revised by rashmi 03/25-- condition to -1
	    	if(hiddenUpload.indexOf("\\") != -1)
			{
	    		uploadFile = hiddenUpload.substring(hiddenUpload.lastIndexOf("\\")+1);
			} else
			{
				uploadFile = hiddenUpload.substring(hiddenUpload.lastIndexOf("/")+1);
			}

	       	File uFile = new File(homeDir+File.separator+"uploads"+File.separator+ uploadFile);

	    	// check if file really got uploaded
	       	logger.debug("looking for uploaded file in uploads directory :uFile.getName() "+uFile.getName() +"uFile.getPath() :" +uFile.getPath());
	       	if(!uFile.exists())
	       	{
	       		logger.debug("file is not uploaded");
	       		String errMsg = bundle.getString("add_section_upload_file_fail");
				context.addMessage (null, new FacesMessage(errMsg));
				return "failure";
	       	}

	    	// check filesize
	       	double size = uFile.length()/1024;
            logger.debug("File size in KB is "+size);

	       	if(uFile.length() <= 0)
	       	 {
	        	// if size is greater than allow size set warning message
	       		//logger.debug("uploaded file is empty");
	       		String errMsg = bundle.getString("add_section_file_empty");
				context.addMessage (null, new FacesMessage(errMsg));
				return "failure";
	       	 }

	       	// get course size allowed
	        if(getMaxUploadSize() < size)
	       	 {
	        	// if size is greater than allow size set warning message
	         		sizeWarning=true;
	       	 }
	       	 section.setUploadPath(uploadFile);
	      }

		try
		{
//			 if content is new, create temp file to store the contents

		     if(section.getContentType().equals("typeEditor") && getContentEditor() != null && getContentEditor().trim()!=null)
		     {
		       	createContentTempFile();
		     }

		     // if content is a link
		     if(section.getContentType().equals("typeLink") && section.getLink().startsWith("http://"))
		     {
		     //	System.out.println("checking link");
		     	String check = validateLink(section.getLink());
		     }
	   //   save section
		    logger.debug("AddSectionpage:inserting section");
		    //Mallika - new code to send the dirs
		    String homeDir = context.getExternalContext().getInitParameter("homeDir");
			String meleteDocsDir = context.getExternalContext().getInitParameter("meleteDocsDir");

			
		    getSectionService().insertSection(module,section,dataPath,homeDir,meleteDocsDir);
		}
		catch(MalformedURLException me)
		{
			String errMsg = bundle.getString("add_section_bad_url");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
		}
		catch(UnknownHostException me)
		{
			String errMsg = bundle.getString("add_section_bad_url");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
		}
		catch(MeleteException me)
		{
			String errMsg = bundle.getString(me.getMessage());
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
		}
		catch(Exception ex)
			{
			logger.error("error in insertind section "+ ex.toString());
			String errMsg = bundle.getString("add_section_fail");
			context.addMessage (null, new FacesMessage(errMsg));
			return "failure";
			}

		return "success";
	}

	public String save()
	{
		setSuccess(false);
		if(!saveHere().equals("failure"))
		{
		setSuccess(true);
		return "confirm_addmodulesection";
		}
		return "addmodulesections";
	}

	/*
	 * moved from sectionpage to give right nav rules
	 */
	public String editModulefromSection()
	{
		if(base_editModulefromSection().equals("success"))
		{
			return "edit_module";
		} else {
			return "addmodulesections";
		}

	}
	/**
	 * save the section, if not saved yet and then refresh the page to
	 * add more sections.
	 **/
	public String saveAndAddAnotherSection()
	{
		//System.out.println("save and add another sections called");

	     // create new instance of section model
	     resetSectionValues();
	     setSizeWarning(false);

		return "addmodulesections";
	}

	/**
	 * returns failure if the section has not been saved first.
	 * returns finish to redirect to addmodulefinish page.
	 * */
	public String Finish()
	{
		return "list_auth_modules";
	}

	public String previewFromAdd()
	{
		return "previewEditor";
	}

	public String previewLinkFromAdd()
	{
		return "previewLink";
	}

}