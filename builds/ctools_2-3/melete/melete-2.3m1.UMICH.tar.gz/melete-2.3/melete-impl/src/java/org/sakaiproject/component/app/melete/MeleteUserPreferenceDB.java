/*
 * Created on Oct 11, 2006 
 *
 * author Rashmi
 */
package org.sakaiproject.component.app.melete;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.StaleObjectStateException;
import org.hibernate.Transaction;


public class MeleteUserPreferenceDB {
	private HibernateUtil hibernateUtil;
	private Log logger = LogFactory.getLog(MeleteUserPreferenceDB.class);
	private String userEditorChoice;
	
	/**
	 * default constructor 
	 */
	public MeleteUserPreferenceDB() {
		
	}

	public String getUserEditorPreference(String userId)
	{
		try{
			logger.debug("MeleteUserPreference:getUserPreference()");
		     Session session = getHibernateUtil().currentSession();
		     Query q=session.createQuery("select mup.editorChoice from MeleteUserPreference mup where mup.userId =:userId");
			  q.setParameter("userId",userId);
			 String choice = (String)q.uniqueResult();
			 logger.debug("choice from db is " + choice);
		     getHibernateUtil().closeSession();
		     return choice;
		} catch(Exception ex)
		{
			//ex.printStackTrace();
			logger.error(ex.toString());
			return "";
			}
		
	}
	
	/**
	 * @param userEditorChoice The userEditorChoice to set.
	 */
	public void setUserEditorChoice(String user_id, String userEditorChoice) throws Exception {
		try{
			logger.debug("MeleteUserPreference:setUserEditorChoice()");
		     Session session = getHibernateUtil().currentSession();
		     Transaction tx = null;
		     try
		     {
		     	
		     	Query q=session.createQuery("select mup from MeleteUserPreference as mup where mup.userId =:userId");
				  q.setParameter("userId",user_id);
				  MeleteUserPreference existMUP = (MeleteUserPreference)q.uniqueResult(); 
				 if ( existMUP == null)
				 {
		     	   	MeleteUserPreference mup = new MeleteUserPreference();
		     	   	mup.setEditorChoice(userEditorChoice);
		     	   	mup.setUserId(user_id);
		     	   	tx = session.beginTransaction();
				// logger.debug("saving section");
		     	   	session.save(mup);		     	   
				 }
				 else 
				 {
				 	existMUP.setEditorChoice(userEditorChoice);
				 	existMUP.setUserId(user_id);
		     	   	tx = session.beginTransaction();
				// logger.debug("saving section");
		     	   	session.update(existMUP);
				 }
					tx.commit();
		     	   	session.flush();
		     }
		     catch(StaleObjectStateException sose)
		     {
				logger.error("stale object exception" + sose.toString());
				throw sose;
		     }
			catch(HibernateException he)
				     {
						if(tx !=null) tx.rollback();
						logger.error(he.toString());
						throw he;
				     }
	        	finally{
				hibernateUtil.closeSession();
				 }		     
		} catch(Exception ex)
		{
			ex.printStackTrace();
			logger.error(ex.toString());	
			throw ex;
		}		
	}
	/**
	 * @return Returns the hibernateUtil.
	 */
	public HibernateUtil getHibernateUtil() {
		return hibernateUtil;
	}
	/**
	 * @param hibernateUtil The hibernateUtil to set.
	 */
	public void setHibernateUtil(HibernateUtil hibernateUtil) {
		this.hibernateUtil = hibernateUtil;
	}

	/**
	 * @param logger The logger to set.
	 */
	public void setLogger(Log logger) {
		this.logger = logger;
	}
	
	
}
