--
-- Table structure for table `melete_cc_license`
--


CREATE TABLE `melete_cc_license` (
  `REQ_ATTR` tinyint(1) NOT NULL default '0',
  `ALLOW_CMRCL` tinyint(1) NOT NULL default '0',
  `ALLOW_MOD` int(11) NOT NULL default '0',
  `URL` varchar(100) NOT NULL default '',
  `NAME` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`REQ_ATTR`,`ALLOW_CMRCL`,`ALLOW_MOD`,`URL`,`NAME`)
);


--
-- Table structure for table `melete_course_module`
--

CREATE TABLE `melete_course_module` (
  `MODULE_ID` int(11) NOT NULL default '0',
  `COURSE_ID` varchar(99) default NULL,
  `SEQ_NO` int(11) NOT NULL default '0',
  `ARCHV_FLAG` tinyint(1) default NULL,
  `DATE_ARCHIVED` datetime default NULL,
  `DELETE_FLAG` tinyint(1) default NULL,
  PRIMARY KEY  (`MODULE_ID`)
);


--
-- Table structure for table `melete_module`
--

CREATE TABLE `melete_module` (
  `MODULE_ID` int(11) NOT NULL default '0',
  `VERSION` int(11) NOT NULL default '0',
  `TITLE` varchar(50) NOT NULL default '',
  `LEARN_OBJ` text,
  `DESCRIPTION` text,
  `KEYWORDS` varchar(250) NOT NULL default '',
  `CREATED_BY_FNAME` varchar(20) NOT NULL default '',
  `CREATED_BY_LNAME` varchar(30) NOT NULL default '',
  `USER_ID` varchar(99) NOT NULL default '',
  `MODIFIED_BY_FNAME` varchar(20) default NULL,
  `MODIFIED_BY_LNAME` varchar(30) default NULL,
  `INSTITUTE` varchar(50) default NULL,
  `LICENSE_CODE` int(11) default NULL,
  `CC_LICENSE_URL` varchar(55) default NULL,
  `REQ_ATTR` tinyint(1) default NULL,
  `ALLOW_CMRCL` tinyint(1) default NULL,
  `ALLOW_MOD` int(11) default NULL,
  `WHATS_NEXT` text,
  `CREATION_DATE` datetime NOT NULL default '0000-00-00 00:00:00',
  `MODIFICATION_DATE` datetime default NULL,
  PRIMARY KEY  (`MODULE_ID`)
);


--
-- Table structure for table `melete_module_license`
--

CREATE TABLE `melete_module_license` (
  `CODE` int(11) NOT NULL default '0',
  `DESCRIPTION` varchar(25) default NULL,
  PRIMARY KEY  (`CODE`)
);


--
-- Table structure for table `melete_module_shdates`
--


CREATE TABLE `melete_module_shdates` (
  `MODULE_ID` int(11) NOT NULL default '0',
  `VERSION` int(11) NOT NULL default '0',
  `HIDE_FLAG` tinyint(1) default NULL,
  `START_DATE` datetime default NULL,
  `END_DATE` datetime default NULL,
  PRIMARY KEY  (`MODULE_ID`)
);



--
-- Table structure for table `melete_module_student_privs`
--


CREATE TABLE `melete_module_student_privs` (
  `COURSE_ID` varchar(20) NOT NULL default '',
  `MODULE_ID` int(11) NOT NULL default '0',
  `STUDENT_ID` varchar(11) NOT NULL default '',
  `ALLOW_UNLIMITED` tinyint(1) default NULL,
  `DENY` tinyint(1) default NULL,
  `START_DATE` datetime default NULL,
  `END_DATE` datetime default NULL,
  PRIMARY KEY  (`COURSE_ID`,`MODULE_ID`,`STUDENT_ID`)
);


--
-- Table structure for table `melete_section`
--


CREATE TABLE `melete_section` (
  `SECTION_ID` int(11) NOT NULL default '0',
  `VERSION` int(11) NOT NULL default '0',
  `MODULE_ID` int(11) NOT NULL default '0',
  `SEQ_NO` int(11) default NULL,
  `TITLE` varchar(50) NOT NULL default '',
  `CREATED_BY_FNAME` varchar(20) NOT NULL default '',
  `CREATED_BY_LNAME` varchar(30) NOT NULL default '',
  `MODIFIED_BY_FNAME` varchar(20) default NULL,
  `MODIFIED_BY_LNAME` varchar(30) default NULL,
  `INSTR` varchar(250) default NULL,
  `CONTENT_TYPE` varchar(10) NOT NULL default '',
  `CONTENT_PATH` varchar(200) default NULL,
  `UPLOAD_PATH` varchar(200) default NULL,
  `LINK` varchar(200) default NULL,
  `AUDIO_CONTENT` tinyint(1) default NULL,
  `VIDEO_CONTENT` tinyint(1) default NULL,
  `TEXTUAL_CONTENT` tinyint(1) default NULL,
  `DELETE_FLAG` tinyint(1) default NULL,
  `CREATION_DATE` datetime NOT NULL default '0000-00-00 00:00:00',
  `MODIFICATION_DATE` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`SECTION_ID`) 
);


--
-- Table structure for table `melete_user_preference`
--

CREATE TABLE `melete_user_preference` (
  `PREF_ID` int(11) NOT NULL default '0',
  `USER_ID` varchar(99) default NULL,
  `EDITOR_CHOICE` varchar(255) default NULL,
  PRIMARY KEY  (`PREF_ID`)
);

