alter table melete_course_module add column delete_flag tinyint(1);
update melete_course_module set delete_flag=0;
alter table melete_section add column delete_flag tinyint(1);
update melete_section set delete_flag=0;
CREATE TABLE `melete_user_preference` (
  `PREF_ID` int(11) NOT NULL default '0',
  `USER_ID` varchar(99) default NULL,
  `EDITOR_CHOICE` varchar(255) default NULL,
  PRIMARY KEY  (`PREF_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

